﻿namespace Proveedor
{
    partial class Proveedor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TablaProveedor = new System.Windows.Forms.DataGridView();
            this.txtEmail_Proveedor = new System.Windows.Forms.TextBox();
            this.txtTelefono_Proveedor = new System.Windows.Forms.TextBox();
            this.txtNombre_Proveedor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnInserta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TablaProveedor)).BeginInit();
            this.SuspendLayout();
            // 
            // TablaProveedor
            // 
            this.TablaProveedor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaProveedor.Location = new System.Drawing.Point(25, 192);
            this.TablaProveedor.Name = "TablaProveedor";
            this.TablaProveedor.RowHeadersWidth = 51;
            this.TablaProveedor.RowTemplate.Height = 24;
            this.TablaProveedor.Size = new System.Drawing.Size(608, 271);
            this.TablaProveedor.TabIndex = 24;
            // 
            // txtEmail_Proveedor
            // 
            this.txtEmail_Proveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtEmail_Proveedor.Location = new System.Drawing.Point(298, 104);
            this.txtEmail_Proveedor.Name = "txtEmail_Proveedor";
            this.txtEmail_Proveedor.Size = new System.Drawing.Size(281, 30);
            this.txtEmail_Proveedor.TabIndex = 19;
            // 
            // txtTelefono_Proveedor
            // 
            this.txtTelefono_Proveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTelefono_Proveedor.Location = new System.Drawing.Point(298, 62);
            this.txtTelefono_Proveedor.Name = "txtTelefono_Proveedor";
            this.txtTelefono_Proveedor.Size = new System.Drawing.Size(281, 30);
            this.txtTelefono_Proveedor.TabIndex = 18;
            // 
            // txtNombre_Proveedor
            // 
            this.txtNombre_Proveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombre_Proveedor.Location = new System.Drawing.Point(298, 21);
            this.txtNombre_Proveedor.Name = "txtNombre_Proveedor";
            this.txtNombre_Proveedor.Size = new System.Drawing.Size(281, 30);
            this.txtNombre_Proveedor.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(68, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(221, 25);
            this.label4.TabIndex = 16;
            this.label4.Text = "Teléfono del Proveedor:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(68, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "Email del Proveedor:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(68, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Nombre del Proveedor:";
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(461, 153);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 27;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click_1);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(268, 153);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 26;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click_1);
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(77, 153);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 25;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click_1);
            // 
            // Proveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 495);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Controls.Add(this.TablaProveedor);
            this.Controls.Add(this.txtEmail_Proveedor);
            this.Controls.Add(this.txtTelefono_Proveedor);
            this.Controls.Add(this.txtNombre_Proveedor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Proveedor";
            this.Text = "Proveedor";
            ((System.ComponentModel.ISupportInitialize)(this.TablaProveedor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView TablaProveedor;
        private System.Windows.Forms.TextBox txtEmail_Proveedor;
        private System.Windows.Forms.TextBox txtTelefono_Proveedor;
        private System.Windows.Forms.TextBox txtNombre_Proveedor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnInserta;
    }
}

