﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Proveedor
{
    public partial class Proveedor : Form
    {
        SqlConnection nuevaConexion = new SqlConnection("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idProveedor = -1;
        string nombreProveedor = "";
        string telefonoProveedor = "";
        string emailProveedor = "";

        public Proveedor()
        {
            InitializeComponent();
            ConsultaDatos();
            TablaProveedor.CellClick += TablaProveedor_CellClick;
        }

        public void ConsultaDatos()
        {
            nuevaConexion.Open();
            TablaProveedor.DataSource = null;
            string selectInfo = "SELECT * FROM Comercial.Proveedor";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion);
            SqlDataReader reader = cmd.ExecuteReader();
            if (TablaProveedor.Columns.Count == 0)
            {
                TablaProveedor.Columns.Add("idProveedor", "ID");
                TablaProveedor.Columns.Add("nombreProveedor", "Nombre del proveedor");
                TablaProveedor.Columns.Add("telefonoProveedor", "Teléfono del proveedor");
                TablaProveedor.Columns.Add("emailProveedor", "Email del proveedor");
            }

            TablaProveedor.Rows.Clear();

            int i = 0;
            while (reader.Read())
            {
                TablaProveedor.Rows.Add();
                TablaProveedor.Rows[i].Cells[0].Value = reader["idProveedor"].ToString();
                TablaProveedor.Rows[i].Cells[1].Value = reader["nombreProveedor"].ToString();
                TablaProveedor.Rows[i].Cells[2].Value = reader["telefonoProveedor"].ToString();
                TablaProveedor.Rows[i].Cells[3].Value = reader["emailProveedor"].ToString();
                i++;
            }
            reader.Close();
            nuevaConexion.Close();
        }

        private void TablaProveedor_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaProveedor.Rows[e.RowIndex];
                idProveedor = int.Parse(row.Cells[0].Value.ToString());
                txtNombre_Proveedor.Text = row.Cells[1].Value.ToString();
                txtTelefono_Proveedor.Text = row.Cells[2].Value.ToString();
                txtEmail_Proveedor.Text = row.Cells[3].Value.ToString();
            }
        }

        public void InsertaDato()
        {
            nombreProveedor = txtNombre_Proveedor.Text;
            telefonoProveedor = txtTelefono_Proveedor.Text;
            emailProveedor = txtEmail_Proveedor.Text;

            nuevaConexion.Open();

            string verifica = "SELECT COUNT(*) FROM Comercial.Proveedor WHERE telefonoProveedor = @Telefono OR emailProveedor = @Email";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion);
            checkCmd.Parameters.AddWithValue("@Telefono", telefonoProveedor);
            checkCmd.Parameters.AddWithValue("@Email", emailProveedor);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El teléfono o el correo electrónico ya están en uso.");
            }
            else
            {
                string InsertInfo = "INSERT INTO Comercial.Proveedor(nombreProveedor, telefonoProveedor, emailProveedor) " +
                    "VALUES (@Nombre, @Telefono, @Email)";
                SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion);
                cm.Parameters.AddWithValue("@Nombre", nombreProveedor);
                cm.Parameters.AddWithValue("@Telefono", telefonoProveedor);
                cm.Parameters.AddWithValue("@Email", emailProveedor);
                cm.ExecuteNonQuery();
            }

            nuevaConexion.Close();
            nombreProveedor = "";
            telefonoProveedor = "";
            emailProveedor = "";
        }

        public void ModificaDato()
        {
            nombreProveedor = txtNombre_Proveedor.Text;
            telefonoProveedor = txtTelefono_Proveedor.Text;
            emailProveedor = txtEmail_Proveedor.Text;

            nuevaConexion.Open();

            string verifica = "SELECT COUNT(*) FROM Comercial.Proveedor WHERE (telefonoProveedor = @Telefono OR emailProveedor = @Email) AND idProveedor != @Id";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion);
            checkCmd.Parameters.AddWithValue("@Telefono", telefonoProveedor);
            checkCmd.Parameters.AddWithValue("@Email", emailProveedor);
            checkCmd.Parameters.AddWithValue("@Id", idProveedor);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El teléfono o el correo electrónico ya están en uso por otro proveedor.");
            }
            else
            {
                string update = "UPDATE Comercial.Proveedor SET nombreProveedor = @Nombre, telefonoProveedor = @Telefono, emailProveedor = @Email " +
                    "WHERE idProveedor = @Id";
                SqlCommand cmd = new SqlCommand(update, nuevaConexion);
                cmd.Parameters.AddWithValue("@Nombre", nombreProveedor);
                cmd.Parameters.AddWithValue("@Telefono", telefonoProveedor);
                cmd.Parameters.AddWithValue("@Email", emailProveedor);
                cmd.Parameters.AddWithValue("@Id", idProveedor);
                cmd.ExecuteNonQuery();
            }

            nuevaConexion.Close();
        }

        public void EliminaDato()
        {
            if (idProveedor != -1)
            {
                nuevaConexion.Open();
                string delete = "DELETE FROM Comercial.Proveedor WHERE idProveedor = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion);
                cmd.Parameters.AddWithValue("@Id", idProveedor);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Comercial.Proveedor";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion);
                int rowCount = (int)checkCmd.ExecuteScalar();

                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Comercial.Proveedor', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion);
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.Close();
            }
        }

        private void btnInserta_Click_1(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtNombre_Proveedor.Clear();
            txtTelefono_Proveedor.Clear();
            txtEmail_Proveedor.Clear();
        }

        private void btnModifica_Click_1(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtNombre_Proveedor.Clear();
            txtTelefono_Proveedor.Clear();
            txtEmail_Proveedor.Clear();
            idProveedor = -1;
        }

        private void btnElimina_Click_1(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtNombre_Proveedor.Clear();
            txtTelefono_Proveedor.Clear();
            txtEmail_Proveedor.Clear();
            idProveedor = -1;
        }
    }
}
