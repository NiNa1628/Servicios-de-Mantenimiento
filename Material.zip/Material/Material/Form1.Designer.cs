﻿namespace Material
{
    partial class Material
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNombre_Material = new System.Windows.Forms.TextBox();
            this.txtExistencia = new System.Windows.Forms.TextBox();
            this.txtPrecio_Material = new System.Windows.Forms.TextBox();
            this.cmbBoxTipo_Material = new System.Windows.Forms.ComboBox();
            this.btnInserta = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnElimina = new System.Windows.Forms.Button();
            this.TablaMaterial = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.TablaMaterial)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(155, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre del material:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(155, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Existencias:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(155, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Precio del material:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(155, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tipo del material:";
            // 
            // txtNombre_Material
            // 
            this.txtNombre_Material.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombre_Material.Location = new System.Drawing.Point(364, 27);
            this.txtNombre_Material.Name = "txtNombre_Material";
            this.txtNombre_Material.Size = new System.Drawing.Size(281, 30);
            this.txtNombre_Material.TabIndex = 4;
            // 
            // txtExistencia
            // 
            this.txtExistencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtExistencia.Location = new System.Drawing.Point(364, 149);
            this.txtExistencia.Name = "txtExistencia";
            this.txtExistencia.Size = new System.Drawing.Size(281, 30);
            this.txtExistencia.TabIndex = 6;
            // 
            // txtPrecio_Material
            // 
            this.txtPrecio_Material.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtPrecio_Material.Location = new System.Drawing.Point(364, 110);
            this.txtPrecio_Material.Name = "txtPrecio_Material";
            this.txtPrecio_Material.Size = new System.Drawing.Size(281, 30);
            this.txtPrecio_Material.TabIndex = 7;
            // 
            // cmbBoxTipo_Material
            // 
            this.cmbBoxTipo_Material.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBoxTipo_Material.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cmbBoxTipo_Material.FormattingEnabled = true;
            this.cmbBoxTipo_Material.Items.AddRange(new object[] {
            "Plomeria",
            "Reconstrucción",
            "Electricidad"});
            this.cmbBoxTipo_Material.Location = new System.Drawing.Point(364, 68);
            this.cmbBoxTipo_Material.Name = "cmbBoxTipo_Material";
            this.cmbBoxTipo_Material.Size = new System.Drawing.Size(281, 33);
            this.cmbBoxTipo_Material.TabIndex = 8;
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(160, 203);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 9;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(351, 203);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 10;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(544, 203);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 11;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // TablaMaterial
            // 
            this.TablaMaterial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaMaterial.Location = new System.Drawing.Point(38, 250);
            this.TablaMaterial.Name = "TablaMaterial";
            this.TablaMaterial.RowHeadersWidth = 51;
            this.TablaMaterial.RowTemplate.Height = 24;
            this.TablaMaterial.Size = new System.Drawing.Size(739, 260);
            this.TablaMaterial.TabIndex = 12;
            // 
            // Material
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 537);
            this.Controls.Add(this.TablaMaterial);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Controls.Add(this.cmbBoxTipo_Material);
            this.Controls.Add(this.txtPrecio_Material);
            this.Controls.Add(this.txtExistencia);
            this.Controls.Add(this.txtNombre_Material);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Material";
            this.Text = "Material";
            ((System.ComponentModel.ISupportInitialize)(this.TablaMaterial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNombre_Material;
        private System.Windows.Forms.TextBox txtExistencia;
        private System.Windows.Forms.TextBox txtPrecio_Material;
        private System.Windows.Forms.ComboBox cmbBoxTipo_Material;
        private System.Windows.Forms.Button btnInserta;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.DataGridView TablaMaterial;
    }
}

