﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Material
{
    public partial class Material : Form
    {
        SqlConnection nuevaConexion = new SqlConnection("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idMaterial = -1;
        string nombreMaterial = "";
        string tipoMaterial = "";
        string precioMaterial = "";
        string existencia = "";

        public Material()
        {
            InitializeComponent();
            ConsultaDatos();
            TablaMaterial.CellClick += TablaMaterial_CellClick;
        }

        public void ConsultaDatos()
        {
            nuevaConexion.Open();
            TablaMaterial.DataSource = null;
            string selectInfo = "SELECT * FROM Operativo.Material";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion);
            SqlDataReader reader = cmd.ExecuteReader();
            if (TablaMaterial.Columns.Count == 0)
            {
                TablaMaterial.Columns.Add("idMaterial", "ID");
                TablaMaterial.Columns.Add("nombreMaterial", "Nombre del material");
                TablaMaterial.Columns.Add("tipoMaterial", "Tipo del material");
                TablaMaterial.Columns.Add("precioMaterial", "Precio del material");
                TablaMaterial.Columns.Add("existencia", "Existencias");

                TablaMaterial.Columns["precioMaterial"].DefaultCellStyle.Format = "N2";
            }

            TablaMaterial.Rows.Clear();

            int i = 0;
            while (reader.Read())
            {
                TablaMaterial.Rows.Add();
                TablaMaterial.Rows[i].Cells[0].Value = reader["idMaterial"].ToString();
                TablaMaterial.Rows[i].Cells[1].Value = reader["nombreMaterial"].ToString();
                TablaMaterial.Rows[i].Cells[2].Value = reader["tipoMaterial"].ToString();
                TablaMaterial.Rows[i].Cells[3].Value = Convert.ToDecimal(reader["precioMaterial"]).ToString("N2");
                TablaMaterial.Rows[i].Cells[4].Value = reader["existencia"].ToString();
                i++;
            }
            reader.Close();
            nuevaConexion.Close();
        }

        private void TablaMaterial_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaMaterial.Rows[e.RowIndex];
                idMaterial = int.Parse(row.Cells[0].Value.ToString());
                txtNombre_Material.Text = row.Cells[1].Value.ToString();
                cmbBoxTipo_Material.Text = row.Cells[2].Value.ToString();
                txtPrecio_Material.Text = row.Cells[3].Value.ToString();
                txtExistencia.Text = row.Cells[4].Value.ToString();
            }
        }

        public void InsertaDato()
        {
            nombreMaterial = txtNombre_Material.Text;
            tipoMaterial = cmbBoxTipo_Material.Text;
            precioMaterial = txtPrecio_Material.Text;
            existencia = txtExistencia.Text;

            try
            {
                nuevaConexion.Open();
                string InsertInfo = "INSERT INTO Operativo.Material(nombreMaterial, tipoMaterial, precioMaterial, existencia) " +
                    "VALUES ('" + nombreMaterial + "', '" + tipoMaterial + "', '" + precioMaterial + "', '" + existencia + "')";
                SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion);
                cm.ExecuteNonQuery();
            }
            catch(SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    MessageBox.Show("No se puede insertar el material. El nombre ya existe.");
                }
                else
                {
                    MessageBox.Show("Error al insertar el material: " + ex.Message);
                }
            }
            finally
            {
                nuevaConexion.Close();
                nombreMaterial = "";
                tipoMaterial = "";
                precioMaterial = "";
                existencia = "";
            }
        }

        public void ModificaDato()
        {
            nombreMaterial = txtNombre_Material.Text;
            tipoMaterial = cmbBoxTipo_Material.Text;
            precioMaterial = txtPrecio_Material.Text;
            existencia = txtExistencia.Text;

            try
            {
                nuevaConexion.Open();
                string update = "UPDATE Operativo.Material SET nombreMaterial = @Nombre, tipoMaterial = @Tipo, precioMaterial = @Precio, existencia = @Existencias " +
                    "WHERE idMaterial = @Id";
                SqlCommand cmd = new SqlCommand(update, nuevaConexion);
                cmd.Parameters.AddWithValue("@Nombre", nombreMaterial);
                cmd.Parameters.AddWithValue("@Tipo", tipoMaterial);
                cmd.Parameters.AddWithValue("@Precio", precioMaterial);
                cmd.Parameters.AddWithValue("@Existencias", existencia);
                cmd.Parameters.AddWithValue("@Id", idMaterial);
                cmd.ExecuteNonQuery();
            }

            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    MessageBox.Show("No se puede insertar el material. El nombre ya existe.");
                }
                else
                {
                    MessageBox.Show("Error al insertar el material: " + ex.Message);
                }
            }
            finally
            {
                nuevaConexion.Close();
            }
        }

        public void EliminaDato()
        {
            if (idMaterial != -1)
            {
                nuevaConexion.Open();
                string delete = "DELETE FROM Operativo.Material WHERE idMaterial = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion);
                cmd.Parameters.AddWithValue("@Id", idMaterial);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Operativo.Material";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion);
                int rowCount = (int)checkCmd.ExecuteScalar();

                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Operativo.Material', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion);
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.Close();
            }
        }

        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtNombre_Material.Clear();
            cmbBoxTipo_Material.SelectedIndex = -1;
            txtPrecio_Material.Clear();
            txtExistencia.Clear();
        }

        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtNombre_Material.Clear();
            cmbBoxTipo_Material.SelectedIndex = -1;
            txtPrecio_Material.Clear();
            txtExistencia.Clear();
            idMaterial = -1;
        }

        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtNombre_Material.Clear();
            cmbBoxTipo_Material.SelectedIndex = -1;
            txtPrecio_Material.Clear();
            txtExistencia.Clear();
            idMaterial = -1;
        }
    }
}
