﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Trabajador
{
    public partial class Trabajador : Form
    {
        SqlConnection nuevaConexion = new SqlConnection("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idTrabajador = -1;
        string nombreTrabajador = "";
        string RFCTrabajador = "";
        string telefonoTrabajador = "";
        string emailTrabajador = "";

        public Trabajador()
        {
            InitializeComponent();
            ConsultaDatos();
            TablaTrabajador.CellClick += TablaTrabajador_CellClick;
        }

        public void ConsultaDatos()
        {
            nuevaConexion.Open();
            TablaTrabajador.DataSource = null;
            string selectInfo = "SELECT * FROM Operativo.Trabajador";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion);
            SqlDataReader reader = cmd.ExecuteReader();
            if (TablaTrabajador.Columns.Count == 0)
            {
                TablaTrabajador.Columns.Add("idTrabajador", "ID");
                TablaTrabajador.Columns.Add("nombreTrabajador", "Nombre del trabajador");
                TablaTrabajador.Columns.Add("RFCTrabajador", "RFC del trabajador");
                TablaTrabajador.Columns.Add("telefonoTrabajador", "Teléfono del trabajador");
                TablaTrabajador.Columns.Add("emailTrabajador", "Email del trabajador");
            }

            TablaTrabajador.Rows.Clear();

            int i = 0;
            while (reader.Read())
            {
                TablaTrabajador.Rows.Add();
                TablaTrabajador.Rows[i].Cells[0].Value = reader["idTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[1].Value = reader["nombreTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[2].Value = reader["RFCTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[3].Value = reader["telefonoTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[4].Value = reader["emailTrabajador"].ToString();
                i++;
            }
            reader.Close();
            nuevaConexion.Close();
        }

        private void TablaTrabajador_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaTrabajador.Rows[e.RowIndex];
                idTrabajador = int.Parse(row.Cells[0].Value.ToString());
                txtNombre_Trabajador.Text = row.Cells[1].Value.ToString();
                txtRFC_Trabajador.Text = row.Cells[2].Value.ToString();
                txtTelefono_Trabajador.Text = row.Cells[3].Value.ToString();
                txtEmail_Trabajador.Text = row.Cells[4].Value.ToString();
            }
        }

        public void InsertaDato()
        {
            nombreTrabajador = txtNombre_Trabajador.Text;
            RFCTrabajador = txtRFC_Trabajador.Text;
            telefonoTrabajador = txtTelefono_Trabajador.Text;
            emailTrabajador = txtEmail_Trabajador.Text;

            nuevaConexion.Open();
            string InsertInfo = "INSERT INTO Operativo.Trabajador(nombreTrabajador, RFCTrabajador, telefonoTrabajador, emailTrabajador) " +
            "VALUES ('" + nombreTrabajador + "', '" + RFCTrabajador + "', '" + telefonoTrabajador + "', '" + emailTrabajador + "')";
            SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion);
            cm.ExecuteNonQuery();
            nuevaConexion.Close();
            nombreTrabajador = "";
            RFCTrabajador = "";
            telefonoTrabajador = "";
            emailTrabajador = "";
        }

        public void ModificaDato()
        {
            nombreTrabajador = txtNombre_Trabajador.Text;
            RFCTrabajador = txtRFC_Trabajador.Text;
            telefonoTrabajador = txtTelefono_Trabajador.Text;
            emailTrabajador = txtEmail_Trabajador.Text;

            nuevaConexion.Open();
            string update = "UPDATE Operativo.Trabajador SET nombreTrabajador = @Nombre, RFCTrabajador = @RFC ,telefonoTrabajador = @Telefono, emailTrabajador = @Email " +
                "WHERE idTrabajador = @Id";
            SqlCommand cmd = new SqlCommand(update, nuevaConexion);
            cmd.Parameters.AddWithValue("@Nombre", nombreTrabajador);
            cmd.Parameters.AddWithValue("@RFC", RFCTrabajador);
            cmd.Parameters.AddWithValue("@Telefono", telefonoTrabajador);
            cmd.Parameters.AddWithValue("@Email", emailTrabajador);
            cmd.Parameters.AddWithValue("@Id", idTrabajador);
            cmd.ExecuteNonQuery();
            nuevaConexion.Close();
        }

        public void EliminaDato()
        {
            if (idTrabajador != -1)
            {
                nuevaConexion.Open();
                string delete = "DELETE FROM Operativo.Trabajador WHERE idTrabajador = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion);
                cmd.Parameters.AddWithValue("@Id", idTrabajador);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Operativo.Trabajador";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion);
                int rowCount = (int)checkCmd.ExecuteScalar();

                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Operativo.Trabajador', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion);
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.Close();
            }
        }

        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtNombre_Trabajador.Clear();
            txtRFC_Trabajador.Clear();
            txtTelefono_Trabajador.Clear();
            txtEmail_Trabajador.Clear();
        }

        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtNombre_Trabajador.Clear();
            txtRFC_Trabajador.Clear();
            txtTelefono_Trabajador.Clear();
            txtEmail_Trabajador.Clear();
            idTrabajador = -1;
        }

        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtNombre_Trabajador.Clear();
            txtRFC_Trabajador.Clear();
            txtTelefono_Trabajador.Clear();
            txtEmail_Trabajador.Clear();
            idTrabajador = -1;
        }
    }
}
