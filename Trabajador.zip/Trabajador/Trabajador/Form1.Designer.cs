﻿namespace Trabajador
{
    partial class Trabajador
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnInserta = new System.Windows.Forms.Button();
            this.TablaTrabajador = new System.Windows.Forms.DataGridView();
            this.txtEmail_Trabajador = new System.Windows.Forms.TextBox();
            this.txtTelefono_Trabajador = new System.Windows.Forms.TextBox();
            this.txtNombre_Trabajador = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRFC_Trabajador = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TablaTrabajador)).BeginInit();
            this.SuspendLayout();
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(529, 195);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 37;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(336, 195);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 36;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(145, 195);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 35;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click);
            // 
            // TablaTrabajador
            // 
            this.TablaTrabajador.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaTrabajador.Location = new System.Drawing.Point(27, 238);
            this.TablaTrabajador.Name = "TablaTrabajador";
            this.TablaTrabajador.RowHeadersWidth = 51;
            this.TablaTrabajador.RowTemplate.Height = 24;
            this.TablaTrabajador.Size = new System.Drawing.Size(737, 271);
            this.TablaTrabajador.TabIndex = 34;
            // 
            // txtEmail_Trabajador
            // 
            this.txtEmail_Trabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtEmail_Trabajador.Location = new System.Drawing.Point(368, 138);
            this.txtEmail_Trabajador.Name = "txtEmail_Trabajador";
            this.txtEmail_Trabajador.Size = new System.Drawing.Size(281, 30);
            this.txtEmail_Trabajador.TabIndex = 33;
            // 
            // txtTelefono_Trabajador
            // 
            this.txtTelefono_Trabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTelefono_Trabajador.Location = new System.Drawing.Point(368, 99);
            this.txtTelefono_Trabajador.Name = "txtTelefono_Trabajador";
            this.txtTelefono_Trabajador.Size = new System.Drawing.Size(281, 30);
            this.txtTelefono_Trabajador.TabIndex = 32;
            // 
            // txtNombre_Trabajador
            // 
            this.txtNombre_Trabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombre_Trabajador.Location = new System.Drawing.Point(368, 22);
            this.txtNombre_Trabajador.Name = "txtNombre_Trabajador";
            this.txtNombre_Trabajador.Size = new System.Drawing.Size(281, 30);
            this.txtNombre_Trabajador.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(136, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(226, 25);
            this.label4.TabIndex = 30;
            this.label4.Text = "Teléfono del Trabajador:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(136, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(197, 25);
            this.label3.TabIndex = 29;
            this.label3.Text = "Email del Trabajador:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(136, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "Nombre del Trabajador:";
            // 
            // txtRFC_Trabajador
            // 
            this.txtRFC_Trabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtRFC_Trabajador.Location = new System.Drawing.Point(368, 61);
            this.txtRFC_Trabajador.Name = "txtRFC_Trabajador";
            this.txtRFC_Trabajador.Size = new System.Drawing.Size(281, 30);
            this.txtRFC_Trabajador.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(136, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 25);
            this.label2.TabIndex = 38;
            this.label2.Text = "RFC del Trabajador:";
            // 
            // Trabajador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 540);
            this.Controls.Add(this.txtRFC_Trabajador);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Controls.Add(this.TablaTrabajador);
            this.Controls.Add(this.txtEmail_Trabajador);
            this.Controls.Add(this.txtTelefono_Trabajador);
            this.Controls.Add(this.txtNombre_Trabajador);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Trabajador";
            this.Text = "Trabajador";
            ((System.ComponentModel.ISupportInitialize)(this.TablaTrabajador)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnInserta;
        private System.Windows.Forms.DataGridView TablaTrabajador;
        private System.Windows.Forms.TextBox txtEmail_Trabajador;
        private System.Windows.Forms.TextBox txtTelefono_Trabajador;
        private System.Windows.Forms.TextBox txtNombre_Trabajador;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRFC_Trabajador;
        private System.Windows.Forms.Label label2;
    }
}

