﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario Compra.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
        Clase para gestionar el manejo de las compras dentro de los Servicios de Mantenimiento
        Proporciona métodos para consultar, insertar, modificar y eliminar datos.
     */
    public partial class Compra : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idCompra = -1;
        string idProveedor = "";
        string fechaCompra = "";
        string totalCompra = "0.00";

        //Lista que almacena objetos de tipo DetalleCompra.
        private List<DetalleCompra> detalleCompraForms = new List<DetalleCompra>();

        /* 
            Constructor del formulario Compra.
            Inicializa el formulario y carga los datos de la tabla Compra en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public Compra()
        {
            InitializeComponent();
            ConsultaDatos();
            CargarProveedores();
            TablaCompra.CellClick += TablaCompra_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Comercial.Compra en el DataGridView.
            Formatea la columna de precios y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaCompra.DataSource = null;

            // Cadena SQL para consultar la tabla Comercial.Compra.
            string selectInfo = "SELECT c.idCompra, c.idProveedor, c.fechaCompra, c.totalCompra, " +
                                "p.NombreProveedor, p.TelefonoProveedor " +
                                "FROM Comercial.Compra c " +
                                "JOIN Comercial.Proveedor p ON c.idProveedor = p.idProveedor";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaCompra si es que no contiene columnas.
            if (TablaCompra.Columns.Count == 0)
            {
                TablaCompra.Columns.Add("idCompra", "ID");
                TablaCompra.Columns.Add("idProveedor", "Proveedor");
                TablaCompra.Columns.Add("fechaCompra", "Fecha de la compra");
                TablaCompra.Columns.Add("totalCompra", "Total de la compra");

                TablaCompra.Columns["totalCompra"].DefaultCellStyle.Format = "N2";
            }

            TablaCompra.Rows.Clear();
            int i = 0;

            // Agrega a TablaCompra una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                string nombreProveedor = reader["NombreProveedor"].ToString();
                string telefonoProveedor = reader["TelefonoProveedor"].ToString();
                string proveedor = $"{nombreProveedor} - {telefonoProveedor.Substring(telefonoProveedor.Length - 3)}";

                TablaCompra.Rows.Add();
                TablaCompra.Rows[i].Cells[0].Value = reader["idCompra"].ToString();
                TablaCompra.Rows[i].Cells[1].Value = proveedor;  // Aquí se muestra la concatenación
                TablaCompra.Rows[i].Cells[2].Value = Convert.ToDateTime(reader["fechaCompra"]).ToString("dd-MM-yyyy");
                var totalValue = reader["totalCompra"];
                if (totalValue == DBNull.Value || string.IsNullOrEmpty(totalValue.ToString()))
                {
                    TablaCompra.Rows[i].Cells[3].Value = "0.00";
                }
                else
                {
                    TablaCompra.Rows[i].Cells[3].Value = Convert.ToDecimal(totalValue).ToString("N2");
                }
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            Carge la información de la tabla Comercial.Proveedor y la muestra en un combobox.
         */
        public void CargarProveedores()
        {
            nuevaConexion.AbrirConexion();
            string selectInfo = "SELECT NombreProveedor, TelefonoProveedor FROM Comercial.Proveedor";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            cmb_Proveedor.Items.Clear();

            // Lee cada proveedor del resultado de la consulta
            while (reader.Read())
            {
                string nombreProveedor = reader["NombreProveedor"].ToString();
                string telefonoProveedor = reader["TelefonoProveedor"].ToString();
                string proveedor = $"{nombreProveedor} - {telefonoProveedor.Substring(telefonoProveedor.Length - 3)}";

                // Agrega el resultado al combobox
                cmb_Proveedor.Items.Add(proveedor);
            }

            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaCompra_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaCompra_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaCompra.Rows[e.RowIndex];
                idCompra = int.Parse(row.Cells[0].Value.ToString());
                cmb_Proveedor.Text = row.Cells[1].Value.ToString();

                // Hace visible al botón btnDetalleCompra.
                btnDetalleCompra.Visible = true;
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Comercial.Compra con los datos ingresados.
         */
        public void InsertaDato()
        {
            string proveedorSeleccionado = cmb_Proveedor.Text;
            string[] partesProveedor = proveedorSeleccionado.Split('-');
            string nombreProveedor = partesProveedor[0].Trim();
            string ultimosTresTelefono = partesProveedor[1].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del proveedor.
            string queryIdProveedor = "SELECT idProveedor FROM Comercial.Proveedor WHERE NombreProveedor = @Nombre AND RIGHT(TelefonoProveedor, 3) = @UltimosTres";
            SqlCommand cmdIdProveedor = new SqlCommand(queryIdProveedor, nuevaConexion.AbrirConexion());
            cmdIdProveedor.Parameters.AddWithValue("@Nombre", nombreProveedor);
            cmdIdProveedor.Parameters.AddWithValue("@UltimosTres", ultimosTresTelefono);
            idProveedor = cmdIdProveedor.ExecuteScalar().ToString();
            nuevaConexion.CerrarConexion();

            DateTime fechaCompra = DateTime.Now;

            
            nuevaConexion.AbrirConexion();
            
            // Cadena SQL para agregar un nuevo registro en la tabla Comercial.Compra.
            string InsertInfo = "INSERT INTO Comercial.Compra(idProveedor, fechaCompra) " +
                                "VALUES (@IdProveedor, @Fecha)";
            SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
            cm.Parameters.AddWithValue("@IdProveedor", idProveedor);
            cm.Parameters.AddWithValue("@Fecha", fechaCompra);
            cm.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Comercial.Compra con los datos actualizados.     
         */
        public void ModificaDato()
        {
            string proveedorSeleccionado = cmb_Proveedor.Text;
            string[] partesProveedor = proveedorSeleccionado.Split('-');
            string nombreProveedor = partesProveedor[0].Trim();
            string ultimosTresTelefono = partesProveedor[1].Trim();

            // Obtén el idProveedor de la base de datos basado en el nombre del proveedor y los últimos 3 dígitos del teléfono
            nuevaConexion.AbrirConexion();
            string queryIdProveedor = "SELECT idProveedor FROM Comercial.Proveedor WHERE NombreProveedor = @Nombre AND RIGHT(TelefonoProveedor, 3) = @UltimosTres";
            SqlCommand cmdIdProveedor = new SqlCommand(queryIdProveedor, nuevaConexion.AbrirConexion());
            cmdIdProveedor.Parameters.AddWithValue("@Nombre", nombreProveedor);
            cmdIdProveedor.Parameters.AddWithValue("@UltimosTres", ultimosTresTelefono);
            idProveedor = cmdIdProveedor.ExecuteScalar().ToString();
            nuevaConexion.CerrarConexion();

            nuevaConexion.AbrirConexion();

            // Cadena SQL para modificar un nuevo registro en la tabla Comercial.Compra.
            string update = "UPDATE Comercial.Compra SET idProveedor = @idProveedor WHERE idCompra = @Id";
            SqlCommand cmd = new SqlCommand(update, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@idProveedor", idProveedor);
            cmd.Parameters.AddWithValue("@Id", idCompra);
            cmd.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Comercial.Compra con los datos actualizados.
         */
        public void EliminaDato()
        {
            if (idCompra != -1)
            {
                nuevaConexion.AbrirConexion();
                
                // Eliminar primero los detalles de la compra.
                string deleteDetalles = "DELETE FROM Comercial.DetalleCompra WHERE idCompra = @Id";
                SqlCommand cmdDetalles = new SqlCommand(deleteDetalles, nuevaConexion.AbrirConexion());
                cmdDetalles.Parameters.AddWithValue("@Id", idCompra);
                cmdDetalles.ExecuteNonQuery();

                // Cadena SQL para eliminar un nuevo registro en la tabla Comercial.Compra.
                string delete = "DELETE FROM Comercial.Compra WHERE idCompra = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Id", idCompra);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Comercial.Compra";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion.AbrirConexion());
                int rowCount = (int)checkCmd.ExecuteScalar();

                // Reinicia el valor del idCompra cuando la cantidad de filas es igual a 0.
                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Comercial.Compra', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion.AbrirConexion());
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.CerrarConexion();
            }
        }

        /*
            Recupera el valor de la columna del idCompra.
         */
        private int ObtenerIdCompra()
        {
            if (TablaCompra.SelectedRows.Count > 0)
            {
                DataGridViewRow row = TablaCompra.SelectedRows[0];
                int idCompra = int.Parse(row.Cells[0].Value.ToString()); // Asegúrate de que el índice de la celda sea correcto

                return idCompra;
            }
            throw new InvalidOperationException("No hay una compra seleccionada.");
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            cmb_Proveedor.SelectedIndex = -1;
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            cmb_Proveedor.SelectedIndex = -1;
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            cmb_Proveedor.SelectedIndex = -1;
        }

        /*
            Evento que se dispara al hacer clic en el botón de Detalle de Compra.
            Abre el formulario DetalleCompra para gestionar los detalles asociados a una compra específica.
         */
        private void btnDetalleCompra_Click(object sender, EventArgs e)
        {
            if (idCompra != -1)
            {
                DetalleCompra detalleCompraForm = new DetalleCompra(idCompra);
                detalleCompraForms.Add(detalleCompraForm);
                detalleCompraForm.SubtotalChanged += DetalleCompraForm_SubtotalChanged;
                detalleCompraForm.FormClosed += (s, args) =>
                {
                    detalleCompraForms.Remove(detalleCompraForm);
                };
                detalleCompraForm.Show();
            }
        }

        /*
            Ejecuta el Evento el cual es disparado por una instancia de DetalleCompra.
         */
        private void DetalleCompraForm_SubtotalChanged(object sender, EventArgs e)
        {
            ConsultaDatos();
        }
    }
}
