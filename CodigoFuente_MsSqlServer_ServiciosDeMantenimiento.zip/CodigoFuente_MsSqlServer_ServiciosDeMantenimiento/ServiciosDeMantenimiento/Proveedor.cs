﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario Proveedor.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
        Clase para gestionar el manejo de los proveedores dentro de los Servicios de Mantenimiento
        Proporciona métodos para consultar, insertar, modificar y eliminar datos.
     */
    public partial class Proveedor : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idProveedor = -1;
        string nombreProveedor = "";
        string telefonoProveedor = "";
        string emailProveedor = "";

        /* 
            Constructor del formulario Proveedor.
            Inicializa el formulario y carga los datos de la tabla Proveedor en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public Proveedor()
        {
            InitializeComponent();
            ConsultaDatos();
            TablaProveedor.CellClick += TablaProveedor_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Comercial.DomicilioCliente en el DataGridView.
            Formatea las columnas y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaProveedor.DataSource = null;

            // Cadena SQL para consultar la tabla Comercial.Proveedor.
            string selectInfo = "SELECT * FROM Comercial.Proveedor";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaProveedor si es que no contiene columnas.
            if (TablaProveedor.Columns.Count == 0)
            {
                TablaProveedor.Columns.Add("idProveedor", "ID");
                TablaProveedor.Columns.Add("nombreProveedor", "Nombre del proveedor");
                TablaProveedor.Columns.Add("telefonoProveedor", "Teléfono del proveedor");
                TablaProveedor.Columns.Add("emailProveedor", "Email del proveedor");
            }

            TablaProveedor.Rows.Clear();
            int i = 0;

            // Agrega a TablaProveedor una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                TablaProveedor.Rows.Add();
                TablaProveedor.Rows[i].Cells[0].Value = reader["idProveedor"].ToString();
                TablaProveedor.Rows[i].Cells[1].Value = reader["nombreProveedor"].ToString();
                TablaProveedor.Rows[i].Cells[2].Value = reader["telefonoProveedor"].ToString();
                TablaProveedor.Rows[i].Cells[3].Value = reader["emailProveedor"].ToString();
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaProveedor_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaProveedor_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaProveedor.Rows[e.RowIndex];
                idProveedor = int.Parse(row.Cells[0].Value.ToString());
                txtNombre_Proveedor.Text = row.Cells[1].Value.ToString();
                txtTelefono_Proveedor.Text = row.Cells[2].Value.ToString();
                txtEmail_Proveedor.Text = row.Cells[3].Value.ToString();
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Comercial.Proveedor con los datos ingresados.
            Si ocurre un error (como duplicación de un teléfono o un correo electrónico), muestra un mensaje de error.
         */
        public void InsertaDato()
        {
            nombreProveedor = txtNombre_Proveedor.Text;
            telefonoProveedor = txtTelefono_Proveedor.Text;
            emailProveedor = txtEmail_Proveedor.Text;

            nuevaConexion.AbrirConexion();

            //Verifica si el teléfono o el correo electrónico ya existen.
            string verifica = "SELECT COUNT(*) FROM Comercial.Proveedor WHERE telefonoProveedor = @Telefono OR emailProveedor = @Email";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion.AbrirConexion());
            checkCmd.Parameters.AddWithValue("@Telefono", telefonoProveedor);
            checkCmd.Parameters.AddWithValue("@Email", emailProveedor);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El teléfono o el correo electrónico ya están en uso.");
            }
            else
            {
                // Cadena SQL para agregar un nuevo registro en la tabla Comercial.Proveedor.
                string InsertInfo = "INSERT INTO Comercial.Proveedor(nombreProveedor, telefonoProveedor, emailProveedor) " +
                    "VALUES (@Nombre, @Telefono, @Email)";
                SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
                cm.Parameters.AddWithValue("@Nombre", nombreProveedor);
                cm.Parameters.AddWithValue("@Telefono", telefonoProveedor);
                cm.Parameters.AddWithValue("@Email", emailProveedor);
                cm.ExecuteNonQuery();
            }

            nuevaConexion.CerrarConexion();
        }

        /*
            Modifica el registro seleccionado en la tabla COmercial.Proveedor con los datos actualizados.
            Si ocurre un error (como duplicación de un teléfono o un correo electrónico), muestra un mensaje de error.
         */
        public void ModificaDato()
        {
            nombreProveedor = txtNombre_Proveedor.Text;
            telefonoProveedor = txtTelefono_Proveedor.Text;
            emailProveedor = txtEmail_Proveedor.Text;

            nuevaConexion.AbrirConexion();
            
            //Verifica si el teléfono o el correo electrónico ya existen.
            string verifica = "SELECT COUNT(*) FROM Comercial.Proveedor WHERE (telefonoProveedor = @Telefono OR emailProveedor = @Email) AND idProveedor != @Id";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion.AbrirConexion());
            checkCmd.Parameters.AddWithValue("@Telefono", telefonoProveedor);
            checkCmd.Parameters.AddWithValue("@Email", emailProveedor);
            checkCmd.Parameters.AddWithValue("@Id", idProveedor);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El teléfono o el correo electrónico ya están en uso por otro proveedor.");
            }
            else
            {
                // Cadena SQL para modificar un nuevo registro en la tabla Comercial.Proveedor.
                string update = "UPDATE Comercial.Proveedor SET nombreProveedor = @Nombre, telefonoProveedor = @Telefono, emailProveedor = @Email " +
                    "WHERE idProveedor = @Id";
                SqlCommand cmd = new SqlCommand(update, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Nombre", nombreProveedor);
                cmd.Parameters.AddWithValue("@Telefono", telefonoProveedor);
                cmd.Parameters.AddWithValue("@Email", emailProveedor);
                cmd.Parameters.AddWithValue("@Id", idProveedor);
                cmd.ExecuteNonQuery();
            }

            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Comercial.Proveedor con los datos actualizados.
         */
        public void EliminaDato()
        {
            if (idProveedor != -1)
            {
                nuevaConexion.AbrirConexion();

                // Cadena SQL para eliminar un nuevo registro en la tabla Comercial.Proveedor.
                string delete = "DELETE FROM Comercial.Proveedor WHERE idProveedor = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Id", idProveedor);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Comercial.Proveedor";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion.AbrirConexion());
                int rowCount = (int)checkCmd.ExecuteScalar();

                // Reinicia el valor del idProveedor cuando la cantidad de filas es igual a 0.
                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Comercial.Proveedor', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion.AbrirConexion());
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.CerrarConexion();
            }
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtNombre_Proveedor.Clear();
            txtTelefono_Proveedor.Clear();
            txtEmail_Proveedor.Clear();
            idProveedor = -1;
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtNombre_Proveedor.Clear();
            txtTelefono_Proveedor.Clear();
            txtEmail_Proveedor.Clear();
            idProveedor = -1;
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtNombre_Proveedor.Clear();
            txtTelefono_Proveedor.Clear();
            txtEmail_Proveedor.Clear();
            idProveedor = -1;
        }
    }
}
