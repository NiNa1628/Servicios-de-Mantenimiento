﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario DomicilioCliente
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ServiciosDeMantenimiento
{
    /*
        Clase para gestionar el manejo de los domicilios de los cliente dentro de los Servicios de Mantenimiento
        Proporciona métodos para consultar, insertar, modificar y eliminar datos.
     */
    public partial class DomicilioCliente : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idDomicilio = -1;
        int idCliente;
        string domicilioCliente = "";

        /* 
            Constructor del formulario DomicilioCliente.
            Inicializa el formulario y carga los datos de la tabla DomicilioCliente en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public DomicilioCliente(int idCliente)
        {

            InitializeComponent();
            this.idCliente = idCliente;
            ConsultaDatos();
            TablaDomicilioCliente.CellClick += TablaDomicilioCliente_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Comercial.DomicilioCliente en el DataGridView.
            Formatea las columnas y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaDomicilioCliente.DataSource = null;

            // Cadena SQL para consultar la tabla Comercial.DomicilioCliente.
            string selectInfo = "SELECT d.idDomicilio, d.idCliente, d.domicilioCliente, " +
                                "c.NombreCliente, c.RFCCliente " +
                                "FROM Comercial.DomicilioCliente d " +
                                "JOIN Comercial.Cliente c ON d.idCliente = c.idCliente " + // Agregamos un espacio al final de esta línea
                                "WHERE c.idCliente = @IdCliente";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdCliente", idCliente);
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaDomicilioCliente si es que no contiene columnas.
            if (TablaDomicilioCliente.Columns.Count == 0)
            {
                TablaDomicilioCliente.Columns.Add("idDomicilio", "ID");
                TablaDomicilioCliente.Columns.Add("idCliente", "Cliente");
                TablaDomicilioCliente.Columns.Add("domicilioCliente", "Domicilio");
            }

            TablaDomicilioCliente.Rows.Clear();
            int i = 0;

            // Agrega a TablaDomicilioCliente una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                string nombreCliente = reader["NombreCliente"].ToString();
                string rfcCliente = reader["RFCCliente"].ToString();
                string cliente = $"{nombreCliente}-{rfcCliente.Substring(rfcCliente.Length - 3)}";

                TablaDomicilioCliente.Rows.Add();
                TablaDomicilioCliente.Rows[i].Cells[0].Value = reader["idDomicilio"].ToString();
                TablaDomicilioCliente.Rows[i].Cells[1].Value = cliente;
                TablaDomicilioCliente.Rows[i].Cells[2].Value = reader["domicilioCliente"].ToString();
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaDomicilioCliente_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaDomicilioCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaDomicilioCliente.Rows[e.RowIndex];
                idDomicilio = int.Parse(row.Cells[0].Value.ToString());
                txtDomCliente.Text = row.Cells[2].Value.ToString();
            }
        }

        /*
            Verifica si un domicilio específico ya existe para un cliente.
         */
        public bool DomicilioExiste(string domicilio)
        {
            nuevaConexion.AbrirConexion();
            string query = "SELECT COUNT(*) FROM Comercial.DomicilioCliente WHERE idCliente = @IdCliente AND domicilioCliente = @Domicilio";
            SqlCommand cmd = new SqlCommand(query, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdCliente", idCliente);
            cmd.Parameters.AddWithValue("@Domicilio", domicilio);

            int count = (int)cmd.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            return count > 0;
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Comercial.DomicilioCliente con los datos ingresados.
            Si ocurre un error (como duplicación de un domicilio), muestra un mensaje de error.
         */
        public void InsertaDato()
        {
            string domicilioCliente = txtDomCliente.Text;

            if (DomicilioExiste(domicilioCliente))
            {
                MessageBox.Show("El domicilio ya existe para este cliente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            nuevaConexion.AbrirConexion();

            // Cadena SQL para agregar un nuevo registro en la tabla Comercial.DomicilioCliente.
            string InsertInfo = "INSERT INTO Comercial.DomicilioCliente(idCliente, domicilioCliente)" +
                "VALUES(@IdCliente, @DomCliente)";
            SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
            cm.Parameters.AddWithValue("@IdCliente", idCliente);
            cm.Parameters.AddWithValue("@DomCliente", domicilioCliente);
            cm.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Comercial.DomicilioCliente con los datos actualizados.
            Si ocurre un error (como duplicación de un domicilio), muestra un mensaje de error.
         */
        public void ModificaDato()
        {
            string domicilioCliente = txtDomCliente.Text;

            if (DomicilioExiste(domicilioCliente))
            {
                MessageBox.Show("El domicilio ya existe para este cliente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            nuevaConexion.AbrirConexion();

            // Cadena SQL para modificar un nuevo registro en la tabla Comercial.DomicilioCliente.
            string update = "UPDATE Comercial.DomicilioCliente SET idCliente = @idCliente, domicilioCliente = @DomicilioCliente WHERE idDomicilio = @Id";
            SqlCommand cmd = new SqlCommand(update, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@idCliente", idCliente);
            cmd.Parameters.AddWithValue("@domicilioCliente", domicilioCliente);
            cmd.Parameters.AddWithValue("@Id", idDomicilio);
            cmd.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Comercial.DomicilioCliente con los datos actualizados.
            Si existe un servicio ya asociado a dicho domicilio, muestra un mensaje de error. 
         */
        public void EliminaDato()
        {
            try
            {
                if (idDomicilio != -1)
                {
                    nuevaConexion.AbrirConexion();

                    // Cadena SQL para eliminar un nuevo registro en la tabla Comercial.DomicilioCliente.
                    string delete = "DELETE FROM Comercial.DomicilioCliente WHERE idDomicilio = @Id";
                    SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
                    cmd.Parameters.AddWithValue("@Id", idDomicilio);
                    cmd.ExecuteNonQuery();

                    string checkEmptyQuery = "SELECT COUNT(*) FROM Comercial.DomicilioCliente";
                    SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion.AbrirConexion());
                    int rowCount = (int)checkCmd.ExecuteScalar();

                    // Reinicia el valor del idCliente cuando la cantidad de filas es igual a 0.
                    if (rowCount == 0)
                    {
                        string resetIdentityQuery = "DBCC CHECKIDENT ('Comercial.DomicilioCliente', RESEED, 0)";
                        SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion.AbrirConexion());
                        resetCmd.ExecuteNonQuery();
                    }
                    nuevaConexion.CerrarConexion();
                }
            }
            catch
            {
                MessageBox.Show("Existe al menos un servicio asociado a dicho domicilio.");
            }
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtDomCliente.Clear();
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtDomCliente.Clear();
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtDomCliente.Clear();
        }
    }
}