﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario Trabajador.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace ServiciosDeMantenimiento
{
    /*
        Clase para gestionar el manejo de los trabajadores dentro de los Servicios de Mantenimiento
        Proporciona métodos para consultar, insertar, modificar y eliminar datos.
     */
    public partial class Trabajador : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idTrabajador = -1;
        string nombreTrabajador = "";
        string RFCTrabajador = "";
        string telefonoTrabajador = "";
        string emailTrabajador = "";

        //Lista que almacena objetos de tipo DetalleTrabajador.
        private List<DetalleTrabajador> detalleTrabajadorForms = new List<DetalleTrabajador>();

        /* 
            Constructor del formulario Trabajador.
            Inicializa el formulario y carga los datos de la tabla Trabajador en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public Trabajador()
        {
            InitializeComponent();
            ConsultaDatos();
            TablaTrabajador.CellClick += TablaTrabajador_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Operativo.Trabajador en el DataGridView.
            Formatea las columnas y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaTrabajador.DataSource = null;

            // Cadena SQL para consultar la tabla Operativo.Trabajador.
            string selectInfo = "SELECT * FROM Operativo.Trabajador";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaTrabajador si es que no contiene columnas.
            if (TablaTrabajador.Columns.Count == 0)
            {
                TablaTrabajador.Columns.Add("idTrabajador", "ID");
                TablaTrabajador.Columns.Add("nombreTrabajador", "Nombre del trabajador");
                TablaTrabajador.Columns.Add("RFCTrabajador", "RFC del trabajador");
                TablaTrabajador.Columns.Add("telefonoTrabajador", "Teléfono del trabajador");
                TablaTrabajador.Columns.Add("emailTrabajador", "Email del trabajador");
            }

            TablaTrabajador.Rows.Clear();
            int i = 0;

            // Agrega a TablaTrabajador una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                TablaTrabajador.Rows.Add();
                TablaTrabajador.Rows[i].Cells[0].Value = reader["idTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[1].Value = reader["nombreTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[2].Value = reader["RFCTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[3].Value = reader["telefonoTrabajador"].ToString();
                TablaTrabajador.Rows[i].Cells[4].Value = reader["emailTrabajador"].ToString();
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaTrabajador_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaTrabajador_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaTrabajador.Rows[e.RowIndex];
                idTrabajador = int.Parse(row.Cells[0].Value.ToString());
                txtNombre_Trabajador.Text = row.Cells[1].Value.ToString();
                txtRFC_Trabajador.Text = row.Cells[2].Value.ToString();
                txtTelefono_Trabajador.Text = row.Cells[3].Value.ToString();
                txtEmail_Trabajador.Text = row.Cells[4].Value.ToString();

                // Hace visible al botón btnDetalleTrabajador.
                btnDetalleTrabajador.Visible = true;
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Operativo.Trabajador con los datos ingresados.
            Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
         */
        public void InsertaDato()
        {
            nombreTrabajador = txtNombre_Trabajador.Text;
            RFCTrabajador = txtRFC_Trabajador.Text;
            telefonoTrabajador = txtTelefono_Trabajador.Text;
            emailTrabajador = txtEmail_Trabajador.Text;

            nuevaConexion.AbrirConexion();

            //Verifica si el RFC, el teléfono o el correo electrónico ya existen.
            string verifica = "SELECT COUNT(*) FROM Operativo.Trabajador WHERE RFCTrabajador=@RFC OR telefonoTrabajador = @Telefono OR emailTrabajador = @Email";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion.AbrirConexion());
            checkCmd.Parameters.AddWithValue("@RFC", RFCTrabajador);
            checkCmd.Parameters.AddWithValue("@Telefono", telefonoTrabajador);
            checkCmd.Parameters.AddWithValue("@Email", emailTrabajador);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El RFC, el teléfono o el correo electrónico ya están en uso.");
            }
            else
            {
                // Cadena SQL para agregar un nuevo registro en la tabla Operativo.Trabajador.
                string InsertInfo = "INSERT INTO Operativo.Trabajador(nombreTrabajador, RFCTrabajador, telefonoTrabajador, emailTrabajador) " +
                "VALUES ('" + nombreTrabajador + "', '" + RFCTrabajador + "', '" + telefonoTrabajador + "', '" + emailTrabajador + "')";
                SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
                cm.ExecuteNonQuery();
            }

            nuevaConexion.CerrarConexion();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Operativo.Trabajador con los datos actualizados.
            Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
         */
        public void ModificaDato()
        {
            nombreTrabajador = txtNombre_Trabajador.Text;
            RFCTrabajador = txtRFC_Trabajador.Text;
            telefonoTrabajador = txtTelefono_Trabajador.Text;
            emailTrabajador = txtEmail_Trabajador.Text;

            nuevaConexion.AbrirConexion();

            //Verifica si el RFC, el teléfono o el correo electrónico ya existen.
            string verifica = "SELECT COUNT(*) FROM Operativo.Trabajador WHERE RFCTrabajador=@RFC OR telefonoTrabajador = @Telefono OR emailTrabajador = @Email";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion.AbrirConexion());
            checkCmd.Parameters.AddWithValue("@RFC", RFCTrabajador);
            checkCmd.Parameters.AddWithValue("@Telefono", telefonoTrabajador);
            checkCmd.Parameters.AddWithValue("@Email", emailTrabajador);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El RFC, el teléfono o el correo electrónico ya están en uso.");
            }
            else
            {
                // Cadena SQL para modificar un nuevo registro en la tabla Operativo.Trabajador.
                string update = "UPDATE Operativo.Trabajador SET nombreTrabajador = @Nombre, RFCTrabajador = @RFC ,telefonoTrabajador = @Telefono, emailTrabajador = @Email " +
                "WHERE idTrabajador = @Id";
                SqlCommand cmd = new SqlCommand(update, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Nombre", nombreTrabajador);
                cmd.Parameters.AddWithValue("@RFC", RFCTrabajador);
                cmd.Parameters.AddWithValue("@Telefono", telefonoTrabajador);
                cmd.Parameters.AddWithValue("@Email", emailTrabajador);
                cmd.Parameters.AddWithValue("@Id", idTrabajador);
                cmd.ExecuteNonQuery();
                nuevaConexion.CerrarConexion();
            }
            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Operativo.Trabajador con los datos actualizados.
         */
        public void EliminaDato()
        {
            if (idTrabajador != -1)
            {
                nuevaConexion.AbrirConexion();

                // Cadena SQL para eliminar un nuevo registro en la tabla Operativo.Trabajador.
                string delete = "DELETE FROM Operativo.Trabajador WHERE idTrabajador = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Id", idTrabajador);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Operativo.Trabajador";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion.AbrirConexion());
                int rowCount = (int)checkCmd.ExecuteScalar();

                // Reinicia el valor del idTrabajador cuando la cantidad de filas es igual a 0.
                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Operativo.Trabajador', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion.AbrirConexion());
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.CerrarConexion();
            }
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtNombre_Trabajador.Clear();
            txtRFC_Trabajador.Clear();
            txtTelefono_Trabajador.Clear();
            txtEmail_Trabajador.Clear();
            idTrabajador = -1;
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtNombre_Trabajador.Clear();
            txtRFC_Trabajador.Clear();
            txtTelefono_Trabajador.Clear();
            txtEmail_Trabajador.Clear();
            idTrabajador = -1;
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtNombre_Trabajador.Clear();
            txtRFC_Trabajador.Clear();
            txtTelefono_Trabajador.Clear();
            txtEmail_Trabajador.Clear();
            idTrabajador = -1;
        }

        /*
            Evento que se dispara al hacer clic en el botón de Detalle del Trabajador.
            Abre el formulario DetalleTrabajador para gestionar los detalles asociados a un trabajador específico.
         */
        private void btnDetalleTrabajador_Click(object sender, EventArgs e)
        {
            if (idTrabajador != -1)
            {
                DetalleTrabajador detalleTrabajadorForm = new DetalleTrabajador(idTrabajador);
                detalleTrabajadorForms.Add(detalleTrabajadorForm);
                detalleTrabajadorForm.Show();
                txtNombre_Trabajador.Clear();
                txtRFC_Trabajador.Clear();
                txtTelefono_Trabajador.Clear();
                txtEmail_Trabajador.Clear();
                idTrabajador = -1;
            }
        }
    }
}
