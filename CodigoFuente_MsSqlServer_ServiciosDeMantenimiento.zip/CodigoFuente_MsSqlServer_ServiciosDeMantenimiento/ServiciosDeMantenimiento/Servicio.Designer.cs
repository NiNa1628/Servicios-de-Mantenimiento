﻿namespace ServiciosDeMantenimiento
{
    partial class Servicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpFech_Fin = new System.Windows.Forms.DateTimePicker();
            this.dtpFech_Ini = new System.Windows.Forms.DateTimePicker();
            this.dtpFech_Cot = new System.Windows.Forms.DateTimePicker();
            this.cmbBoxDomicilio = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TablaServicio = new System.Windows.Forms.DataGridView();
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnInserta = new System.Windows.Forms.Button();
            this.btnTrabajador = new System.Windows.Forms.Button();
            this.btnMaterial = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TablaServicio)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(301, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(202, 25);
            this.label3.TabIndex = 36;
            this.label3.Text = "Fecha de Finalización";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(306, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 25);
            this.label2.TabIndex = 35;
            this.label2.Text = "Fecha de Cotización:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(353, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 25);
            this.label1.TabIndex = 34;
            this.label1.Text = "Fecha de Inicio:";
            // 
            // dtpFech_Fin
            // 
            this.dtpFech_Fin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFech_Fin.Location = new System.Drawing.Point(520, 121);
            this.dtpFech_Fin.Name = "dtpFech_Fin";
            this.dtpFech_Fin.Size = new System.Drawing.Size(355, 27);
            this.dtpFech_Fin.TabIndex = 33;
            // 
            // dtpFech_Ini
            // 
            this.dtpFech_Ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFech_Ini.Location = new System.Drawing.Point(520, 83);
            this.dtpFech_Ini.Name = "dtpFech_Ini";
            this.dtpFech_Ini.Size = new System.Drawing.Size(355, 27);
            this.dtpFech_Ini.TabIndex = 32;
            // 
            // dtpFech_Cot
            // 
            this.dtpFech_Cot.Enabled = false;
            this.dtpFech_Cot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFech_Cot.Location = new System.Drawing.Point(519, 44);
            this.dtpFech_Cot.Name = "dtpFech_Cot";
            this.dtpFech_Cot.Size = new System.Drawing.Size(355, 27);
            this.dtpFech_Cot.TabIndex = 31;
            this.dtpFech_Cot.TabStop = false;
            // 
            // cmbBoxDomicilio
            // 
            this.cmbBoxDomicilio.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBoxDomicilio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBoxDomicilio.FormattingEnabled = true;
            this.cmbBoxDomicilio.Location = new System.Drawing.Point(519, 6);
            this.cmbBoxDomicilio.Name = "cmbBoxDomicilio";
            this.cmbBoxDomicilio.Size = new System.Drawing.Size(494, 28);
            this.cmbBoxDomicilio.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(285, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(218, 25);
            this.label4.TabIndex = 29;
            this.label4.Text = "Seleccione el Domicilio:";
            // 
            // TablaServicio
            // 
            this.TablaServicio.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.TablaServicio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaServicio.Location = new System.Drawing.Point(12, 221);
            this.TablaServicio.Name = "TablaServicio";
            this.TablaServicio.RowHeadersWidth = 51;
            this.TablaServicio.RowTemplate.Height = 24;
            this.TablaServicio.Size = new System.Drawing.Size(1098, 260);
            this.TablaServicio.TabIndex = 28;
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(705, 166);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 27;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(512, 166);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 26;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(321, 166);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 25;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click);
            // 
            // btnTrabajador
            // 
            this.btnTrabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnTrabajador.Location = new System.Drawing.Point(661, 492);
            this.btnTrabajador.Name = "btnTrabajador";
            this.btnTrabajador.Size = new System.Drawing.Size(127, 36);
            this.btnTrabajador.TabIndex = 38;
            this.btnTrabajador.Text = "Trabajador";
            this.btnTrabajador.UseVisualStyleBackColor = true;
            this.btnTrabajador.Visible = false;
            this.btnTrabajador.Click += new System.EventHandler(this.btnTrabajador_Click);
            // 
            // btnMaterial
            // 
            this.btnMaterial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnMaterial.Location = new System.Drawing.Point(334, 492);
            this.btnMaterial.Name = "btnMaterial";
            this.btnMaterial.Size = new System.Drawing.Size(116, 36);
            this.btnMaterial.TabIndex = 37;
            this.btnMaterial.Text = "Material";
            this.btnMaterial.UseVisualStyleBackColor = true;
            this.btnMaterial.Visible = false;
            this.btnMaterial.Click += new System.EventHandler(this.btnMaterial_Click);
            // 
            // Servicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 545);
            this.Controls.Add(this.btnTrabajador);
            this.Controls.Add(this.btnMaterial);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpFech_Fin);
            this.Controls.Add(this.dtpFech_Ini);
            this.Controls.Add(this.dtpFech_Cot);
            this.Controls.Add(this.cmbBoxDomicilio);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TablaServicio);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Name = "Servicio";
            this.Text = "Servicio";
            ((System.ComponentModel.ISupportInitialize)(this.TablaServicio)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpFech_Fin;
        private System.Windows.Forms.DateTimePicker dtpFech_Ini;
        private System.Windows.Forms.DateTimePicker dtpFech_Cot;
        private System.Windows.Forms.ComboBox cmbBoxDomicilio;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView TablaServicio;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnInserta;
        private System.Windows.Forms.Button btnTrabajador;
        private System.Windows.Forms.Button btnMaterial;
    }
}