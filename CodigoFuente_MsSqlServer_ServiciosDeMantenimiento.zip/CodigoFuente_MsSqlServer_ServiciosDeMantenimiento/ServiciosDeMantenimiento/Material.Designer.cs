﻿namespace ServiciosDeMantenimiento
{
    partial class Material
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region  Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.TablaMaterial = new System.Windows.Forms.DataGridView();
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnInserta = new System.Windows.Forms.Button();
            this.cmbBoxTipo_Material = new System.Windows.Forms.ComboBox();
            this.txtPrecio_Material = new System.Windows.Forms.TextBox();
            this.txtExistencia = new System.Windows.Forms.TextBox();
            this.txtNombre_Material = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TablaMaterial)).BeginInit();
            this.SuspendLayout();
            // 
            // TablaMaterial
            // 
            this.TablaMaterial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaMaterial.Location = new System.Drawing.Point(12, 233);
            this.TablaMaterial.Name = "TablaMaterial";
            this.TablaMaterial.RowHeadersWidth = 51;
            this.TablaMaterial.RowTemplate.Height = 24;
            this.TablaMaterial.Size = new System.Drawing.Size(739, 260);
            this.TablaMaterial.TabIndex = 24;
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(518, 186);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 23;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click_1);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(325, 186);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 22;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click_1);
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(134, 186);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 21;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click_1);
            // 
            // cmbBoxTipo_Material
            // 
            this.cmbBoxTipo_Material.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBoxTipo_Material.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cmbBoxTipo_Material.FormattingEnabled = true;
            this.cmbBoxTipo_Material.Items.AddRange(new object[] {
            "Plomeria",
            "Reconstrucción",
            "Electricidad"});
            this.cmbBoxTipo_Material.Location = new System.Drawing.Point(338, 51);
            this.cmbBoxTipo_Material.Name = "cmbBoxTipo_Material";
            this.cmbBoxTipo_Material.Size = new System.Drawing.Size(281, 33);
            this.cmbBoxTipo_Material.TabIndex = 20;
            // 
            // txtPrecio_Material
            // 
            this.txtPrecio_Material.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtPrecio_Material.Location = new System.Drawing.Point(338, 93);
            this.txtPrecio_Material.Name = "txtPrecio_Material";
            this.txtPrecio_Material.Size = new System.Drawing.Size(281, 30);
            this.txtPrecio_Material.TabIndex = 19;
            // 
            // txtExistencia
            // 
            this.txtExistencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtExistencia.Location = new System.Drawing.Point(338, 132);
            this.txtExistencia.Name = "txtExistencia";
            this.txtExistencia.Size = new System.Drawing.Size(281, 30);
            this.txtExistencia.TabIndex = 18;
            // 
            // txtNombre_Material
            // 
            this.txtNombre_Material.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombre_Material.Location = new System.Drawing.Point(338, 10);
            this.txtNombre_Material.Name = "txtNombre_Material";
            this.txtNombre_Material.Size = new System.Drawing.Size(281, 30);
            this.txtNombre_Material.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(129, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 25);
            this.label4.TabIndex = 16;
            this.label4.Text = "Tipo del material:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(129, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "Precio del material:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(129, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 25);
            this.label2.TabIndex = 14;
            this.label2.Text = "Existencias:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(129, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Nombre del material:";
            // 
            // Material
            // 
            this.ClientSize = new System.Drawing.Size(774, 505);
            this.Controls.Add(this.TablaMaterial);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Controls.Add(this.cmbBoxTipo_Material);
            this.Controls.Add(this.txtPrecio_Material);
            this.Controls.Add(this.txtExistencia);
            this.Controls.Add(this.txtNombre_Material);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Material";
            ((System.ComponentModel.ISupportInitialize)(this.TablaMaterial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView TablaMaterial;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnInserta;
        private System.Windows.Forms.ComboBox cmbBoxTipo_Material;
        private System.Windows.Forms.TextBox txtPrecio_Material;
        private System.Windows.Forms.TextBox txtExistencia;
        private System.Windows.Forms.TextBox txtNombre_Material;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}