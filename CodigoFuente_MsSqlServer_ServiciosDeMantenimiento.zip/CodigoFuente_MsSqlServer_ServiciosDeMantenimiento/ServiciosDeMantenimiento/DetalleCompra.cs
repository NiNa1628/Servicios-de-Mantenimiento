﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario DetalleCompra.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
       Clase para gestionar el manejo de los detalles de las compras dentro de los Servicios de Mantenimiento
       Proporciona métodos para consultar, insertar, modificar y eliminar datos.
    */
    public partial class DetalleCompra : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idCompra;
        string idMaterial = "";
        string cantidad;
        float subtotal;

        // Define un evento llamado SubtotalChanged el cual se utiliza para notificar cuando ocurre un cambio en el subtotal de una compra.
        public event EventHandler SubtotalChanged;

        /* 
            Constructor del formulario DetalleCompra.
            Inicializa el formulario y carga los datos de la tabla DetalleCompra en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public DetalleCompra(int idCompra)
        {
            InitializeComponent();
            this.idCompra = idCompra;
            ConsultaDatos();
            CargarMateriales();
            TablaDetalleCompra.CellClick += TablaDetalleCompra_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Comercial.DetalleCompra en el DataGridView.
            Formatea las columnas y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaDetalleCompra.DataSource = null;

            // Cadena SQL para consultar la tabla Comercial.DetalleCompra.
            string selectInfo = "SELECT d.idCompra, d.idMaterial, d.cantidad, d.subtotal, " +
                    "m.NombreMaterial, m.TipoMaterial " +
                    "FROM Comercial.DetalleCompra d " +
                    "JOIN Operativo.Material m ON d.idMaterial = m.idMaterial " +  // Notice the space added here
                    "WHERE d.idCompra = @IdCompra";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdCompra", idCompra);
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaDetalleCompra si es que no contiene columnas.
            if (TablaDetalleCompra.Columns.Count == 0)
            {
                TablaDetalleCompra.Columns.Add("idCompra", "Compra");
                TablaDetalleCompra.Columns.Add("idMaterial", "Material");
                TablaDetalleCompra.Columns.Add("cantidad", "Cantidad");
                TablaDetalleCompra.Columns.Add("subtotal", "subtotal");

                TablaDetalleCompra.Columns["subtotal"].DefaultCellStyle.Format = "N2";
            }

            TablaDetalleCompra.Rows.Clear();
            int i = 0;

            // Agrega a TablaDetalleCompra una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                string nombreMaterial = reader["NombreMaterial"].ToString();
                string tipoMaterial = reader["TipoMaterial"].ToString();
                string material = $"{nombreMaterial} - {tipoMaterial}";

                TablaDetalleCompra.Rows.Add();
                TablaDetalleCompra.Rows[i].Cells[0].Value = reader["idCompra"].ToString();
                TablaDetalleCompra.Rows[i].Cells[1].Value = material;
                TablaDetalleCompra.Rows[i].Cells[2].Value = Convert.ToInt64(reader["cantidad"]).ToString();
                TablaDetalleCompra.Rows[i].Cells[3].Value = Convert.ToDecimal(reader["subtotal"]).ToString("N2");
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            Carge la información de la tabla Operativo.Material y la muestra en un combobox.
         */
        public void CargarMateriales()
        {
            nuevaConexion.AbrirConexion();
            string selectInfo = "SELECT NombreMaterial, TipoMaterial FROM Operativo.Material";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            cmb_Material.Items.Clear();

            // Lee cada material del resultado de la consulta
            while (reader.Read())
            {
                string nombreMaterial = reader["NombreMaterial"].ToString();
                string tipoMaterial = reader["TipoMaterial"].ToString();
                string material = $"{nombreMaterial} - {tipoMaterial}";

                // Agrega el resultado al combo box
                cmb_Material.Items.Add(material);
            }

            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaDetalleCompra_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaDetalleCompra_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaDetalleCompra.Rows[e.RowIndex];
                txtCantidad.Text = row.Cells[2].Value.ToString();
                cmb_Material.Text = row.Cells[1].Value.ToString();
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Comercial.DetalleCompra con los datos ingresados.
         */
        public void InsertaDato()
        {
            cantidad = txtCantidad.Text;
            string materialSeleccionado = cmb_Material.Text;
            string[] partesMaterial = materialSeleccionado.Split('-');
            string nombreMaterial = partesMaterial[0].Trim();
            string tipoMaterial = partesMaterial[1].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del material.
            string queryIdMaterial = "SELECT idMaterial FROM Operativo.Material WHERE NombreMaterial = @Nombre AND TipoMaterial = @Tipo";
            SqlCommand cmdIdMaterial = new SqlCommand(queryIdMaterial, nuevaConexion.AbrirConexion());
            cmdIdMaterial.Parameters.AddWithValue("@Nombre", nombreMaterial);
            cmdIdMaterial.Parameters.AddWithValue("@Tipo", tipoMaterial);
            idMaterial = cmdIdMaterial.ExecuteScalar()?.ToString();
            nuevaConexion.CerrarConexion();

            nuevaConexion.AbrirConexion();

            // Cadena SQL para agregar un nuevo registro en la tabla Comercial.DetalleCompra.
            string InsertInfo = "INSERT INTO Comercial.DetalleCompra(idCompra, idMaterial, cantidad) " +
                                "VALUES (@IdCompra, @IdMaterial, @Cantidad)";
            SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
            cm.Parameters.AddWithValue("@IdCompra", idCompra);
            cm.Parameters.AddWithValue("@IdMaterial", idMaterial);
            cm.Parameters.AddWithValue("@Cantidad", cantidad);
            cm.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();

            // Notificar que se ha actualizado.
            OnDetalleCompraUpdated();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Comercial.Compra con los datos actualizados.     
         */
        public void ModificaDato()
        {
            cantidad = txtCantidad.Text;
            string materialSeleccionado = cmb_Material.Text;
            string[] partesMaterial = materialSeleccionado.Split('-');
            string nombreMaterial = partesMaterial[0].Trim();
            string tipoMaterial = partesMaterial[1].Trim();
            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del material.
            string queryIdMaterial = "SELECT idMaterial FROM Operativo.Material WHERE NombreMaterial = @Nombre AND TipoMaterial = @Tipo";
            SqlCommand cmdIdMaterial = new SqlCommand(queryIdMaterial, nuevaConexion.AbrirConexion());
            cmdIdMaterial.Parameters.AddWithValue("@Nombre", nombreMaterial);
            cmdIdMaterial.Parameters.AddWithValue("@Tipo", tipoMaterial);
            idMaterial = cmdIdMaterial.ExecuteScalar()?.ToString();
            nuevaConexion.CerrarConexion();

            int cant = int.Parse(cantidad);
            nuevaConexion.AbrirConexion();

            // Cadena SQL para modificar un nuevo registro en la tabla Comercial.DetalleCompra.
            string updateQuery = "UPDATE Comercial.DetalleCompra SET cantidad = @Cantidad WHERE idCompra = @IdCompra AND idMaterial = @IdMaterial";
            SqlCommand cmd = new SqlCommand(updateQuery, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@Cantidad", cantidad);
            cmd.Parameters.AddWithValue("@IdCompra", idCompra);
            cmd.Parameters.AddWithValue("@IdMaterial", idMaterial);
            cmd.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();

            // Notificar que se ha actualizado.
            OnDetalleCompraUpdated();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Comercial.Compra con los datos actualizados.
         */
        public void EliminaDato()
        {
            string materialSeleccionado = cmb_Material.Text;
            string[] partesMaterial = materialSeleccionado.Split('-');
            string nombreMaterial = partesMaterial[0].Trim();
            string tipoMaterial = partesMaterial[1].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del material. 
            string queryIdMaterial = "SELECT idMaterial FROM Operativo.Material WHERE NombreMaterial = @Nombre AND TipoMaterial = @Tipo";
            SqlCommand cmdIdMaterial = new SqlCommand(queryIdMaterial, nuevaConexion.AbrirConexion());
            cmdIdMaterial.Parameters.AddWithValue("@Nombre", nombreMaterial);
            cmdIdMaterial.Parameters.AddWithValue("@Tipo", tipoMaterial);
            idMaterial = cmdIdMaterial.ExecuteScalar()?.ToString();
            nuevaConexion.CerrarConexion();

            nuevaConexion.AbrirConexion();

            // Cadena SQL para eliminar un nuevo registro en la tabla Comercial.DetalleCompra.
            string delete = "DELETE FROM Comercial.DetalleCompra WHERE idCompra = @IdCompra AND idMaterial = @IdMaterial";
            SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdCompra", idCompra);
            cmd.Parameters.AddWithValue("@IdMaterial", idMaterial);
            cmd.ExecuteNonQuery();

            nuevaConexion.CerrarConexion();

            // Notificar que se ha actualizado.
            OnDetalleCompraUpdated();
        }

        /*
            Dispara el Evento para notificar el cambio del subtotal.
         */
        protected virtual void OnDetalleCompraUpdated()
        {
            SubtotalChanged?.Invoke(this, EventArgs.Empty);
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            cmb_Material.SelectedIndex = -1;
            txtCantidad.Clear();
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            cmb_Material.SelectedIndex = -1;
            txtCantidad.Clear();
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            cmb_Material.SelectedIndex = -1;
            txtCantidad.Clear();
        }
    }
}
