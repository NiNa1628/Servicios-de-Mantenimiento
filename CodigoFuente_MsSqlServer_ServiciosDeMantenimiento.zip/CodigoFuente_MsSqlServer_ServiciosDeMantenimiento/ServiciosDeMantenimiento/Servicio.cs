﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario Servicio.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
        Clase para gestionar el manejo de los servicio dentro de los Servicios de Mantenimiento
        Proporciona métodos para consultar, insertar, modificar y eliminar datos.
     */
    public partial class Servicio : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idServicio = -1;
        string idDomicilio = "";
        string fechaCotizacion = "";
        string fechaInicio = "";
        string fechaFinal = "";
        int duracion = 0;
        decimal costoFinal = 0;

        //Lista que almacena objetos de tipo MaterialXServicio.
        private List<MaterialXServicio> materialXServicioForms = new List<MaterialXServicio>();

        //Lista que almacena objetos de tipo TrabajadorXServicio.
        private List<TrabajadorXServicio> trabajadorXServicioForms = new List<TrabajadorXServicio>();

        /* 
            Constructor del formulario Servicio.
            Inicializa el formulario y carga los datos de la tabla Servicio en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public Servicio()
        {
            InitializeComponent();
            ConsultaDatos();
            CargarDomicilios();
            TablaServicio.CellClick += TablaServicio_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Comercial.Compra en el DataGridView.
            Formatea la columna de precios y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaServicio.DataSource = null;

            // Cadena SQL para consultar la tabla Operativo.Servicio. 
            string selectInfo = "SELECT s.idServicio, s.idDomicilio, s.fechaCotizacion, s.fechaInicio, s.fechaFinal, s.duracion, s.costoFinal, " +
                        "CONCAT(dc.domicilioCliente, ' (', c.nombreCliente, ')') AS DomicilioCliente " +
                        "FROM Operativo.Servicio s " +
                        "JOIN Comercial.DomicilioCliente dc ON s.idDomicilio = dc.idDomicilio " +
                        "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaServicio si es que no contiene columnas.
            if (TablaServicio.Columns.Count == 0)
            {
                TablaServicio.Columns.Add("idServicio", "ID");
                TablaServicio.Columns.Add("idDomicilio", "Domicilio");
                TablaServicio.Columns.Add("fechaCotizacion", "Fecha Cotizacion");
                TablaServicio.Columns.Add("fechaInicio", "Fecha Inicio");
                TablaServicio.Columns.Add("fechaFinal", "Fecha Finalización");
                TablaServicio.Columns.Add("duracion", "Duración");
                TablaServicio.Columns.Add("costoFinal", "Costo Final");

                TablaServicio.Columns["costoFinal"].DefaultCellStyle.Format = "N2";
            }

            TablaServicio.Rows.Clear();
            int i = 0;

            // Agrega a TablaServicio una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                string domicilioCliente = reader["DomicilioCliente"].ToString();
                int duracion = reader["duracion"] != DBNull.Value ? Convert.ToInt32(reader["duracion"]) + 1 : 1;
                decimal costoFinal = reader["costoFinal"] != DBNull.Value ? Convert.ToDecimal(reader["costoFinal"]) : 0;

                TablaServicio.Rows.Add();
                TablaServicio.Rows[i].Cells[0].Value = reader["idServicio"].ToString();
                TablaServicio.Rows[i].Cells[1].Value = domicilioCliente;
                TablaServicio.Rows[i].Cells[2].Value = Convert.ToDateTime(reader["fechaCotizacion"]).ToString("yyyy-MM-dd");
                TablaServicio.Rows[i].Cells[3].Value = Convert.ToDateTime(reader["fechaInicio"]).ToString("yyyy-MM-dd");
                TablaServicio.Rows[i].Cells[4].Value = Convert.ToDateTime(reader["fechaFinal"]).ToString("yyyy-MM-dd"); ;
                TablaServicio.Rows[i].Cells[5].Value = duracion.ToString();
                TablaServicio.Rows[i].Cells[6].Value = costoFinal.ToString("N2");
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            Carge la información de la tabla Comercial.Cliente y Comercial.DomicilioCliente y la muestra en un combobox.
         */
        public void CargarDomicilios()
        {
            nuevaConexion.AbrirConexion();
            string selectInfo = "SELECT dc.domicilioCliente, c.nombreCliente " +
                                "FROM Comercial.DomicilioCliente dc " +
                                "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            cmbBoxDomicilio.Items.Clear();

            // Lee cada domicilio y cliente del resultado de la consulta
            while (reader.Read())
            {
                string domicilioCliente = reader["domicilioCliente"].ToString();
                string nombreCliente = reader["nombreCliente"].ToString();
                string domicilio = $"{domicilioCliente} ({nombreCliente})";

                // Agrega el resultado al combo box
                cmbBoxDomicilio.Items.Add(domicilio);
            }

            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaServicio_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        public void TablaServicio_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaServicio.Rows[e.RowIndex];
                idServicio = int.Parse(row.Cells[0].Value.ToString());
                cmbBoxDomicilio.Text = row.Cells[1].Value.ToString();
                dtpFech_Cot.Text = row.Cells[2].Value.ToString();
                dtpFech_Ini.Text = row.Cells[3].Value.ToString();
                dtpFech_Fin.Text = row.Cells[4].Value.ToString();

                // Hace visible al botón btnMaterial.
                btnMaterial.Visible = true;

                // Hace visible al botón btnTrabajador.
                btnTrabajador.Visible = true;
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Operativo.Servicio con los datos ingresados.
         */
        public void InsertaDato()
        {
            string domicilioSeleccionado = cmbBoxDomicilio.Text;
            string[] partesDomicilio = domicilioSeleccionado.Split('(');
            string domicilioCliente = partesDomicilio[0].Trim();
            string fechaCotizacion = dtpFech_Cot.Value.ToString("yyyy-MM-dd");
            string fechaInicio = dtpFech_Ini.Value.ToString("yyyy-MM-dd");
            string fechaFinal = dtpFech_Fin.Value.ToString("yyyy-MM-dd");

            // Validación de fechas
            if (dtpFech_Ini.Value < dtpFech_Cot.Value)
            {
                MessageBox.Show("La fecha de inicio no puede ser anterior a la fecha de cotización.", "Error de Fecha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dtpFech_Fin.Value < dtpFech_Ini.Value)
            {
                MessageBox.Show("La fecha de finalización no puede ser anterior a la fecha de inicio.", "Error de Fecha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string idDomicilio = "";
            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del domicilio.
            string queryIdDomicilio = "SELECT idDomicilio FROM Comercial.DomicilioCliente WHERE domicilioCliente = @Domicilio";

            using (SqlCommand cmdIdDomicilio = new SqlCommand(queryIdDomicilio, nuevaConexion.AbrirConexion()))
            {
                cmdIdDomicilio.Parameters.AddWithValue("@Domicilio", domicilioCliente);
                var result = cmdIdDomicilio.ExecuteScalar();

                if (result != null)
                    idDomicilio = result.ToString();
            }
            nuevaConexion.CerrarConexion();

            // Verificar si ya existe un servicio programado para este domicilio antes de la fecha de inicio seleccionada
            string queryCheckServicio = "SELECT COUNT(*) FROM Operativo.Servicio " +
                                        "WHERE idDomicilio = @IdDomicilio AND fechaFinal >= @FechaInicio";
            using (SqlCommand cmdCheckServicio = new SqlCommand(queryCheckServicio, nuevaConexion.AbrirConexion()))
            {
                cmdCheckServicio.Parameters.AddWithValue("@IdDomicilio", idDomicilio);
                cmdCheckServicio.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                int count = (int)cmdCheckServicio.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("No se puede programar un nuevo servicio para este domicilio hasta que el servicio actual finalice.");
                    nuevaConexion.CerrarConexion();
                    return;
                }
            }

            nuevaConexion.AbrirConexion();

            // Cadena SQL para agregar un nuevo registro en la tabla Operativo.Servicio.
            string insertInfo = "INSERT INTO Operativo.Servicio(idDomicilio, fechaCotizacion, fechaInicio, fechaFinal) " +
                                "VALUES (@IdDomicilio, @FechaCot, @FechaIni, @FechaFin)";
            using (SqlCommand cm = new SqlCommand(insertInfo, nuevaConexion.AbrirConexion()))
            {
                cm.Parameters.AddWithValue("@IdDomicilio", idDomicilio);
                cm.Parameters.AddWithValue("@FechaCot", fechaCotizacion);
                cm.Parameters.AddWithValue("@FechaIni", fechaInicio);
                cm.Parameters.AddWithValue("@FechaFin", fechaFinal);
                cm.ExecuteNonQuery();
            }
            nuevaConexion.CerrarConexion();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Operativo.Serivicio con los datos actualizados.     
         */
        public void ModificaDato()
        {
            string domicilioSeleccionado = cmbBoxDomicilio.Text;
            string idDomicilio = "";
            string fechaCotizacion = dtpFech_Cot.Value.ToString("yyyy-MM-dd");
            string fechaInicio = dtpFech_Ini.Value.ToString("yyyy-MM-dd");
            string fechaFinal = dtpFech_Fin.Value.ToString("yyyy-MM-dd");

            // Validación de fechas
            if (dtpFech_Ini.Value < dtpFech_Cot.Value)
            {
                MessageBox.Show("La fecha de inicio no puede ser anterior a la fecha de cotización.", "Error de Fecha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dtpFech_Fin.Value < dtpFech_Ini.Value)
            {
                MessageBox.Show("La fecha de finalización no puede ser anterior a la fecha de inicio.", "Error de Fecha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del domicilio.
            string queryIdDomicilio = "SELECT dc.idDomicilio FROM Comercial.DomicilioCliente dc " +
                                       "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente " +
                                       "WHERE CONCAT(dc.domicilioCliente, ' (', c.nombreCliente, ')') = @Domicilio";

            SqlCommand cmdIdDomicilio = new SqlCommand(queryIdDomicilio, nuevaConexion.AbrirConexion());
            cmdIdDomicilio.Parameters.AddWithValue("@Domicilio", domicilioSeleccionado);
            var result = cmdIdDomicilio.ExecuteScalar();
            if (result != null)
            {
                idDomicilio = result.ToString();
            }
            nuevaConexion.CerrarConexion();

            // Verificar si ya existe un servicio programado para este domicilio antes de la fecha de inicio seleccionada
            string queryCheckServicio = "SELECT COUNT(*) FROM Operativo.Servicio " +
                                        "WHERE idDomicilio = @IdDomicilio AND fechaFinal >= @FechaInicio";
            using (SqlCommand cmdCheckServicio = new SqlCommand(queryCheckServicio, nuevaConexion.AbrirConexion()))
            {
                cmdCheckServicio.Parameters.AddWithValue("@IdDomicilio", idDomicilio);
                cmdCheckServicio.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                int count = (int)cmdCheckServicio.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("No se puede programar un nuevo servicio para este domicilio hasta que el servicio actual finalice.");
                    nuevaConexion.CerrarConexion();
                    return;
                }
            }

            nuevaConexion.AbrirConexion();

            // Cadena SQL para actualizar un nuevo registro en la tabla Operativo.Servicio.
            string update = "UPDATE Operativo.Servicio SET idDomicilio = @IdDomicilio, fechaCotizacion = @FechaCot, " +
                            "fechaInicio = @FechaIni, fechaFinal = @FechaFin WHERE idServicio = @IdServicio";
            SqlCommand cmd = new SqlCommand(update, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdDomicilio", idDomicilio);
            cmd.Parameters.AddWithValue("@FechaCot", fechaCotizacion);
            cmd.Parameters.AddWithValue("@FechaIni", fechaInicio);
            cmd.Parameters.AddWithValue("@FechaFin", fechaFinal);
            cmd.Parameters.AddWithValue("@IdServicio", idServicio);
            cmd.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Operativo.Serivicio con los datos actualizados.
         */
        public void EliminaDato()
        {
            if (idServicio != -1)
            {
                nuevaConexion.AbrirConexion();

                // Eliminar primero los materiales por servicio.
                string deleteMaterialXServicio = "DELETE FROM Operativo.MaterialXServicio WHERE idServicio = @Id";
                SqlCommand cmdMaterialXServicio = new SqlCommand(deleteMaterialXServicio, nuevaConexion.AbrirConexion());
                cmdMaterialXServicio.Parameters.AddWithValue("@Id", idServicio);
                cmdMaterialXServicio.ExecuteNonQuery();

                // Eliminar primero los trabajadores por servicio.
                string deleteMaterialXTrabajador = "DELETE FROM Operativo.TrabajadorXServicio WHERE idServicio = @Id";
                SqlCommand cmdTrabajadorXServicio = new SqlCommand(deleteMaterialXTrabajador, nuevaConexion.AbrirConexion());
                cmdTrabajadorXServicio.Parameters.AddWithValue("@Id", idServicio);
                cmdTrabajadorXServicio.ExecuteNonQuery();

                // Cadena SQL para eliminar un nuevo registro en la tabla Comercial.Compra.
                string delete = "DELETE FROM Operativo.Servicio WHERE idServicio = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Id", idServicio);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Operativo.Servicio";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion.AbrirConexion());
                int rowCount = (int)checkCmd.ExecuteScalar();

                // Reinicia el valor del idServicio cuando la cantidad de filas es igual a 0.
                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Operativo.Servicio', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion.AbrirConexion());
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.CerrarConexion();
            }
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            cmbBoxDomicilio.SelectedIndex = -1;
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            cmbBoxDomicilio.SelectedIndex = -1;
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            cmbBoxDomicilio.SelectedIndex = -1;
        }

        /*
            Evento que se dispara al hacer clic en el botón de Taterial.
            Abre el formulario DetalleCompra para gestionar los materiales asociados a un servicio específico.
         */
        private void btnMaterial_Click(object sender, EventArgs e)
        {
            if (idServicio != -1)
            {
                MaterialXServicio materialXServicioForm = new MaterialXServicio(idServicio);
                materialXServicioForms.Add(materialXServicioForm);
                materialXServicioForm.SubtotalChanged += Form_SubtotalChanged;
                materialXServicioForm.FormClosed += (s, args) =>
                {
                    materialXServicioForms.Remove(materialXServicioForm);
                };
                materialXServicioForm.Show();
            }
        }

        /*
            Evento que se dispara al hacer clic en el botón de Trabajador.
            Abre el formulario DetalleCompra para gestionar los trabajadores asociados a un servicio específico.
         */
        private void btnTrabajador_Click(object sender, EventArgs e)
        {
            if (idServicio != -1)
            {
                TrabajadorXServicio trabajadorXServicioForm = new TrabajadorXServicio(idServicio);
                trabajadorXServicioForms.Add(trabajadorXServicioForm);
                trabajadorXServicioForm.SubtotalChanged += Form_SubtotalChanged;
                trabajadorXServicioForm.FormClosed += (s, args) =>
                {
                    trabajadorXServicioForms.Remove(trabajadorXServicioForm);
                };
                trabajadorXServicioForm.Show();
            }
        }

        /*
            Ejecuta el Evento el cual es disparado por una instancia de DetalleCompra.
         */
        private void Form_SubtotalChanged(object sender, EventArgs e)
        {
            ConsultaDatos();
        }
    }
}