﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario MarerialXServicio.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
       Clase para gestionar el manejo de los materiales de los servicios dentro de los Servicios de Mantenimiento
       Proporciona métodos para consultar, insertar, modificar y eliminar datos.
    */
    public partial class MaterialXServicio : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idServicio;
        string idMaterial = "";
        int material;
        string cantidad;
        float subtotalMaterial = 0;

        // Define un evento llamado SubtotalChanged el cual se utiliza para notificar cuando ocurre un cambio en el subtotal de un servicio.
        public event EventHandler SubtotalChanged;

        /* 
            Constructor del formulario MaterialXServicio.
            Inicializa el formulario y carga los datos de la tabla MaterialXServicio en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public MaterialXServicio(int idServicio)
        {
            InitializeComponent();
            this.idServicio = idServicio;
            ConsultaDatos();
            CargarMateriales();
            TablaMaterialXServicio.CellClick += TablaMaterialXServicio_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Operativo.MaterialXServicio en el DataGridView.
            Formatea la columna de precios y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaMaterialXServicio.DataSource = null;

            // Cadena SQL para consultar la tabla Operativo.MaterialXServicio. 
            string selectInfo = "SELECT s.idServicio, CONCAT(s.idServicio, ' - ', c.nombreCliente) AS ServicioCliente, " +
                                "mat.NombreMaterial, mat.TipoMaterial, m.cantMaterial, m.subtotalMaterial " +
                                "FROM Operativo.MaterialXServicio m " +
                                "JOIN Operativo.Servicio s ON m.idServicio = s.idServicio " +
                                "JOIN Comercial.DomicilioCliente dc ON s.idDomicilio = dc.idDomicilio " +
                                "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente " +
                                "JOIN Operativo.Material mat ON m.idMaterial = mat.idMaterial " +
                                "WHERE m.idServicio = @IdServicio";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdServicio", idServicio);
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaMaterialXServicio si es que no contiene columnas.
            if (TablaMaterialXServicio.Columns.Count == 0)
            {
                TablaMaterialXServicio.Columns.Add("ServicioCliente", "Servicio");
                TablaMaterialXServicio.Columns.Add("idMaterial", "Material");
                TablaMaterialXServicio.Columns.Add("cantMaterial", "Cantidad");
                TablaMaterialXServicio.Columns.Add("subtotalMaterial", "Subtotal");

                TablaMaterialXServicio.Columns["subtotalMaterial"].DefaultCellStyle.Format = "N2";
            }

            TablaMaterialXServicio.Rows.Clear();
            int i = 0;

            // Agrega a TablaMaterialXServicio una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                string servicioCliente = reader["ServicioCliente"].ToString();
                string nombreMaterial = reader["NombreMaterial"].ToString();
                string tipoMaterial = reader["TipoMaterial"].ToString();
                string material = $"{nombreMaterial} - {tipoMaterial}";
                decimal subtotalMaterial = reader["subtotalMaterial"] != DBNull.Value ? Convert.ToDecimal(reader["subtotalMaterial"]) : 0;

                TablaMaterialXServicio.Rows.Add();
                TablaMaterialXServicio.Rows[i].Cells[0].Value = servicioCliente;
                TablaMaterialXServicio.Rows[i].Cells[1].Value = material;
                TablaMaterialXServicio.Rows[i].Cells[2].Value = Convert.ToInt32(reader["cantMaterial"]).ToString();
                TablaMaterialXServicio.Rows[i].Cells[3].Value = subtotalMaterial.ToString("N2");
                i++;
            }

            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            Carge la información de la tabla Operativo.Material y la muestra en un combobox.
         */
        public void CargarMateriales()
        {
            nuevaConexion.AbrirConexion();
            string selectInfo = "SELECT NombreMaterial, TipoMaterial FROM Operativo.Material";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            cmb_Material.Items.Clear();

            // Lee cada material del resultado de la consulta
            while (reader.Read())
            {
                string nombreMaterial = reader["NombreMaterial"].ToString();
                string tipoMaterial = reader["TipoMaterial"].ToString();
                string material = $"{nombreMaterial} - {tipoMaterial}";

                // Agrega el resultado al combo box
                cmb_Material.Items.Add(material);
            }

            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaMaterialXServicio_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaMaterialXServicio_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaMaterialXServicio.Rows[e.RowIndex];
                cmb_Material.Text = row.Cells[1].Value.ToString();
                txtCantidad.Text = row.Cells[2].Value.ToString();
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Operativo.MaterialXServicio con los datos ingresados.
         */
        public void InsertaDato()
        {
            cantidad = txtCantidad.Text;
            string materialSeleccionado = cmb_Material.Text;
            string[] partesMaterial = materialSeleccionado.Split('-');
            string nombreMaterial = partesMaterial[0].Trim();
            string tipoMaterial = partesMaterial[1].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del material.
            string queryIdMaterial = "SELECT idMaterial, existencia FROM Operativo.Material WHERE NombreMaterial = @Nombre AND TipoMaterial = @Tipo";
            SqlCommand cmdIdMaterial = new SqlCommand(queryIdMaterial, nuevaConexion.AbrirConexion());
            cmdIdMaterial.Parameters.AddWithValue("@Nombre", nombreMaterial);
            cmdIdMaterial.Parameters.AddWithValue("@Tipo", tipoMaterial);
            SqlDataReader reader = cmdIdMaterial.ExecuteReader();

            if (reader.Read())
            {
                idMaterial = reader["idMaterial"].ToString();
                int existencia = Convert.ToInt32(reader["existencia"]);
                reader.Close();
                nuevaConexion.CerrarConexion();

                int cant = int.Parse(cantidad);
                
                //Verifica la existencia del material para el servicio.
                if (cant > existencia)
                {
                    MessageBox.Show("No hay suficiente existencia del material seleccionado.");
                    return;
                }

                nuevaConexion.AbrirConexion();

                // Verificar si ya existe un material para este servicio.
                string verificarMaterial = "SELECT COUNT(*) FROM Operativo.MaterialXServicio WHERE idServicio = @IdServicio AND idMaterial = @IdMaterial";
                SqlCommand cmdVverificarMaterial = new SqlCommand(verificarMaterial, nuevaConexion.AbrirConexion());
                cmdVverificarMaterial.Parameters.AddWithValue("@IdServicio", idServicio);
                cmdVverificarMaterial.Parameters.AddWithValue("@IdMaterial", idMaterial);

                int count = (int)cmdVverificarMaterial.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("El material ya está asociado a este servicio.");
                    return;
                }

                nuevaConexion.AbrirConexion();

                // Cadena SQL para agregar un nuevo registro en la tabla Operativo.MaterialXServicio.
                string InsertInfo = "INSERT INTO Operativo.MaterialXServicio(idServicio, idMaterial, cantMaterial) " +
                       "VALUES (@IdServicio, @IdMaterial, @Cantidad)";

                SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
                cm.Parameters.AddWithValue("@IdServicio", idServicio);
                cm.Parameters.AddWithValue("@IdMaterial", idMaterial);
                cm.Parameters.AddWithValue("@Cantidad", cantidad);
                cm.ExecuteNonQuery();
                nuevaConexion.CerrarConexion();

                // Notificar que se ha actualizado.
                OnMaterialXServicioUpdated();
            }
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Operativo.MaterialXServicio con los datos actualizados.     
         */
        public void ModificaDato()
        {
            cantidad = txtCantidad.Text;
            string materialSeleccionado = cmb_Material.Text;
            string[] partesMaterial = materialSeleccionado.Split('-');
            string nombreMaterial = partesMaterial[0].Trim();
            string tipoMaterial = partesMaterial[1].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del material.
            string queryIdMaterial = "SELECT idMaterial, existencia FROM Operativo.Material WHERE NombreMaterial = @Nombre AND TipoMaterial = @Tipo";
            SqlCommand cmdIdMaterial = new SqlCommand(queryIdMaterial, nuevaConexion.AbrirConexion());
            cmdIdMaterial.Parameters.AddWithValue("@Nombre", nombreMaterial);
            cmdIdMaterial.Parameters.AddWithValue("@Tipo", tipoMaterial);
            SqlDataReader reader = cmdIdMaterial.ExecuteReader();

            if (reader.Read())
            {
                idMaterial = reader["idMaterial"].ToString();
                int existencia = Convert.ToInt32(reader["existencia"]);
                reader.Close();
                nuevaConexion.CerrarConexion();

                int cant = int.Parse(cantidad);
                nuevaConexion.AbrirConexion();

                //Verifica la existencia del material para el servicio.
                if (cant > existencia)
                {
                    MessageBox.Show("No hay suficiente existencia del material seleccionado.");
                    return;
                }

                string verificarMaterial = "SELECT COUNT(*) FROM Operativo.MaterialXServicio WHERE idServicio = @IdServicio AND idMaterial = @IdMaterial";
                SqlCommand cmdVerificarMaterial = new SqlCommand(verificarMaterial, nuevaConexion.AbrirConexion());
                cmdVerificarMaterial.Parameters.AddWithValue("@IdServicio", idServicio);
                cmdVerificarMaterial.Parameters.AddWithValue("@IdMaterial", idMaterial);

                int count = (int)cmdVerificarMaterial.ExecuteScalar();
                nuevaConexion.CerrarConexion();

                if (count == 0)
                {
                    MessageBox.Show("El material no está asociado a este servicio. No se puede modificar.");
                    return;
                }

                nuevaConexion.AbrirConexion();

                // Cadena SQL para modificar un nuevo registro en la tabla Operativo.MaterialXServicio.
                string updateQuery = "UPDATE Operativo.MaterialXServicio SET cantMaterial = @Cantidad WHERE idServicio = @IdServicio AND idMaterial = @IdMaterial";
                SqlCommand cmdUpdate = new SqlCommand(updateQuery, nuevaConexion.AbrirConexion());
                cmdUpdate.Parameters.AddWithValue("@Cantidad", cant);
                cmdUpdate.Parameters.AddWithValue("@IdServicio", idServicio);
                cmdUpdate.Parameters.AddWithValue("@IdMaterial", idMaterial);
                cmdUpdate.ExecuteNonQuery();
                nuevaConexion.CerrarConexion();

                // Notificar que se ha actualizado.
                OnMaterialXServicioUpdated();
            }
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Operativo.MaterialXServicio con los datos actualizados.
         */
        public void EliminaDato()
        {
            string materialSeleccionado = cmb_Material.Text;
            string[] partesMaterial = materialSeleccionado.Split('-');
            string nombreMaterial = partesMaterial[0].Trim();
            string tipoMaterial = partesMaterial[1].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del material.
            string queryIdMaterial = "SELECT idMaterial FROM Operativo.Material WHERE NombreMaterial = @Nombre AND TipoMaterial = @Tipo";
            SqlCommand cmdIdMaterial = new SqlCommand(queryIdMaterial, nuevaConexion.AbrirConexion());
            cmdIdMaterial.Parameters.AddWithValue("@Nombre", nombreMaterial);
            cmdIdMaterial.Parameters.AddWithValue("@Tipo", tipoMaterial);
            idMaterial = cmdIdMaterial.ExecuteScalar()?.ToString();
            nuevaConexion.CerrarConexion();

            nuevaConexion.AbrirConexion();

            // Cadena SQL para eliminar un nuevo registro en la tabla Operativo.MaterialXServicio.
            string delete = "DELETE FROM Operativo.MaterialXServicio WHERE idServicio = @IdServicio AND idMaterial = @IdMaterial";
            SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdServicio", idServicio);
            cmd.Parameters.AddWithValue("@IdMaterial", idMaterial);
            cmd.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();

            // Notificar que se ha actualizado.
            OnMaterialXServicioUpdated();
        }

        /*
            Dispara el Evento para notificar el cambio del subtotal.
         */
        protected virtual void OnMaterialXServicioUpdated()
        {
            SubtotalChanged?.Invoke(this, EventArgs.Empty);
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            cmb_Material.SelectedIndex = -1;
            txtCantidad.Clear();
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            cmb_Material.SelectedIndex = -1;
            txtCantidad.Clear();
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            cmb_Material.SelectedIndex = -1;
            txtCantidad.Clear();
        }
    }
}