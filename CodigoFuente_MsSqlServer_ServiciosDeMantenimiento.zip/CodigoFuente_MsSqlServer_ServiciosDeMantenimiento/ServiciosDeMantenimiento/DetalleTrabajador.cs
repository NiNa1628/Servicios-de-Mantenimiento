﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario DetalleTrabajador
using Microsoft.Win32;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ServiciosDeMantenimiento
{
    /*
       Clase para gestionar el manejo de los detalles de los trabajadores dentro de los Servicios de Mantenimiento
       Proporciona métodos para consultar, insertar, modificar y eliminar datos.
    */
    public partial class DetalleTrabajador : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; integrated security = true");
        int idTrabajador = -1;
        string profesion = "";
        string costoBase = "";

        /* 
            Constructor del formulario DetalleTrabajador.
            Inicializa el formulario y carga los datos de la tabla DetalleTrabajador en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public DetalleTrabajador(int idTrabajador)
        {
            InitializeComponent();
            this.idTrabajador = idTrabajador;
            ConsultaDatos();
            TablaDetalleTrabajador.CellClick += TablaDetalleTrabajador_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Operativo.DetalleTrabajador en el DataGridView.
            Formatea las columnas y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaDetalleTrabajador.DataSource = null;

            // Cadena SQL para consultar la tabla Operativo.DetalleTrabajador.
            string selectInfo = "SELECT dt.idTrabajador, dt.profesion, dt.costoBase, t.nombreTrabajador " +
                                "FROM Operativo.DetalleTrabajador dt " +
                                "JOIN Operativo.Trabajador t ON dt.idTrabajador = t.idTrabajador " +
                                "WHERE dt.idTrabajador = @IdTrabajador";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaDetalleTrabajador si es que no contiene columnas.
            if (TablaDetalleTrabajador.Columns.Count == 0)
            {
                TablaDetalleTrabajador.Columns.Add("idTrabajador", "Trabajador");
                TablaDetalleTrabajador.Columns.Add("profesion", "Profesión");
                TablaDetalleTrabajador.Columns.Add("costoBase", "Costo Base");

                TablaDetalleTrabajador.Columns["costoBase"].DefaultCellStyle.Format = "N2";
            }

            TablaDetalleTrabajador.Rows.Clear();
            int i = 0;

            // Agrega a TablaDetalleTrabajador una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                string nombreTrabajador = reader["nombreTrabajador"].ToString();
                string trabajador = nombreTrabajador;

                TablaDetalleTrabajador.Rows.Add();
                TablaDetalleTrabajador.Rows[i].Cells[0].Value = trabajador;
                TablaDetalleTrabajador.Rows[i].Cells[1].Value = reader["profesion"].ToString();
                TablaDetalleTrabajador.Rows[i].Cells[2].Value = Convert.ToDecimal(reader["costoBase"]).ToString("N2");
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaDetalleTrabajador_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaDetalleTrabajador_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaDetalleTrabajador.Rows[e.RowIndex];
                txtProfesion_Trabajador.Text = row.Cells[1].Value.ToString();
                txtCostoBase_Trabajador.Text = row.Cells[2].Value.ToString();
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Operativo.DetalleTrabajador con los datos ingresados.
            Si ocurre un error(como duplicación de la profesión), muestra un mensaje de error.
         */
        private void InsertaDato()
        {
            profesion = txtProfesion_Trabajador.Text;
            costoBase = txtCostoBase_Trabajador.Text;

            //Verifica si profesión ya existe.
            string verificaProfesion = "SELECT COUNT(*) FROM Operativo.DetalleTrabajador " +
                                "WHERE idTrabajador = @IdTrabajador AND profesion = @Profesion";
            SqlCommand checkCmd = new SqlCommand(verificaProfesion, nuevaConexion.AbrirConexion());
            checkCmd.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            checkCmd.Parameters.AddWithValue("@Profesion", profesion);

            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("Este trabajador ya tiene asignada esta profesión.");
                return;
            }

            nuevaConexion.AbrirConexion();
            
            
            string InsertInfo = "INSERT INTO Operativo.DetalleTrabajador(idTrabajador, profesion, costoBase) " +
                                "VALUES (@IdTrabajador, @Profesion, @CostoBase)";
            SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
            cm.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            cm.Parameters.AddWithValue("@Profesion", profesion);
            cm.Parameters.AddWithValue("@CostoBase", costoBase);
            cm.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Operativo.DetalleTrabajador con los datos actualizados.
            Si ocurre un error(como duplicación de la profesión), muestra un mensaje de error.
         */
        private void ModificaDato()
        {
            DataGridViewRow selectedRow = TablaDetalleTrabajador.Rows[TablaDetalleTrabajador.SelectedCells[0].RowIndex];
            string profesionActual = selectedRow.Cells["profesion"].Value.ToString();
            string costoBaseActual = selectedRow.Cells["costoBase"].Value.ToString();

            profesion = txtProfesion_Trabajador.Text;
            costoBase = txtCostoBase_Trabajador.Text;

            if (profesion != profesionActual)
            {
                //Verifica si profesión ya existe.
                string verificaProfesion = "SELECT COUNT(*) FROM Operativo.DetalleTrabajador " +
                                           "WHERE idTrabajador = @IdTrabajador AND profesion = @Profesion";
                SqlCommand checkCmd = new SqlCommand(verificaProfesion, nuevaConexion.AbrirConexion());
                checkCmd.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
                checkCmd.Parameters.AddWithValue("@Profesion", profesion);

                int count = (int)checkCmd.ExecuteScalar();
                nuevaConexion.CerrarConexion();

                if (count > 0)
                {
                    MessageBox.Show("El trabajador ya tiene asignada esta profesión.");
                    return;
                }
            }

            nuevaConexion.AbrirConexion();

            // Cadena SQL para modificar un nuevo registro en la tabla Operativo.DetalleTrabajador.
            string updateInfo = "UPDATE Operativo.DetalleTrabajador " +
                                "SET profesion = @Profesion, costoBase = @CostoBase " +
                                "WHERE idTrabajador = @IdTrabajador AND profesion = @ProfesionActual";
            SqlCommand updateCmd = new SqlCommand(updateInfo, nuevaConexion.AbrirConexion());
            updateCmd.Parameters.AddWithValue("@Profesion", profesion);
            updateCmd.Parameters.AddWithValue("@CostoBase", costoBase);
            updateCmd.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            updateCmd.Parameters.AddWithValue("@ProfesionActual", profesionActual);

            updateCmd.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Operativo.DetalleTrabajador con los datos actualizados.
         */
        public void EliminaDato()
        {
            nuevaConexion.AbrirConexion();

            // Cadena SQL para eliminar un nuevo registro en la tabla Operativo.Trabajador.
            string delete = "DELETE FROM Operativo.DetalleTrabajador WHERE idTrabajador = @IdTrabajador AND profesion = @Profesion";
            SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            cmd.Parameters.AddWithValue("@Profesion", profesion);
            cmd.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtProfesion_Trabajador.Clear();
            txtCostoBase_Trabajador.Clear();
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtProfesion_Trabajador.Clear();
            txtCostoBase_Trabajador.Clear();
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtProfesion_Trabajador.Clear();
            txtCostoBase_Trabajador.Clear();
        }
    }
}
