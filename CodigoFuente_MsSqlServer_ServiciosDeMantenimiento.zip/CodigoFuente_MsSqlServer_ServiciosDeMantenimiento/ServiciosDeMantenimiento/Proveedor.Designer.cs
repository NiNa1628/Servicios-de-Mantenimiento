﻿namespace ServiciosDeMantenimiento
{
    partial class Proveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnInserta = new System.Windows.Forms.Button();
            this.TablaProveedor = new System.Windows.Forms.DataGridView();
            this.txtEmail_Proveedor = new System.Windows.Forms.TextBox();
            this.txtTelefono_Proveedor = new System.Windows.Forms.TextBox();
            this.txtNombre_Proveedor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TablaProveedor)).BeginInit();
            this.SuspendLayout();
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(479, 139);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 37;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(286, 139);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 36;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(95, 139);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 35;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click);
            // 
            // TablaProveedor
            // 
            this.TablaProveedor.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.TablaProveedor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaProveedor.Location = new System.Drawing.Point(26, 178);
            this.TablaProveedor.Name = "TablaProveedor";
            this.TablaProveedor.RowHeadersWidth = 51;
            this.TablaProveedor.RowTemplate.Height = 24;
            this.TablaProveedor.Size = new System.Drawing.Size(645, 271);
            this.TablaProveedor.TabIndex = 34;
            // 
            // txtEmail_Proveedor
            // 
            this.txtEmail_Proveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtEmail_Proveedor.Location = new System.Drawing.Point(316, 90);
            this.txtEmail_Proveedor.Name = "txtEmail_Proveedor";
            this.txtEmail_Proveedor.Size = new System.Drawing.Size(281, 30);
            this.txtEmail_Proveedor.TabIndex = 33;
            // 
            // txtTelefono_Proveedor
            // 
            this.txtTelefono_Proveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTelefono_Proveedor.Location = new System.Drawing.Point(316, 48);
            this.txtTelefono_Proveedor.Name = "txtTelefono_Proveedor";
            this.txtTelefono_Proveedor.Size = new System.Drawing.Size(281, 30);
            this.txtTelefono_Proveedor.TabIndex = 32;
            // 
            // txtNombre_Proveedor
            // 
            this.txtNombre_Proveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtNombre_Proveedor.Location = new System.Drawing.Point(316, 7);
            this.txtNombre_Proveedor.Name = "txtNombre_Proveedor";
            this.txtNombre_Proveedor.Size = new System.Drawing.Size(281, 30);
            this.txtNombre_Proveedor.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(86, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(221, 25);
            this.label4.TabIndex = 30;
            this.label4.Text = "Teléfono del Proveedor:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(86, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 25);
            this.label3.TabIndex = 29;
            this.label3.Text = "Email del Proveedor:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(86, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "Nombre del Proveedor:";
            // 
            // Proveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 468);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Controls.Add(this.TablaProveedor);
            this.Controls.Add(this.txtEmail_Proveedor);
            this.Controls.Add(this.txtTelefono_Proveedor);
            this.Controls.Add(this.txtNombre_Proveedor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Proveedor";
            this.Text = "Proveedor";
            ((System.ComponentModel.ISupportInitialize)(this.TablaProveedor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnInserta;
        private System.Windows.Forms.DataGridView TablaProveedor;
        private System.Windows.Forms.TextBox txtEmail_Proveedor;
        private System.Windows.Forms.TextBox txtTelefono_Proveedor;
        private System.Windows.Forms.TextBox txtNombre_Proveedor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
    }
}