﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar la conexión con SQL
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

/*
    Clase para gestionar la conexión con la base de datos SQL Server.
    Proporciona métodos para abrir y cerrar la conexión.
 */
public class ConexionDB
{
    private SqlConnection conexion;
    private readonly string cadenaConexion;

    /*
        Constructor de la clase ConexionBD
        Inicializa la conexión con la base de datos a través de una cadena proporcinada.
     */
    public ConexionDB(string connectionString)
    {
        cadenaConexion = connectionString;
        conexion = new SqlConnection(cadenaConexion);
    }

    /*
        Abre la conexión con la base de datos si está cerrada.
        Muestra un mensaje de error si ocurre una excepción al abrir la conexión.
     */
    public SqlConnection AbrirConexion()
    {
        try
        {
            if (conexion.State == System.Data.ConnectionState.Closed)
            {
                conexion.Open();
            }
        }
        catch (SqlException ex)
        {
            MessageBox.Show("Error al abrir la conexión: " + ex.Message);
        }

        return conexion;
    }

    /*
        Cierra la conexión con la base de datos si está abierta.
        Muestra un mensaje de error si ocurre una excepción al cerrar la conexión.
     */
    public void CerrarConexion()
    {
        try
        {
            if (conexion.State == System.Data.ConnectionState.Open)
            {
                conexion.Close();
            }
        }
        catch (SqlException ex)
        {
            MessageBox.Show("Error al cerrar la conexión: " + ex.Message);
        }
    }
}
