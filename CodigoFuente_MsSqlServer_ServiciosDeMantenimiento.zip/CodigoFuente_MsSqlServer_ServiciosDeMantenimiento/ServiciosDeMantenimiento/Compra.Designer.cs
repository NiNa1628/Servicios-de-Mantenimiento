﻿namespace ServiciosDeMantenimiento
{
    partial class Compra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDetalleCompra = new System.Windows.Forms.Button();
            this.cmb_Proveedor = new System.Windows.Forms.ComboBox();
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnInserta = new System.Windows.Forms.Button();
            this.TablaCompra = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TablaCompra)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDetalleCompra
            // 
            this.btnDetalleCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnDetalleCompra.Location = new System.Drawing.Point(197, 387);
            this.btnDetalleCompra.Name = "btnDetalleCompra";
            this.btnDetalleCompra.Size = new System.Drawing.Size(216, 32);
            this.btnDetalleCompra.TabIndex = 46;
            this.btnDetalleCompra.Text = "Detalle de Compra";
            this.btnDetalleCompra.UseVisualStyleBackColor = true;
            this.btnDetalleCompra.Visible = false;
            this.btnDetalleCompra.Click += new System.EventHandler(this.btnDetalleCompra_Click);
            // 
            // cmb_Proveedor
            // 
            this.cmb_Proveedor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Proveedor.FormattingEnabled = true;
            this.cmb_Proveedor.Location = new System.Drawing.Point(284, 19);
            this.cmb_Proveedor.Name = "cmb_Proveedor";
            this.cmb_Proveedor.Size = new System.Drawing.Size(281, 24);
            this.cmb_Proveedor.TabIndex = 45;
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(448, 66);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 44;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(255, 66);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 43;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(64, 66);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 42;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click);
            // 
            // TablaCompra
            // 
            this.TablaCompra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.TablaCompra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaCompra.Location = new System.Drawing.Point(12, 105);
            this.TablaCompra.Name = "TablaCompra";
            this.TablaCompra.RowHeadersWidth = 51;
            this.TablaCompra.RowTemplate.Height = 24;
            this.TablaCompra.Size = new System.Drawing.Size(608, 271);
            this.TablaCompra.TabIndex = 41;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(35, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 25);
            this.label1.TabIndex = 40;
            this.label1.Text = "Seleccione el Proveedor:";
            // 
            // Compra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 429);
            this.Controls.Add(this.btnDetalleCompra);
            this.Controls.Add(this.cmb_Proveedor);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Controls.Add(this.TablaCompra);
            this.Controls.Add(this.label1);
            this.Name = "Compra";
            this.Text = "Compra";
            ((System.ComponentModel.ISupportInitialize)(this.TablaCompra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDetalleCompra;
        private System.Windows.Forms.ComboBox cmb_Proveedor;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnInserta;
        private System.Windows.Forms.DataGridView TablaCompra;
        private System.Windows.Forms.Label label1;
    }
}