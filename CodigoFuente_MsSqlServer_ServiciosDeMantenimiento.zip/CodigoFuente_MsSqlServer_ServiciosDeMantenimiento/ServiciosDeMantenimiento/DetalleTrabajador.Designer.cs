﻿namespace ServiciosDeMantenimiento
{
    partial class DetalleTrabajador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnElimina = new System.Windows.Forms.Button();
            this.btnModifica = new System.Windows.Forms.Button();
            this.btnInserta = new System.Windows.Forms.Button();
            this.TablaDetalleTrabajador = new System.Windows.Forms.DataGridView();
            this.txtCostoBase_Trabajador = new System.Windows.Forms.TextBox();
            this.txtProfesion_Trabajador = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TablaDetalleTrabajador)).BeginInit();
            this.SuspendLayout();
            // 
            // btnElimina
            // 
            this.btnElimina.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnElimina.Location = new System.Drawing.Point(459, 109);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(101, 30);
            this.btnElimina.TabIndex = 57;
            this.btnElimina.Text = "Eliminar";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // btnModifica
            // 
            this.btnModifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnModifica.Location = new System.Drawing.Point(266, 109);
            this.btnModifica.Name = "btnModifica";
            this.btnModifica.Size = new System.Drawing.Size(116, 30);
            this.btnModifica.TabIndex = 56;
            this.btnModifica.Text = "Modificar";
            this.btnModifica.UseVisualStyleBackColor = true;
            this.btnModifica.Click += new System.EventHandler(this.btnModifica_Click);
            // 
            // btnInserta
            // 
            this.btnInserta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnInserta.Location = new System.Drawing.Point(75, 109);
            this.btnInserta.Name = "btnInserta";
            this.btnInserta.Size = new System.Drawing.Size(100, 30);
            this.btnInserta.TabIndex = 55;
            this.btnInserta.Text = "Insertar";
            this.btnInserta.UseVisualStyleBackColor = true;
            this.btnInserta.Click += new System.EventHandler(this.btnInserta_Click);
            // 
            // TablaDetalleTrabajador
            // 
            this.TablaDetalleTrabajador.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.TablaDetalleTrabajador.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TablaDetalleTrabajador.Location = new System.Drawing.Point(12, 145);
            this.TablaDetalleTrabajador.Name = "TablaDetalleTrabajador";
            this.TablaDetalleTrabajador.RowHeadersWidth = 51;
            this.TablaDetalleTrabajador.RowTemplate.Height = 24;
            this.TablaDetalleTrabajador.Size = new System.Drawing.Size(603, 271);
            this.TablaDetalleTrabajador.TabIndex = 54;
            // 
            // txtCostoBase_Trabajador
            // 
            this.txtCostoBase_Trabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCostoBase_Trabajador.Location = new System.Drawing.Point(298, 52);
            this.txtCostoBase_Trabajador.Name = "txtCostoBase_Trabajador";
            this.txtCostoBase_Trabajador.Size = new System.Drawing.Size(281, 30);
            this.txtCostoBase_Trabajador.TabIndex = 53;
            // 
            // txtProfesion_Trabajador
            // 
            this.txtProfesion_Trabajador.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtProfesion_Trabajador.Location = new System.Drawing.Point(298, 13);
            this.txtProfesion_Trabajador.Name = "txtProfesion_Trabajador";
            this.txtProfesion_Trabajador.Size = new System.Drawing.Size(281, 30);
            this.txtProfesion_Trabajador.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(38, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 25);
            this.label4.TabIndex = 51;
            this.label4.Text = "Profesión del Trabajador:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(38, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(249, 25);
            this.label3.TabIndex = 50;
            this.label3.Text = "Costo base del Trabajador:";
            // 
            // DetalleTrabajador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 450);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.btnModifica);
            this.Controls.Add(this.btnInserta);
            this.Controls.Add(this.TablaDetalleTrabajador);
            this.Controls.Add(this.txtCostoBase_Trabajador);
            this.Controls.Add(this.txtProfesion_Trabajador);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Name = "DetalleTrabajador";
            this.Text = "DetalleTrabajador";
            ((System.ComponentModel.ISupportInitialize)(this.TablaDetalleTrabajador)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Button btnModifica;
        private System.Windows.Forms.Button btnInserta;
        private System.Windows.Forms.DataGridView TablaDetalleTrabajador;
        private System.Windows.Forms.TextBox txtCostoBase_Trabajador;
        private System.Windows.Forms.TextBox txtProfesion_Trabajador;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}