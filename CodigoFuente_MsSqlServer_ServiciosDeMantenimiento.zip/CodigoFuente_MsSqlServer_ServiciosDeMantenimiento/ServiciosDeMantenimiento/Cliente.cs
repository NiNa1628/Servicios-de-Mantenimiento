﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario Cliente.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
        Clase para gestionar el manejo de los clientes dentro de los Servicios de Mantenimiento
        Proporciona métodos para consultar, insertar, modificar y eliminar datos.
     */
    public partial class Cliente : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idCliente = -1;
        string rfcCliente = " ";
        string nomCliente = " ";
        string telCliente = " ";
        string emailCliente = " ";
        
        //Lista que almacena objetos de tipo DomicilioCliente.
        private List<DomicilioCliente> domicilioClienteForms = new List<DomicilioCliente>();

        /* 
            Constructor del formulario Cliente.
            Inicializa el formulario y carga los datos de la tabla Cliente en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public Cliente()
        {
            InitializeComponent();
            ConsultaDatos();
            TablaCliente.CellClick += TablaCliente_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Comercial.Cliente en el DataGridView.
            Formatea las columnas y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaCliente.DataSource = null;
           
            // Cadena SQL para consultar la tabla Comercial.Cliente.
            String selectInfo = "SELECT * FROM Comercial.Cliente";
            SqlCommand scm = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader lector = scm.ExecuteReader();

            // Agrega columnas en la TablaCliente si es que no contiene columnas.
            if (TablaCliente.Columns.Count == 0)
            {
                TablaCliente.Columns.Add("idCliente", "ID");
                TablaCliente.Columns.Add("RFCCliente", "RFC del Cliente");
                TablaCliente.Columns.Add("nombreCliente", "Nombre del Cliente");
                TablaCliente.Columns.Add("telefonoCliente", "Teléfono del Cliente");
                TablaCliente.Columns.Add("emailCliente", "Email");
            }

            TablaCliente.Rows.Clear();
            int i = 0;

            // Agrega a TablaCliente una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (lector.Read())
            {
                TablaCliente.Rows.Add();
                TablaCliente.Rows[i].Cells[0].Value = lector["idCliente"].ToString();
                TablaCliente.Rows[i].Cells[1].Value = lector["RFCCliente"].ToString();
                TablaCliente.Rows[i].Cells[2].Value = lector["nombreCliente"].ToString();
                TablaCliente.Rows[i].Cells[3].Value = lector["telefonoCliente"].ToString();
                TablaCliente.Rows[i].Cells[4].Value = lector["emailCliente"].ToString();
                i++;
            }
            lector.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaCliente_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaCliente.Rows[e.RowIndex];
                idCliente = int.Parse(row.Cells[0].Value.ToString());
                txtRFCCliente.Text = row.Cells[1].Value.ToString();
                txtNomCliente.Text = row.Cells[2].Value.ToString();
                txtTelCliente.Text = row.Cells[3].Value.ToString();
                txtEmailCliente.Text = row.Cells[4].Value.ToString();
                
                // Hace visible al botón btnDomicilio.
                btnDomicilio.Visible = true;
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Comercial.Cliente con los datos ingresados.
            Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
         */
        public void InsertaDato()
        {
            rfcCliente = txtRFCCliente.Text;
            nomCliente = txtNomCliente.Text;
            telCliente = txtTelCliente.Text;
            emailCliente = txtEmailCliente.Text;

            nuevaConexion.AbrirConexion();

            //Verifica si el RFC, el teléfono o el correo electrónico ya existen.
            string verifica = "SELECT COUNT(*) FROM Comercial.Cliente WHERE RFCCliente = @RFC OR telefonoCliente = @Telefono OR emailCliente = @Email";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion.AbrirConexion());
            checkCmd.Parameters.AddWithValue("@RFC", rfcCliente);
            checkCmd.Parameters.AddWithValue("@Telefono", telCliente);
            checkCmd.Parameters.AddWithValue("@Email", emailCliente);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El RFC, el teléfono o el correo electrónico ya están en uso.");
            }
            else
            {
                // Cadena SQL para agregar un nuevo registro en la tabla Comercial.Cliente.
                string InsertInfo = "INSERT INTO Comercial.Cliente(RFCCliente, nombreCliente, telefonoCliente, emailCliente)" +
                   "VALUES('" + rfcCliente + "' , '" + nomCliente + "', '" + telCliente + "', '" + emailCliente + "' )";
                SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
                cm.ExecuteNonQuery();
            }

            nuevaConexion.CerrarConexion();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Comercial.Cliente con los datos actualizados.
            Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
         */
        public void ModificaDato()
        {
            string verificaEmail = txtEmailCliente.Text;

            rfcCliente = txtRFCCliente.Text;
            nomCliente = txtNomCliente.Text;
            telCliente = txtTelCliente.Text;
            emailCliente = txtEmailCliente.Text;

            nuevaConexion.CerrarConexion();

            //Verifica si el RFC, el teléfono o el correo electrónico ya existen.
            string verifica = "SELECT COUNT(*) FROM Comercial.Cliente WHERE RFCCliente = @RFC OR telefonoCliente = @Telefono OR emailCliente = @Email";
            SqlCommand checkCmd = new SqlCommand(verifica, nuevaConexion.AbrirConexion());
            checkCmd.Parameters.AddWithValue("@RFC", rfcCliente);
            checkCmd.Parameters.AddWithValue("@Telefono", telCliente);
            checkCmd.Parameters.AddWithValue("@Email", emailCliente);
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("El RFC, el teléfono o el correo electrónico ya están en uso.");
            }
            else
            {
                // Cadena SQL para modificar un nuevo registro en la tabla Comercial.Cliente.
                string update = "UPDATE Comercial.Cliente SET RFCCliente  = @RFC, nombreCliente = @Nombre, telefonoCliente = @Telefono, emailCliente = @Email " +
                "WHERE idCliente = @Id";
                SqlCommand cmd = new SqlCommand(update, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@RFC", rfcCliente);
                cmd.Parameters.AddWithValue("@Nombre", nomCliente);
                cmd.Parameters.AddWithValue("@Telefono", telCliente);
                cmd.Parameters.AddWithValue("@Email", emailCliente);
                cmd.Parameters.AddWithValue("@Id", idCliente);
                cmd.ExecuteNonQuery();
                nuevaConexion.CerrarConexion();
            }
            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Comercial.Cliente con los datos actualizados.
         */
        public void EliminarDato()
        {
            if (idCliente != -1)
            {
                nuevaConexion.AbrirConexion();
                
                // Cadena SQL para eliminar un nuevo registro en la tabla Comercial.Cliente.
                string delete = "DELETE FROM Comercial.Cliente WHERE  idCliente = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Id", idCliente);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Comercial.Cliente";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion.AbrirConexion());
                int rowCount = (int)checkCmd.ExecuteScalar();

                // Reinicia el valor del idCliente cuando la cantidad de filas es igual a 0.
                if (rowCount == 0)
                {       
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Comercial.Cliente', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion.AbrirConexion());
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.CerrarConexion();
            }
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtRFCCliente.Clear();
            txtNomCliente.Clear();
            txtTelCliente.Clear();
            txtEmailCliente.Clear();
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtRFCCliente.Clear();
            txtNomCliente.Clear();
            txtTelCliente.Clear(); ;
            txtEmailCliente.Clear();
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminarDato();
            ConsultaDatos();
            txtRFCCliente.Clear();
            txtNomCliente.Clear();
            txtTelCliente.Clear();
            txtEmailCliente.Clear();
        }

        /*
            Evento que se dispara al hacer clic en el botón de Domicilio.
            Abre el formulario DomicilioCliente para gestionar los domicilios asociados a un cliente específico.
         */
        private void btnDomicilio_Click(object sender, EventArgs e)
        {
            if (idCliente != -1)
            {
                DomicilioCliente domicilioClienteForm = new DomicilioCliente(idCliente);
                domicilioClienteForms.Add(domicilioClienteForm);
                domicilioClienteForm.Show();
            }
        }
    }
}


