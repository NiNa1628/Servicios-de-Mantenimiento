﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario Material.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
        Clase para gestionar el manejo de los materiales dentro de los Servicios de Mantenimiento
        Proporciona métodos para consultar, insertar, modificar y eliminar datos.
     */
    public partial class Material : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idMaterial = -1;
        string nombreMaterial = "";
        string tipoMaterial = "";
        string precioMaterial = "";
        string existencia = "";

        /* 
            Constructor del formulario Material.
            Inicializa el formulario y carga los datos de la tabla Material en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public Material()
        {
            InitializeComponent();
            ConsultaDatos();
            TablaMaterial.CellClick += TablaMaterial_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Operativo.Material en el DataGridView.
            Formatea las columnas y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaMaterial.DataSource = null;

            // Cadena SQL para consultar la tabla Operativo.Material.
            string selectInfo = "SELECT * FROM Operativo.Material";
            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaMaterial si es que no contiene columnas.
            if (TablaMaterial.Columns.Count == 0)
            {
                TablaMaterial.Columns.Add("idMaterial", "ID");
                TablaMaterial.Columns.Add("nombreMaterial", "Nombre del material");
                TablaMaterial.Columns.Add("tipoMaterial", "Tipo del material");
                TablaMaterial.Columns.Add("precioMaterial", "Precio del material");
                TablaMaterial.Columns.Add("existencia", "Existencias");

                TablaMaterial.Columns["precioMaterial"].DefaultCellStyle.Format = "N2";
            }

            TablaMaterial.Rows.Clear();
            int i = 0;

            // Agrega a TablaMaterial una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                TablaMaterial.Rows.Add();
                TablaMaterial.Rows[i].Cells[0].Value = reader["idMaterial"].ToString();
                TablaMaterial.Rows[i].Cells[1].Value = reader["nombreMaterial"].ToString();
                TablaMaterial.Rows[i].Cells[2].Value = reader["tipoMaterial"].ToString();
                TablaMaterial.Rows[i].Cells[3].Value = Convert.ToDecimal(reader["precioMaterial"]).ToString("N2");
                TablaMaterial.Rows[i].Cells[4].Value = reader["existencia"].ToString();
                i++;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaMaterial_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaMaterial_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaMaterial.Rows[e.RowIndex];
                idMaterial = int.Parse(row.Cells[0].Value.ToString());
                txtNombre_Material.Text = row.Cells[1].Value.ToString();
                cmbBoxTipo_Material.Text = row.Cells[2].Value.ToString();
                txtPrecio_Material.Text = row.Cells[3].Value.ToString();
                txtExistencia.Text = row.Cells[4].Value.ToString();
            }
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Operativo.Material con los datos ingresados.
            Si ocurre un error (como duplicación de nombre), muestra un mensaje de error.
         */
        public void InsertaDato()
        {
            nombreMaterial = txtNombre_Material.Text;
            tipoMaterial = cmbBoxTipo_Material.Text;
            precioMaterial = txtPrecio_Material.Text;
            existencia = txtExistencia.Text;

            try
            {
                nuevaConexion.AbrirConexion();

                // Cadena SQL para agregar un nuevo registro en la tabla Operativo.Material.
                string InsertInfo = "INSERT INTO Operativo.Material(nombreMaterial, tipoMaterial, precioMaterial, existencia) " +
                    "VALUES ('" + nombreMaterial + "', '" + tipoMaterial + "', '" + precioMaterial + "', '" + existencia + "')";
                SqlCommand cm = new SqlCommand(InsertInfo, nuevaConexion.AbrirConexion());
                cm.ExecuteNonQuery();
            }

            //Verifica si el nombre del material ya existe dentro de Operativo.Material.
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    MessageBox.Show("No se puede insertar el material. El nombre ya existe.");
                }
                else
                {
                    MessageBox.Show("Error al insertar el material: " + ex.Message);
                }
            }
            nuevaConexion.CerrarConexion();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Operativo.Material con los datos actualizados.
            Si ocurre un error (como duplicación de nombre), muestra un mensaje de error
         */
        public void ModificaDato()
        {
            nombreMaterial = txtNombre_Material.Text;
            tipoMaterial = cmbBoxTipo_Material.Text;
            precioMaterial = txtPrecio_Material.Text;
            existencia = txtExistencia.Text;

            try
            {
                nuevaConexion.AbrirConexion();

                // Cadena SQL para modificar un nuevo registro en la tabla Operativo.Material.
                string update = "UPDATE Operativo.Material SET nombreMaterial = @Nombre, tipoMaterial = @Tipo, precioMaterial = @Precio, existencia = @Existencias " +
                    "WHERE idMaterial = @Id";
                SqlCommand cmd = new SqlCommand(update, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Nombre", nombreMaterial);
                cmd.Parameters.AddWithValue("@Tipo", tipoMaterial);
                cmd.Parameters.AddWithValue("@Precio", precioMaterial);
                cmd.Parameters.AddWithValue("@Existencias", existencia);
                cmd.Parameters.AddWithValue("@Id", idMaterial);
                cmd.ExecuteNonQuery();
            }

            //Verifica si el nombre del material ya existe dentro de Operativo.Material.
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    MessageBox.Show("No se puede insertar el material. El nombre ya existe.");
                }
                else
                {
                    MessageBox.Show("Error al insertar el material: " + ex.Message);
                }
            }
            nuevaConexion.CerrarConexion();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado de la tabla Operativo.Material.
            Si la tabla queda vacía, reinicia el contador de identidad.
         */
        public void EliminaDato()
        {
            if (idMaterial != -1)
            {
                nuevaConexion.AbrirConexion();

                // Cadena SQL para eliminar un nuevo registro en la tabla Operativo.Material .
                string delete = "DELETE FROM Operativo.Material WHERE idMaterial = @Id";
                SqlCommand cmd = new SqlCommand(delete, nuevaConexion.AbrirConexion());
                cmd.Parameters.AddWithValue("@Id", idMaterial);
                cmd.ExecuteNonQuery();

                string checkEmptyQuery = "SELECT COUNT(*) FROM Operativo.Material";
                SqlCommand checkCmd = new SqlCommand(checkEmptyQuery, nuevaConexion.AbrirConexion());
                int rowCount = (int)checkCmd.ExecuteScalar();

                // Reinicia el valor del idMaterial cuando la cantidad de filas es igual a 0.
                if (rowCount == 0)
                {
                    string resetIdentityQuery = "DBCC CHECKIDENT ('Operativo.Material', RESEED, 0)";
                    SqlCommand resetCmd = new SqlCommand(resetIdentityQuery, nuevaConexion.AbrirConexion());
                    resetCmd.ExecuteNonQuery();
                }
                nuevaConexion.CerrarConexion();
            }
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click_1(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            txtNombre_Material.Clear();
            cmbBoxTipo_Material.SelectedIndex = -1;
            txtPrecio_Material.Clear();
            txtExistencia.Clear();
            idMaterial = -1;
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click_1(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            txtNombre_Material.Clear();
            cmbBoxTipo_Material.SelectedIndex = -1;
            txtPrecio_Material.Clear();
            txtExistencia.Clear();
            idMaterial = -1;
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click_1(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            txtNombre_Material.Clear();
            cmbBoxTipo_Material.SelectedIndex = -1;
            txtPrecio_Material.Clear();
            txtExistencia.Clear();
            idMaterial = -1;
        }
        

        
    }      
}
