﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario Principal
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
        Clase principal del formulario de Servicios de Mantenimiento.
        Este formulario actúa como el menú principal de la aplicación, proporcionando acceso a otros formularios específicos.
        Los siguiente formularios son:
            - Formulario de Material.
            - Formulario de Cliente.
            - Formulario de Proveedor.
            - Formulario de Trabajador.
            - Formulario de Compra.
            - Formulario de Servicio.
     */
    public partial class ServiciosdeMantenimiento : Form
    {
        /*
            Constructor del formulario principal.
            Inicializa los componentes del formulario.
         */
        public ServiciosdeMantenimiento()
        {
            InitializeComponent();
        }

        /*
            Evento que se dispara al hacer clic en el botón de Material.
            Abre el formulario de Material como un cuadro de diálogo, permitiendo gestionar los datos de materiales.
         */
        private void btnMaterial_Click(object sender, EventArgs e)
        {
            Material materialForm = new Material();
            materialForm.ShowDialog();
        }

        /*
            Evento que se dispara al hacer clic en el botón de Cliente.
            Abre el formulario de Cliente como un cuadro de diálogo, permitiendo gestionar los datos de los clientes.
         */
        private void btnCliente_Click(object sender, EventArgs e)
        {
            Cliente clienteForm = new Cliente();
            clienteForm.ShowDialog();
        }

        /*
            Evento que se dispara al hacer clic en el botón de Proveedor.
            Abre el formulario de Proveedor como un cuadro de diálogo, permitiendo gestionar los datos de los proveedores.
         */
        private void btnProveedor_Click(object sender, EventArgs e)
        {
            Proveedor proveedorForm = new Proveedor();
            proveedorForm.ShowDialog();
        }

        /*
            Evento que se dispara al hacer clic en el botón de Trabajador.
            Abre el formulario de Trabajador como un cuadro de diálogo, permitiendo gestionar los datos de los trabajadores.
         */
        private void btnTrabajador_Click(object sender, EventArgs e)
        {
            Trabajador trabajadorForm = new Trabajador();
            trabajadorForm.ShowDialog();
        }

        /*
            Evento que se dispara al hacer clic en el botón de Compra.
            Abre el formulario de Compra como un cuadro de diálogo, permitiendo gestionar los datos de las compras.
         */
        private void btnCompra_Click(object sender, EventArgs e)
        {
            Compra compraForm = new Compra();
            compraForm.ShowDialog();
        }

        /*
            Evento que se dispara al hacer clic en el botón de Servicio.
            Abre el formulario de Servicio como un cuadro de diálogo, permitiendo gestionar los datos de los servicios.
         */
        private void btnServicio_Click(object sender, EventArgs e)
        {
            Servicio servicioForm = new Servicio();
            servicioForm.ShowDialog();
        }
    }
}
    