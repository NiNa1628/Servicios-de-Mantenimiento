﻿// Librerías del sistema y .NET Framework usadas para crear y gestionar el formulario TrabajadorXServicio.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServiciosDeMantenimiento
{
    /*
       Clase para gestionar el manejo de los trabajadores de los servicios dentro de los Servicios de Mantenimiento
       Proporciona métodos para consultar, insertar, modificar y eliminar datos.
    */
    public partial class TrabajadorXServicio : Form
    {
        // Crea una instancia de una nueva conexión para conectarse con la base de datos de SQL Server.
        ConexionDB nuevaConexion = new ConexionDB("Server=ASUS\\SQLEXPRESS1; DATABASE = ServiciosdeMantenimiento; " +
            "integrated security = true");
        int idTrabajadorXServicio = -1;
        int idServicio;
        string idTrabajador = "";
        float subtotalTrabajo = 0;

        // Define un evento llamado SubtotalChanged el cual se utiliza para notificar cuando ocurre un cambio en el subtotal de un servicio.
        public event EventHandler SubtotalChanged;

        /* 
            Constructor del formulario TrabajadorXServicio.
            Inicializa el formulario y carga los datos de la tabla TrabajadorXServicio en el DataGridView.
            También suscribe el evento CellClick de la tabla. 
        */
        public TrabajadorXServicio(int idServicio)
        {
            InitializeComponent();
            this.idServicio = idServicio;
            ConsultaDatos();
            CargarTrabajadores();
            TablaTrabajadorXServicio.CellClick += TablaTrabajadorXServicio_CellClick;
        }

        /*
            ConsultaDatos
            Recupera y muestra todos los registros de la tabla Operativo.TrabajadorXServicio en el DataGridView.
            Formatea la columna de precios y limpia las filas antes de agregar los datos.
         */
        public void ConsultaDatos()
        {
            nuevaConexion.AbrirConexion();
            TablaTrabajadorXServicio.DataSource = null;

            // Cadena SQL para consultar la tabla Operativo.TrabajadorXServicio. 
            string selectInfo = @"SELECT txs.idTrabajadorXServicio, txs.idServicio, txs.idTrabajador, txs.subtotalTrabajo, 
                         CONCAT(t.idServicio, ' - ', c.nombreCliente) AS ServicioCliente, 
                         CONCAT(tr.nombreTrabajador, ' (', COUNT(dt.idTrabajador), ')') AS TrabajadorConProfesiones 
                         FROM Operativo.TrabajadorXServicio txs
                         JOIN Operativo.Trabajador tr ON txs.idTrabajador = tr.idTrabajador
                         JOIN Operativo.Servicio t ON txs.idServicio = t.idServicio
                         JOIN Comercial.DomicilioCliente d ON t.idDomicilio = d.idDomicilio
                         JOIN Comercial.Cliente c ON d.idCliente = c.idCliente
                         LEFT JOIN Operativo.DetalleTrabajador dt ON tr.idTrabajador = dt.idTrabajador
                         WHERE t.idServicio = @IdServicio
                         GROUP BY txs.idTrabajadorXServicio, txs.idServicio, txs.idTrabajador, txs.subtotalTrabajo,
                         t.idServicio, c.nombreCliente, tr.nombreTrabajador";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            cmd.Parameters.AddWithValue("@IdServicio", idServicio);
            SqlDataReader reader = cmd.ExecuteReader();

            // Agrega columnas en la TablaTrabajadorXServicio si es que no contiene columnas.
            if (TablaTrabajadorXServicio.Columns.Count == 0)
            {
                TablaTrabajadorXServicio.Columns.Add("idTrabajadorXServicio", "ID");
                TablaTrabajadorXServicio.Columns.Add("ServicioCliente", "Servicio");
                TablaTrabajadorXServicio.Columns.Add("TrabajadorConProfesiones", "Trabajador");
                TablaTrabajadorXServicio.Columns.Add("subtotalTrabajo", "Subtotal");

                TablaTrabajadorXServicio.Columns["subtotalTrabajo"].DefaultCellStyle.Format = "N2";
            }

            TablaTrabajadorXServicio.Rows.Clear();
            int i = 0;

            // Agrega a TablaTrabajadorXServicio una nueva fila para almacenar con los valores correspondientes a las columnas.
            while (reader.Read())
            {
                string servicioCliente = reader["ServicioCliente"].ToString();
                string trabajadorConProfesiones = reader["TrabajadorConProfesiones"].ToString();
                decimal subtotalTrabajo = reader["subtotalTrabajo"] != DBNull.Value ? Convert.ToDecimal(reader["subtotalTrabajo"]) : 0;

                TablaTrabajadorXServicio.Rows.Add();
                TablaTrabajadorXServicio.Rows[i].Cells[0].Value = reader["idTrabajadorXServicio"].ToString();
                TablaTrabajadorXServicio.Rows[i].Cells[1].Value = servicioCliente;
                TablaTrabajadorXServicio.Rows[i].Cells[2].Value = trabajadorConProfesiones;
                TablaTrabajadorXServicio.Rows[i].Cells[3].Value = subtotalTrabajo.ToString("N2");
                i++;

                TablaTrabajadorXServicio.Columns["idTrabajadorXServicio"].Visible = false;
            }
            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            Carge la información de la tabla Operativo.Trabajador y la muestra en un combobox.
         */
        public void CargarTrabajadores()
        {
            nuevaConexion.AbrirConexion();

            string selectInfo = @"SELECT t.NombreTrabajador, COUNT(dt.profesion) AS CantidadProfesiones
                          FROM Operativo.Trabajador t
                          LEFT JOIN Operativo.DetalleTrabajador dt ON t.idTrabajador = dt.idTrabajador
                          GROUP BY t.NombreTrabajador";

            SqlCommand cmd = new SqlCommand(selectInfo, nuevaConexion.AbrirConexion());
            SqlDataReader reader = cmd.ExecuteReader();

            cmb_Trabajador.Items.Clear();

            // Lee cada trabajador del resultado de la consulta
            while (reader.Read())
            {
                string nombreTrabajador = reader["NombreTrabajador"].ToString();
                int cantidadProfesiones = Convert.ToInt32(reader["CantidadProfesiones"]);
                string trabajador = $"{nombreTrabajador} ({cantidadProfesiones})";

                // Agrega el resultado al combo box
                cmb_Trabajador.Items.Add(trabajador);
            }

            reader.Close();
            nuevaConexion.CerrarConexion();
        }

        /*
            TablaTrabajadorXServicio_CellClick
            Evento que se activa al hacer clic en una celda del DataGridView.
            Llena los campos de entrada con los datos de la fila seleccionada.
         */
        private void TablaTrabajadorXServicio_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = TablaTrabajadorXServicio.Rows[e.RowIndex];
                idTrabajadorXServicio = int.Parse(row.Cells[0].Value.ToString());
                cmb_Trabajador.Text = row.Cells[2].Value.ToString();
            }
        }

        /*
            Recupera el valor de la columna del idTrabajador.
         */
        private int ObtenerIdTrabajador(string nombreTrabajador)
        {
            nuevaConexion.AbrirConexion();
            string queryIdTrabajador = "SELECT idTrabajador FROM Operativo.Trabajador WHERE NombreTrabajador = @Nombre";
            SqlCommand cmdIdTrabajador = new SqlCommand(queryIdTrabajador, nuevaConexion.AbrirConexion());
            cmdIdTrabajador.Parameters.AddWithValue("@Nombre", nombreTrabajador);

            var resultado = cmdIdTrabajador.ExecuteScalar();

            return resultado != null ? Convert.ToInt32(resultado) : -1;
        }

        /*
            InsertaDato
            Inserta un nuevo registro en la tabla Operativo.TrabajadorXServicio con los datos ingresados.
         */
        public void InsertaDato()
        {
            string trabajadorSeleccionado = cmb_Trabajador.SelectedItem.ToString();
            string nombreTrabajador = trabajadorSeleccionado.Split('(')[0].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del trabajador.
            string queryIdTrabajador = "SELECT idTrabajador FROM Operativo.Trabajador WHERE NombreTrabajador = @NombreTrabajador";
            SqlCommand cmdIdTrabajador = new SqlCommand(queryIdTrabajador, nuevaConexion.AbrirConexion());
            cmdIdTrabajador.Parameters.AddWithValue("@NombreTrabajador", nombreTrabajador);

            var resultado = cmdIdTrabajador.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            if (resultado == null)
            {
                MessageBox.Show("Trabajador no encontrado.");
                return;
            }

            string idTrabajador = resultado.ToString();

            nuevaConexion.AbrirConexion();

            // Verificar si ya existe un trabajador para este servicio.
            string queryProfesiones = "SELECT COUNT(*) FROM Operativo.DetalleTrabajador WHERE idTrabajador = @IdTrabajador";
            SqlCommand cmdProfesiones = new SqlCommand(queryProfesiones, nuevaConexion.AbrirConexion());
            cmdProfesiones.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            int cantidadProfesiones = (int)cmdProfesiones.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            string trabajadorConProfesiones = $"{nombreTrabajador} ({cantidadProfesiones} profesiones)";

            nuevaConexion.AbrirConexion();

            // Verificar si ya existe un trabajadorxservicio.
            string verificarExistencia = "SELECT COUNT(*) FROM Operativo.TrabajadorXServicio WHERE idServicio = @IdServicio AND idTrabajador = @IdTrabajador";
            SqlCommand cmdVerificar = new SqlCommand(verificarExistencia, nuevaConexion.AbrirConexion());
            cmdVerificar.Parameters.AddWithValue("@IdServicio", idServicio);
            cmdVerificar.Parameters.AddWithValue("@IdTrabajador", idTrabajador);

            int count = (int)cmdVerificar.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            if (count > 0)
            {
                MessageBox.Show("El trabajador ya está asociado a este servicio.");
                return;
            }

            nuevaConexion.AbrirConexion();

            // Cadena SQL para agregar un nuevo registro en la tabla Operativo.TrabajadorXServicio.
            string insertInfo = "INSERT INTO Operativo.TrabajadorXServicio(idServicio, idTrabajador, subtotalTrabajo) VALUES (@IdServicio, @IdTrabajador, @Subtotal)";
            SqlCommand cm = new SqlCommand(insertInfo, nuevaConexion.AbrirConexion());
            cm.Parameters.AddWithValue("@IdServicio", idServicio);
            cm.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            cm.Parameters.AddWithValue("@Subtotal", subtotalTrabajo);
            cm.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();

            // Notificar que se ha actualizado.
            OnTrabajadorXServicioUpdated();
        }

        /*
            ModificaDato
            Modifica el registro seleccionado en la tabla Operativo.TrabajadorXServicio con los datos actualizados.     
         */
        public void ModificaDato()
        {
            idTrabajador = cmb_Trabajador.Text;
            string nombreTrabajador = idTrabajador.Split('(')[0].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del trabajador.
            string queryIdTrabajador = "SELECT idTrabajador FROM Operativo.Trabajador WHERE NombreTrabajador = @Nombre";
            SqlCommand cmdIdTrabajador = new SqlCommand(queryIdTrabajador, nuevaConexion.AbrirConexion());
            cmdIdTrabajador.Parameters.AddWithValue("@Nombre", nombreTrabajador);

            var resultado = cmdIdTrabajador.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            if (resultado == null)
            {
                MessageBox.Show("Trabajador no encontrado.");
                return;
            }

            idTrabajador = resultado.ToString();

            nuevaConexion.AbrirConexion();

            // Verificar si ya existe un trabajador para este servicio.
            string queryOldIdTrabajador = "SELECT idTrabajador FROM Operativo.TrabajadorXServicio WHERE idServicio = @IdServicio";
            SqlCommand cmdOldIdTrabajador = new SqlCommand(queryOldIdTrabajador, nuevaConexion.AbrirConexion());
            cmdOldIdTrabajador.Parameters.AddWithValue("@IdServicio", idServicio);
            var resultadoOldId = cmdOldIdTrabajador.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            if (resultadoOldId == null)
            {
                MessageBox.Show("No se encontró una asociación con este servicio.");
                return;
            }

            string oldIdTrabajador = resultadoOldId.ToString();

            nuevaConexion.AbrirConexion();

            // Verificar si ya existe un trabajadorxservicio.
            string verificarExistencia = "SELECT COUNT(*) FROM Operativo.TrabajadorXServicio WHERE idServicio = @IdServicio AND idTrabajador = @IdTrabajador";
            SqlCommand cmdVerificar = new SqlCommand(verificarExistencia, nuevaConexion.AbrirConexion());
            cmdVerificar.Parameters.AddWithValue("@IdServicio", idServicio);
            cmdVerificar.Parameters.AddWithValue("@IdTrabajador", idTrabajador);

            int count = (int)cmdVerificar.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            if (count > 0)
            {
                MessageBox.Show("El trabajador ya está asociado a este servicio.");
                return;
            }

            nuevaConexion.AbrirConexion();

            // Cadena SQL para modificar un nuevo registro en la tabla Operativo.TrabajadorXServicio.
            string updateQuery = "UPDATE Operativo.TrabajadorXServicio SET idTrabajador = @Trabajador WHERE idTrabajadorXServicio = @Id";
            SqlCommand cmdUpdate = new SqlCommand(updateQuery, nuevaConexion.AbrirConexion());
            cmdUpdate.Parameters.AddWithValue("@Trabajador", idTrabajador);
            cmdUpdate.Parameters.AddWithValue("@IdServicio", idServicio);
            cmdUpdate.Parameters.AddWithValue("@Id", idTrabajadorXServicio);
            int rowsAffected = cmdUpdate.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();

            // Notificar que se ha actualizado.
            OnTrabajadorXServicioUpdated();
        }

        /*
            EliminaDato
            Elimina el registro seleccionado en la tabla Operativo.TrabajadorXServicio con los datos actualizados.
         */
        public void EliminaDato()
        {
            string trabajadorSeleccionado = cmb_Trabajador.Text;
            string nombreTrabajador = trabajadorSeleccionado.Split('(')[0].Trim();

            nuevaConexion.AbrirConexion();

            //Rescatar la concatenación del trabajador.
            string queryIdTrabajador = "SELECT idTrabajador FROM Operativo.Trabajador WHERE NombreTrabajador = @Nombre";
            SqlCommand cmdIdTrabajador = new SqlCommand(queryIdTrabajador, nuevaConexion.AbrirConexion());
            cmdIdTrabajador.Parameters.AddWithValue("@Nombre", nombreTrabajador);

            var resultado = cmdIdTrabajador.ExecuteScalar();
            nuevaConexion.CerrarConexion();

            if (resultado == null)
            {
                MessageBox.Show("Trabajador no encontrado.");
                return;
            }

            idTrabajador = resultado.ToString();

            nuevaConexion.AbrirConexion();

            // Cadena SQL para eliminar un nuevo registro en la tabla Operativo.TrabajadorXServicio.
            string delete = "DELETE FROM Operativo.TrabajadorXServicio WHERE idServicio = @IdServicio AND idTrabajador = @IdTrabajador";
            SqlCommand cmdDelete = new SqlCommand(delete, nuevaConexion.AbrirConexion());
            cmdDelete.Parameters.AddWithValue("@IdServicio", idServicio);
            cmdDelete.Parameters.AddWithValue("@IdTrabajador", idTrabajador);
            int rowsAffected = cmdDelete.ExecuteNonQuery();
            nuevaConexion.CerrarConexion();

            // Notificar que se ha actualizado.
            OnTrabajadorXServicioUpdated();
        }

        /*
            Dispara el Evento para notificar el cambio del subtotal.
         */
        protected virtual void OnTrabajadorXServicioUpdated()
        {
            SubtotalChanged?.Invoke(this, EventArgs.Empty);
        }

        /*
            btnInserta_Click
            Evento de clic del botón de inserción.
            Llama a InsertaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnInserta_Click(object sender, EventArgs e)
        {
            InsertaDato();
            ConsultaDatos();
            cmb_Trabajador.SelectedIndex = -1;
        }

        /*
            btnModifica_Click
            Evento de clic del botón de modificación.
            Llama a ModificaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnModifica_Click(object sender, EventArgs e)
        {
            ModificaDato();
            ConsultaDatos();
            cmb_Trabajador.SelectedIndex = -1;
        }

        /*
            btnElimina_Click
            Evento de clic del botón de eliminación.
            Llama a EliminaDato, actualiza el DataGridView llamando a ConsultaDatos y limpia los campos de entrada.
         */
        private void btnElimina_Click(object sender, EventArgs e)
        {
            EliminaDato();
            ConsultaDatos();
            cmb_Trabajador.SelectedIndex = -1;
        }
    }
}
