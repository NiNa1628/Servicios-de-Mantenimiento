

package com.mycompany.serviciosdemantenimiento;
import Tablas.Usuarios;

/**
 *
 * @author laptop asus
 */
public class ServiciosDeMantenimiento {

    public static void main(String[] args){
        Usuarios tabla = new Usuarios();
        tabla.setVisible(true);
    }
}
