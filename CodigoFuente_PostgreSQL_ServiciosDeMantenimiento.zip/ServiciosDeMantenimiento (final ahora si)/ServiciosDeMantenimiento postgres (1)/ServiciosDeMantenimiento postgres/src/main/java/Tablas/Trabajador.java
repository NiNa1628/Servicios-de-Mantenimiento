// Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  Servicio.
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
    Clase para gestionar el manejo de los trabajadores dentro de los Servicios de Mantenimiento
    Proporciona métodos para consultar, insertar, modificar y eliminar datos.
 */
public class Trabajador extends javax.swing.JFrame 
{
    private String usuario;
    private String rol;
    int idTrabajador = -1;
 
    // Lista que almacena objetos de tipo DetalleTrabajador.
    private List<DetalleTrabajador> detalleTrabajadorForms = new ArrayList<DetalleTrabajador>();
    
    /* 
        Constructor del formulario DetalleTrabajador.
        Inicializa el formulario y carga los datos de la tabla DetalleTrabajador en el JTable.
    */
    public Trabajador(String usuario, String rol) 
    {
        this.usuario = usuario;
        this.rol = rol;
        initComponents();
        ConsultaDatos();
        configurarPermisos();
    }
    
    /*
        configurarPermisos
        Permite deshabilitar los botones de Insertar, Modificar y Eliminar para el usuario Empleado
    */
    public void configurarPermisos()
    {
        if(rol.equals("Empleado")){
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        }
    }
    
    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Operativo.Trabajador en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos() 
    {
        String[] datos = new String[5];
        DefaultTableModel model = new DefaultTableModel(new String[]{
            "Id Trabajador","RFC del Trabajador", "Nombre del Trabajador", "Teléfono del Trabajador", "Email del Trabajador"
        }, 0);
        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            // Conexión a la base de datos de Postgres.
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            String sql = "SELECT * FROM Operativo.Trabajador";
            stmt = bd.prepareStatement(sql);
            rs = stmt.executeQuery();
            TablaTrabajador.setModel(model);

            // Agrega los valores a una nueva fila para almacenarlos en el JTable.
            while (rs.next()) {
                datos[0] = String.valueOf(rs.getInt("idTrabajador"));
                datos[1] = rs.getString("RFCTrabajador");
                datos[2] = rs.getString("nombreTrabajador");
                datos[3] = rs.getString("telefonoTrabajador");
                datos[4] = rs.getString("emailTrabajador");
                model.addRow(datos);
            }
            rs.close();
            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los trabajadores.");
        }
    }
    
    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Operativo.Trabajador con los datos ingresados.
        Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
    */
    private void InsertaDato() 
    {
        String rfc = txtRFCTrabajador.getText();
        String nombre = txtNomTrabajador.getText();
        String telefono = txtTelTrabajador.getText();
        String email = txtEmailTrabajador.getText();

        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establece la conexión a la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            // Verifica si el RFC, teléfono o correo ya existen
            String verifica = "SELECT COUNT(*) FROM Operativo.Trabajador WHERE RFCTrabajador = ? OR telefonoTrabajador = ? OR emailTrabajador= ?";
            stmt = bd.prepareStatement(verifica);
            stmt.setString(1, rfc);
            stmt.setString(2, telefono);
            stmt.setString(3, email);

            // Ejecuta la consulta
            rs = stmt.executeQuery();
            int count = 0;
            if (rs.next()) {
                count = rs.getInt(1);
            }

            if (count > 0) {
                JOptionPane.showMessageDialog(null, "El RFC, teléfono o correo electrónico ya están en uso.");
                txtRFCTrabajador.setText("");
                txtNomTrabajador.setText("");
                txtTelTrabajador.setText("");
                txtEmailTrabajador.setText("");
            } else {
                // Inserta el nuevo proveedor
                String sql = "INSERT INTO Operativo.Trabajador (RFCTrabajador, nombreTrabajador, telefonoTrabajador, emailTrabajador) VALUES (?, ?, ?,?)";
                stmt.close();
                stmt = bd.prepareStatement(sql);
                stmt.setString(1, rfc);
                stmt.setString(2, nombre);
                stmt.setString(3, telefono);
                stmt.setString(4, email);

                stmt.executeUpdate();
                txtRFCTrabajador.setText("");
                txtNomTrabajador.setText("");
                txtTelTrabajador.setText("");
                txtEmailTrabajador.setText("");

                rs.close();
                stmt.close();
                bd.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al insertar el trabajador: " + ex.getMessage());
        }
    }
    
    /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Operativo.Trabajador con los datos actualizados.
        Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
     */
    private void ModificaDato(int idTrabajador) 
    {
        String rfc = txtRFCTrabajador.getText();
        String nombre = txtNomTrabajador.getText();
        String telefono = txtTelTrabajador.getText();
        String email = txtEmailTrabajador.getText();

        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establece la conexión a la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            // Verifica si el RFC, teléfono o correo ya existen
            String verifica = "SELECT COUNT(*) FROM Operativo.Trabajador WHERE RFCTrabajador = ? OR telefonoTrabajador = ? OR emailTrabajador= ?";
            stmt = bd.prepareStatement(verifica);
            stmt.setString(1, rfc);
            stmt.setString(2, telefono);
            stmt.setString(3, email);

            // Ejecuta la consulta
            rs = stmt.executeQuery();
            int count = 0;
            if (rs.next()) {
                count = rs.getInt(1);
            }

            if (count > 0 && !nombre.equals(txtNomTrabajador.getText())) {
                JOptionPane.showMessageDialog(null, "El RFC, teléfono o correo electrónico ya están en uso.");
                txtRFCTrabajador.setText("");
                txtNomTrabajador.setText("");
                txtTelTrabajador.setText("");
                txtEmailTrabajador.setText("");
            } else {
                // Modifica el proveedor en la base de datos
                String sql = "UPDATE Operativo.Trabajador SET RFCTrabajador = ?,nombreTrabajador = ?, telefonoTrabajador = ?, emailTrabajador = ? WHERE idTrabajador = ?";
                stmt = bd.prepareStatement(sql);
                stmt.setString(1, rfc);
                stmt.setString(2, nombre);
                stmt.setString(3, telefono);
                stmt.setString(4, email);
                stmt.setInt(5,idTrabajador);

                stmt.executeUpdate();
                
                txtRFCTrabajador.setText("");
                txtNomTrabajador.setText("");
                txtTelTrabajador.setText("");
                txtEmailTrabajador.setText("");

                stmt.close();
                bd.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar el trabajador.");
        }
    }
    
    /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Operativo.Trabajador con los datos actualizados.
     */
    private void EliminaDato(int idTrabajador) 
    {
        Connection bd = null;
        PreparedStatement stmt = null;

        try {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            String sql = "DELETE FROM Operativo.Trabajador WHERE idTrabajador = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idTrabajador);

            stmt.executeUpdate();
            
            txtRFCTrabajador.setText("");
            txtNomTrabajador.setText("");
            txtTelTrabajador.setText("");
            txtEmailTrabajador.setText("");

            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el trabajador.");
        }
    }
    
    /*
        SeleccionaDato
        Selecciona los datos del trabajador y los muestra en los campos de texto correspondientes.
    */
    private void SeleccionaDato(int idTrabajador) 
    {
        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            String sql = "SELECT RFCTrabajador, nombreTrabajador, telefonoTrabajador, emailTrabajador FROM Operativo.Trabajador WHERE idTrabajador = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idTrabajador);
            rs = stmt.executeQuery();
            if (rs.next()) {
                txtRFCTrabajador.setText(rs.getString("RFCTrabajador"));
                txtNomTrabajador.setText(rs.getString("nombreTrabajador"));
                txtTelTrabajador.setText(rs.getString("telefonoTrabajador"));
                txtEmailTrabajador.setText(rs.getString("emailTrabajador"));
            }
            rs.close();
            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener los datos del trabajador.");
            ex.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNomTrabajador = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtTelTrabajador = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtEmailTrabajador = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnDetalleTrabajador = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaTrabajador = new javax.swing.JTable();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        txtRFCTrabajador = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Trabajador");

        txtNomTrabajador.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("RFC del Trabajador:");

        txtTelTrabajador.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Nombre del Trabajador:");

        txtEmailTrabajador.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Teléfono  del Trabajador:");

        btnDetalleTrabajador.setText("Detalles del Trabajador");
        btnDetalleTrabajador.setEnabled(false);
        btnDetalleTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetalleTrabajadorActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Email del Trabajador:");

        TablaTrabajador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TablaTrabajador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaTrabajadorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaTrabajador);

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        txtRFCTrabajador.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNomTrabajador, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                            .addComponent(txtTelTrabajador, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtRFCTrabajador, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnModificar)
                                .addComponent(txtEmailTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 424, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnInsertar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnEliminar)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(btnDetalleTrabajador)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtRFCTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNomTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTelTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEmailTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDetalleTrabajador)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnDetalleTrabajadorActionPerformed
        Evento que se dispara al hacer clic en el botón de Detalle del Trabajador.
        Abre el formulario DetalleTrabajador para gestionar los detalles trabajadores.
     */
    private void btnDetalleTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetalleTrabajadorActionPerformed
        if(idTrabajador != -1)
        {
            DetalleTrabajador detalleTrabajadorForm = new DetalleTrabajador(idTrabajador);
            detalleTrabajadorForms.add(detalleTrabajadorForm);
            detalleTrabajadorForm.setVisible(true);
        }
    }//GEN-LAST:event_btnDetalleTrabajadorActionPerformed

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
        Llama al método SeleccionaDato para cargar los datos del cliente en los campos de texto.
    */
    private void TablaTrabajadorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaTrabajadorMouseClicked
        int fila = TablaTrabajador.getSelectedRow();
        if(fila >= 0) {
            idTrabajador = Integer.parseInt(TablaTrabajador.getValueAt(fila, 0).toString());
            SeleccionaDato(idTrabajador);
            
            if(rol.equals("Admin")){
                btnDetalleTrabajador.setEnabled(true);
            }
        }
        else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_TablaTrabajadorMouseClicked

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato();
        ConsultaDatos();
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idTrabajador, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaTrabajador.getSelectedRow();
        if(fila >= 0){
            int idTrabajador = Integer.parseInt(TablaTrabajador.getValueAt(fila, 0).toString());
            ModificaDato(idTrabajador);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idCliente, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaTrabajador.getSelectedRow();
        if(fila >= 0){
            int idTrabajador = Integer.parseInt(TablaTrabajador.getValueAt(fila, 0).toString());
            EliminaDato(idTrabajador);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    public static void main(String args[]) {
        String usuario = "";
        String rol = "";
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Trabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Trabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Trabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Trabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Trabajador(usuario, rol).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaTrabajador;
    private javax.swing.JButton btnDetalleTrabajador;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtEmailTrabajador;
    private javax.swing.JTextField txtNomTrabajador;
    private javax.swing.JTextField txtRFCTrabajador;
    private javax.swing.JTextField txtTelTrabajador;
    // End of variables declaration//GEN-END:variables
}
