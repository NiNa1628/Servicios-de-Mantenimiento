//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario Cliente 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
    Clase para gestionar el manejo de la Consulta 1 en Servicios de Mantenimiento
    a) Consulta 1: Uso de GROUP BY, COUNT e INNER JOIN
*/
public class Consulta1 extends javax.swing.JFrame {
    private String nombreProveedor = "";

    /**
     * Constructor del formulario Consulta1.
     * Inicializa el formulario.
     */
    public Consulta1() 
    {
        initComponents();
        cargarProveedores();
        consultaTabla();
        cmbConsulta1.setSelectedIndex(-1);
    }

    /*
        consulta
        Recupera y muestra todos los registros en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void consulta() 
    {
        nombreProveedor = cmbConsulta1.getSelectedItem().toString();
        
        String[] columnas = {"Proveedor", "Material", "Total Compras"};
        DefaultTableModel model = new DefaultTableModel(columnas, 0);
        
        String sql = "SELECT p.nombreProveedor AS NombreProveedor, "
                   + "m.nombreMaterial AS NombreMaterial, "
                   + "COUNT(c.idCompra) AS TotalCompras "
                   + "FROM Comercial.Proveedor p "
                   + "INNER JOIN Comercial.Compra c ON p.idProveedor = c.idProveedor "
                   + "INNER JOIN Comercial.DetalleCompra dc ON c.idCompra = dc.idCompra "
                   + "INNER JOIN Operativo.Material m ON dc.idMaterial = m.idMaterial "
                   + "WHERE p.nombreProveedor = ? "
                   + "GROUP BY p.nombreProveedor, m.nombreMaterial";

        try (Connection bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
             PreparedStatement stmt = bd.prepareStatement(sql)) {

            stmt.setString(1, nombreProveedor);
            try (ResultSet rs = stmt.executeQuery()) 
            {
                TablaConsulta.setModel(model);
                // Agrega los valores a una nueva fila para almacenarlos en el JTable
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("NombreProveedor"),
                        rs.getString("NombreMaterial"),
                        rs.getInt("TotalCompras")
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos: " + ex.getMessage());
            }
    }
    
    /*
        consultaTabla
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void consultaTabla() 
    {
        nombreProveedor = "";
        
        String[] columnas = {"Proveedor", "Material", "Total Compras"};
        DefaultTableModel model = new DefaultTableModel(columnas, 0);
        
        String sql = "SELECT p.nombreProveedor AS NombreProveedor, "
                   + "m.nombreMaterial AS NombreMaterial, "
                   + "COUNT(c.idCompra) AS TotalCompras "
                   + "FROM Comercial.Proveedor p "
                   + "INNER JOIN Comercial.Compra c ON p.idProveedor = c.idProveedor "
                   + "INNER JOIN Comercial.DetalleCompra dc ON c.idCompra = dc.idCompra "
                   + "INNER JOIN Operativo.Material m ON dc.idMaterial = m.idMaterial "
                   + "WHERE p.nombreProveedor = ? "
                   + "GROUP BY p.nombreProveedor, m.nombreMaterial";

        try (Connection bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
             PreparedStatement stmt = bd.prepareStatement(sql)) {

            stmt.setString(1, nombreProveedor);
            try (ResultSet rs = stmt.executeQuery()) 
            {
                TablaConsulta.setModel(model);
                // Agrega los valores a una nueva fila para almacenarlos en el JTable
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("NombreProveedor"),
                        rs.getString("NombreMaterial"),
                        rs.getInt("TotalCompras")
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos: " + ex.getMessage());
            }
    }
    
    /**
     * Carga la información de los proveedores desde la base de datos y la muestra en un JComboBox.
     */
    public void cargarProveedores() 
    {
        String sql = "SELECT nombreProveedor FROM Comercial.Proveedor";

        try (Connection bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
             PreparedStatement stmt = bd.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            // Limpiar el JComboBox antes de agregar datos
            cmbConsulta1.removeAllItems();

            // Leer cada proveedor del resultado de la consulta
            while (rs.next()) {
                cmbConsulta1.addItem(rs.getString("nombreProveedor"));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los proveedores: " + ex.getMessage());
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaConsulta = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnConsulta = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cmbConsulta1 = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Consulta 1");

        TablaConsulta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TablaConsulta);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Consulta 1");

        btnConsulta.setText("Consultar");
        btnConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("desglosando el resultado por cada material que haya sido adquirido.");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Obtiene el total de compras realizadas por el proveedor seleccionado,");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Proveedor:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel2)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(173, 173, 173)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(cmbConsulta1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnConsulta)))
                        .addGap(0, 8, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbConsulta1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConsulta))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnConsultaActionPerformed
        Evento de clic del botón de Consulta.
        Llama al método para realizar la consulta. 
    */
    private void btnConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultaActionPerformed
        consulta();
    }//GEN-LAST:event_btnConsultaActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Consulta1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Consulta1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Consulta1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Consulta1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consulta1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaConsulta;
    private javax.swing.JButton btnConsulta;
    private javax.swing.JComboBox<String> cmbConsulta1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
