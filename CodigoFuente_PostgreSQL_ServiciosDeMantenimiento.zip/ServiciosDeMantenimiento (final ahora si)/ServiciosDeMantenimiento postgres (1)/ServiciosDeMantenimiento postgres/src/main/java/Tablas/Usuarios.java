//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  Usuarios.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/*
   Clase para gestionar el manejo de los usuarios para la gestión de los servicios dentro de los Servicios de Mantenimiento
   Proporciona métodos para conexión, inicio de sesión, obtener el rol y abrir el menú.
*/
public class Usuarios extends javax.swing.JFrame 
{
    private String usuario;
    private String rol;
    
    /* 
        Constructor del formulario Usuarios.
        Inicializa el formulario.
    */
    public Usuarios() {
        initComponents();
    }
    
    /*
        connectToDatabase
        Realiza la conexión con la base de datos.
    */
    private Connection connectToDatabase(String username, String password) 
    {
        Connection connection = null;
        String url = "jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento"; // URL de tu base de datos
        try {
            // Cargar el controlador JDBC
            Class.forName("org.postgresql.Driver");
            // Conectarse con las credenciales ingresadas
            connection = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(this, "Error al conectar a la base de datos: " + e.getMessage());
        }
        return connection;
    }
    
    /*
        iniciarSesion
        Regresa el usuario al inciciar correctamente sesión con el usuario y contraseña correcta de la base de datos.
    */
    public String iniciarSesion() 
    {
        usuario = txtUsuario.getText(); // Campo de texto del usuario
        String contraseña = new String(txtContraseña.getPassword()); // Campo de contraseña
        Connection bd = connectToDatabase(usuario, contraseña);
         if (bd != null) {
            rol = obtenerRolDeUsuario(usuario);
            //JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso como: " + usuario);
            abrirMenu(usuario, rol);
            try {
                bd.close(); // Cerrar la conexión después de usarla
            } catch (Exception e) {
                //JOptionPane.showMessageDialog(this, "Error al cerrar la conexión: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos incorrectas.");
        } 
        return usuario;
    }

    /*
        obtenerRolDeUsuario
        Obtiene el tipo de Rol del usuario.
    */
    private String obtenerRolDeUsuario(String usuario) 
    {
        if (usuario.equals("gerente")) {
            return "Gerente";
        } else if (usuario.equals("empleado")) {
            return "Empleado";
        } else {
            return "Admin"; // Aquí se podría incluir otro tipo de rol
        }
    }
    
    /*
        abrirMenu
        Crea un nuevo formulario Menu.
    */
    private void abrirMenu(String usuario, String rol) 
    {
        Menu menu = new Menu(usuario, rol);
        menu.setVisible(true);
        this.dispose();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        buttonLogin = new javax.swing.JButton();
        txtContraseña = new javax.swing.JPasswordField();
        txtUsuario = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Acceso");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Usuario: ");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Contraseña: ");

        buttonLogin.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        buttonLogin.setText("Login");
        buttonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLoginActionPerformed(evt);
            }
        });

        txtContraseña.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        txtUsuario.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(txtContraseña))
                .addGap(18, 18, 18))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(buttonLogin)
                .addGap(144, 144, 144))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(buttonLogin)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        buttonLoginActionPerformed
        Evento que se dispara al hacer clic en el botón de Login.
        Abre el formulario de Menu como un cuadro de diálogo, permitiendo gestionar la base de datos.
    */
    private void buttonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLoginActionPerformed
       iniciarSesion(); 
    }//GEN-LAST:event_buttonLoginActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Usuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonLogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField txtContraseña;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
