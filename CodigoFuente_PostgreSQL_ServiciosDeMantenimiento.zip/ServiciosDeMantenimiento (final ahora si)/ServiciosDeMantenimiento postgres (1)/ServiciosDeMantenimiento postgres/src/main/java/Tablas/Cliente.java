//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario Cliente 
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
    Clase para gestionar el manejo de los clientes dentro de los Servicios de Mantenimiento
    Proporciona métodos para consultar, insertar, modificar y eliminar datos.
 */
public class Cliente extends javax.swing.JFrame 
{
    int idCliente = -1;
    private String usuario;
    private String rol;
    
    // Lista que almacena objetos de tipo DomicilioCliente.
    private List<DomicilioCliente> domicilioClienteForms = new ArrayList<DomicilioCliente>();
    
    /* 
        Constructor del formulario Cliente.
        Inicializa el formulario y carga los datos de la tabla Cliente en el JTable.
    */
    public Cliente(String usuario, String rol) 
    {
        this.usuario = usuario;
        this.rol = rol;
        initComponents();
        ConsultaDatos();
        configurarPermisos();
    }
    
    /*
        configurarPermisos
        Permite deshabilitar los botones de Insertar, Modificar y Eliminar para el usuario Empleado
    */
    public void configurarPermisos()
    {
        if(rol.equals("Empleado")){
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        }
    }
    
    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Comercial.Cliente en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos()
    {

    String[] datos = new String[5];
    DefaultTableModel model = new DefaultTableModel(new String[]{"Id Cliente",
    "RFC del Cliente", "Nombre del Cliente", "Teléfono del Cliente", "Email del Cliente"}, 0);
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
   try
    { 
        // Conexión a la base de datos de Postgres.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
        String sql = "SELECT * FROM Comercial.Cliente";
        stmt = bd.prepareStatement(sql);
        rs = stmt.executeQuery();
        TablaCliente.setModel(model);
        
        // Agrega los valores a una nueva fila para almacenarlos en el JTable.
        while(rs.next()){
        datos[0] = String.valueOf(rs.getInt("idCliente"));
        datos[1] = rs.getString("RFCCliente");
        datos[2] = rs.getString("nombreCliente");
        datos[3] = rs.getString("telefonoCliente");
        datos[4] = rs.getString("emailCliente");
        model.addRow(datos);
    }
    rs.close();
    stmt.close();
    bd.close();
    } catch(SQLException ex){
        JOptionPane.showMessageDialog(null, "Error al cargar el Cliente.");
        }
    }
    
    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Comercial.Cliente con los datos ingresados.
        Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
    */
    private void InsertaDato() 
    {
    String rfc = txtRFCCliente.getText();
    String nombre = txtNombreCliente.getText();
    String telefono = txtTelefonoCliente.getText();
    String email = txtEmailCliente.getText();

    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
            // Establece la conexión a la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            // Verifica si el RFC, teléfono o correo ya existen
            String verifica = "SELECT COUNT(*) FROM Comercial.Cliente WHERE RFCCliente = ? OR telefonoCliente = ? OR emailCliente = ?";
            stmt = bd.prepareStatement(verifica);
            stmt.setString(1, rfc);
            stmt.setString(2, telefono);
            stmt.setString(3, email);

            // Ejecuta la consulta
            rs = stmt.executeQuery();
            int count = 0;
            if (rs.next()) {
                count = rs.getInt(1);
            }

            if (count > 0) {
                JOptionPane.showMessageDialog(null, "El RFC, el teléfono o el correo electrónico ya están en uso.");

                txtRFCCliente.setText("");
                txtNombreCliente.setText("");
                txtTelefonoCliente.setText("");
                txtEmailCliente.setText("");
            } else {
                // Inserta el nuevo cliente
                String sql = "INSERT INTO Comercial.Cliente (RFCCliente, nombreCliente, telefonoCliente, emailCliente) VALUES (?, ?, ?, ?)";
                stmt.close();
                stmt = bd.prepareStatement(sql);
                stmt.setString(1, rfc);
                stmt.setString(2, nombre);
                stmt.setString(3, telefono);
                stmt.setString(4, email);

                stmt.executeUpdate();

                txtRFCCliente.setText("");
                txtNombreCliente.setText("");
                txtTelefonoCliente.setText("");
                txtEmailCliente.setText("");

                rs.close();
                stmt.close();
                bd.close();
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al insertar el Cliente: " + ex.getMessage());
        }
    }
    
    /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Comercial.Cliente con los datos actualizados.
        Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
    */
    private void ModificaDato(int idCliente)
    {
        String rfc = txtRFCCliente.getText();
        String nombre = txtNombreCliente.getText();
        String telefono = txtTelefonoCliente.getText();
        String email = txtEmailCliente.getText();
        
        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try
        {
            // Establece la conexión a la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            // Verifica si el RFC, teléfono o correo ya existen
            String verifica = "SELECT COUNT(*) FROM Comercial.Cliente WHERE RFCCliente = ? OR telefonoCliente = ? OR emailCliente = ?";
            stmt = bd.prepareStatement(verifica);
            stmt.setString(1, rfc);
            stmt.setString(2, telefono);
            stmt.setString(3, email);

            // Ejecuta la consulta
            rs = stmt.executeQuery();
            int count = 0;
            if (rs.next()) {
                count = rs.getInt(1);
            }

            if (count > 0) {
                JOptionPane.showMessageDialog(null, "El RFC, el teléfono o el correo electrónico ya están en uso.");

                txtRFCCliente.setText("");
                txtNombreCliente.setText("");
                txtTelefonoCliente.setText("");
                txtEmailCliente.setText("");
            } else {
                bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
           "postgres");
                String sql = "UPDATE Comercial.Cliente SET RFCCliente = ?, nombreCliente = ?, telefonoCliente = ?, emailCliente = ? WHERE idCliente = ?";
                stmt = bd.prepareStatement(sql);
                stmt.setString(1, rfc);
                stmt.setString(2, nombre);
                stmt.setString(3, telefono);
                stmt.setString(4, email);
                stmt.setInt(5, idCliente);

                stmt.executeUpdate();

                txtRFCCliente.setText("");
                txtNombreCliente.setText("");
                txtTelefonoCliente.setText("");
                txtEmailCliente.setText("");

                stmt.close();
                bd.close();
        }
    }catch(SQLException ex){
       JOptionPane.showMessageDialog(null, "Error al modificar el Cliente.");
        }
    }
    
    /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Comercial.Cliente con los datos actualizados.
    */
    private void EliminaDato(int idCliente)
    {
        Connection bd = null;
        PreparedStatement stmt = null;

        try
        {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
            String sql = "DELETE FROM Comercial.Cliente WHERE idCliente = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idCliente);
            
            stmt.executeUpdate();
            
            txtRFCCliente.setText("");
            txtNombreCliente.setText("");
            txtTelefonoCliente.setText("");
            txtEmailCliente.setText("");
            
            stmt.close();
            bd.close();
    }catch(SQLException ex){
       JOptionPane.showMessageDialog(null, "Error al eliminar el Cliente.");
        }
    }
    
    /*
        SeleccionaDato
        Selecciona los datos del cliente y los muestra en los campos de texto correspondientes.
    */
    private void SeleccionaDato(int idCliente)
    {
        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try
        {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
            String sql = "SELECT RFCCliente, nombreCliente, telefonoCliente, emailCliente FROM Comercial.Cliente WHERE idCliente = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idCliente);
            rs = stmt.executeQuery();
            if (rs.next()) {
                txtRFCCliente.setText(rs.getString("RFCCliente"));
                txtNombreCliente.setText(rs.getString("nombreCliente"));
                txtTelefonoCliente.setText(rs.getString("telefonoCliente"));
                txtEmailCliente.setText(rs.getString("emailCliente"));
        }
        rs.close();
        stmt.close();
        bd.close();
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener los datos del Cliente.");
        ex.printStackTrace();
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        txtRFCCliente = new javax.swing.JTextField();
        txtEmailCliente = new javax.swing.JTextField();
        txtTelefonoCliente = new javax.swing.JTextField();
        btnInsertar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaCliente = new javax.swing.JTable();
        btnDomicilioCliente = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cliente");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("RFC Cliente:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Nombre Cliente:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Teléfono Cliente:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Email Cliente:");

        txtNombreCliente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtRFCCliente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtEmailCliente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtTelefonoCliente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        TablaCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TablaCliente.setToolTipText("");
        TablaCliente.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        TablaCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaCliente);

        btnDomicilioCliente.setText("Domicilio del Cliente");
        btnDomicilioCliente.setEnabled(false);
        btnDomicilioCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDomicilioClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 494, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtRFCCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnInsertar))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnModificar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnEliminar))
                                    .addComponent(txtEmailCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(172, 172, 172)
                .addComponent(btnDomicilioCliente)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtRFCCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEmailCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(btnDomicilioCliente)
                .addContainerGap())
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato();
        ConsultaDatos();
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idCliente, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaCliente.getSelectedRow();
        if(fila >= 0){
            int idCliente = Integer.parseInt(TablaCliente.getValueAt(fila, 0).toString());
            ModificaDato(idCliente);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idCliente, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaCliente.getSelectedRow();
        if(fila >= 0){
            int idCliente = Integer.parseInt(TablaCliente.getValueAt(fila, 0).toString());
            EliminaDato(idCliente);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
        Llama al método SeleccionaDato para cargar los datos del cliente en los campos de texto.
    */
    private void TablaClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaClienteMouseClicked
        int fila = TablaCliente.getSelectedRow();
        if(fila >= 0) {
        idCliente = Integer.parseInt(TablaCliente.getValueAt(fila, 0).toString());
        SeleccionaDato(idCliente);
        
        if(rol.equals("Admin")){
        btnDomicilioCliente.setEnabled(true);
            }
        }
        else {
        JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_TablaClienteMouseClicked

    private void btnDomicilioClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDomicilioClienteActionPerformed
        if(idCliente != -1)
        {
            DomicilioCliente domicilioClienteForm = new DomicilioCliente(idCliente);
            domicilioClienteForms.add(domicilioClienteForm);
            domicilioClienteForm.setVisible(true);
        }
    }//GEN-LAST:event_btnDomicilioClienteActionPerformed

    public static void main(String args[]) {
        String usuario = "";
        String rol = "";
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente(usuario, rol).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaCliente;
    private javax.swing.JButton btnDomicilioCliente;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtEmailCliente;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtRFCCliente;
    private javax.swing.JTextField txtTelefonoCliente;
    // End of variables declaration//GEN-END:variables
}
