//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario Cliente 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
    Clase para gestionar el manejo de la Consulta 1 en Servicios de Mantenimiento
    b) Consulta 2: Realizar subconsultas
*/
public class Consulta2 extends javax.swing.JFrame 
{  
    /* 
        Constructor del formulario Consulta2.
        Inicializa el formulario.
    */
    public Consulta2() {
        initComponents();
        cargarServicios();
        consultaTabla();
        cmbConsulta1.setSelectedIndex(-1);
    }
    
    /*
        consulta
        Recupera y muestra todos los registros en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void consulta() 
    {
        String servicioSeleccionado = cmbConsulta1.getSelectedItem().toString();
        String idServicio = servicioSeleccionado.split(" - ")[0].trim();
        int servicio = Integer.parseInt(idServicio);

        String[] columnas = {"Servicio", "Fecha de Inicio", "Fecha de Final", "Total Materiales"};
        DefaultTableModel model = new DefaultTableModel(columnas, 0);

        String sql = "SELECT s.idServicio, s.fechaInicio, s.fechaFinal, " +
                     "CONCAT(s.idServicio, ' - ', c.nombreCliente) AS ServicioCliente, " +
                     "COALESCE((SELECT SUM(mx.cantMaterial) " +
                     "FROM Operativo.MaterialXServicio mx WHERE mx.idServicio = s.idServicio), 0) AS TotalMateriales " +
                     "FROM Operativo.Servicio s " +
                     "JOIN Comercial.DomicilioCliente dc ON s.idDomicilio = dc.idDomicilio " +
                     "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente " +
                     "WHERE s.idServicio = ?";

        try (Connection bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
             PreparedStatement stmt = bd.prepareStatement(sql)) {

            stmt.setInt(1, servicio);

            try (ResultSet rs = stmt.executeQuery()) 
            {
                TablaConsulta.setModel(model);
                // Agrega los valores a una nueva fila para almacenarlos en el JTable
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("ServicioCliente"),
                        rs.getString("fechaInicio"),
                        rs.getString("fechaFinal"),
                        rs.getInt("TotalMateriales")
                    });
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos: " + ex.getMessage());
        }
    }
    
    /*
        consultaTabla
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void consultaTabla()
    {
        int servicio = -1;
        String[] columnas = {"Servicio", "Fecha de Inicio", "Fecha de Final", "Total Materiales"};
        DefaultTableModel model = new DefaultTableModel(columnas, 0);
            String sql = "SELECT s.idServicio, s.fechaInicio, s.fechaFinal, " +
             "CONCAT(s.idServicio, ' - ', c.nombreCliente) AS ServicioCliente, " +
             "COALESCE((SELECT SUM(mx.cantMaterial) " +
             "FROM Operativo.MaterialXServicio mx WHERE mx.idServicio = s.idServicio), 0) AS TotalMateriales " +
             "FROM Operativo.Servicio s " +
             "JOIN Comercial.DomicilioCliente dc ON s.idDomicilio = dc.idDomicilio " +
             "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente " +
             "WHERE s.idServicio = ?";
            
            try (Connection bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
             PreparedStatement stmt = bd.prepareStatement(sql)) {

            stmt.setInt(1, servicio);
            try (ResultSet rs = stmt.executeQuery()) 
            {
                TablaConsulta.setModel(model);
                // Agrega los valores a una nueva fila para almacenarlos en el JTable
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("ServicioCliente"),
                        rs.getString("fechaInicio"),
                        rs.getString("fechaFinal"),
                        rs.getInt("TotalMateriales")
                    });
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos: " + ex.getMessage());
        }
    }
    
    /**
     * Carga la información de los servicios desde la base de datos y la muestra en un JComboBox.
     */
    public void cargarServicios() 
    {
        String sql = "SELECT s.idServicio, CONCAT(s.idServicio, ' - ', c.nombreCliente) AS ServicioCliente " +
                     "FROM Operativo.Servicio s " +
                     "JOIN Comercial.DomicilioCliente dc ON s.idDomicilio = dc.idDomicilio " +
                     "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente";

        try (Connection bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
             PreparedStatement stmt = bd.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            // Limpiar el JComboBox antes de agregar datos
            cmbConsulta1.removeAllItems();

            // Leer cada servicio del resultado de la consulta
            while (rs.next()) {
                cmbConsulta1.addItem(rs.getString("ServicioCliente"));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los servicios: " + ex.getMessage());
            }
        }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaConsulta = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnConsulta = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        cmbConsulta1 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Conuslta 2");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("incluyendo la fecha de inicio, la fecha final y el total de materiales");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Obtener la información del servicio especificado por su identificador");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("utilizados en dicho servicio, sumando las cantidades asociadas a ");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("cada material.");

        TablaConsulta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TablaConsulta);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Consulta 2");

        btnConsulta.setText("Consultar");
        btnConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultaActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Id Servicio:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(173, 173, 173)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(187, 187, 187)
                                .addComponent(jLabel5)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(cmbConsulta1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnConsulta)
                .addGap(48, 48, 48))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbConsulta1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConsulta))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnConsultaActionPerformed
        Evento de clic del botón de Consulta.
        Llama al método para realizar la consulta. 
    */
    private void btnConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultaActionPerformed
        consulta();
    }//GEN-LAST:event_btnConsultaActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Consulta2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Consulta2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Consulta2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Consulta2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consulta2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaConsulta;
    private javax.swing.JButton btnConsulta;
    private javax.swing.JComboBox<String> cmbConsulta1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
