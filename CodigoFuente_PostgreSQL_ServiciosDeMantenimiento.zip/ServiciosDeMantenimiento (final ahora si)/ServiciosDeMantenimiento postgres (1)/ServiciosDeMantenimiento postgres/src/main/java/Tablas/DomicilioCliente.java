// Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  Servicio.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
    Clase para gestionar el manejo de los detalles de los trabajadores dentro de los Servicios de Mantenimiento
    Proporciona métodos para consultar, insertar, modificar y eliminar datos.
 */
public class DomicilioCliente extends javax.swing.JFrame 
{
    int idCliente = -1;
    
    /* 
        Constructor del formulario DetalleTrabajador.
        Inicializa el formulario y carga los datos de la tabla DetalleTrabajador en el JTable.
    */
    public DomicilioCliente(int idCliente) 
    {
        initComponents();
        this.idCliente = idCliente;
        ConsultaDatos(idCliente);
    }

    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Operativo.DetalleTrabajador en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos(int idCliente) 
    {
    String[] datos = new String[3];
    DefaultTableModel model = new DefaultTableModel(new String[]{"Id Domicilio", "Cliente", "Domicilio del Cliente"}, 0);
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
        
        // Consulta con JOIN para obtener el nombre del trabajador
        String sql = "SELECT d.idDomicilio, d.idCliente, d.domicilioCliente, " +
                                "c.NombreCliente, c.RFCCliente " +
                                "FROM Comercial.DomicilioCliente d " +
                                "JOIN Comercial.Cliente c ON d.idCliente = c.idCliente " +
                                "WHERE c.idCliente = ?";
        stmt = bd.prepareStatement(sql);
        stmt.setInt(1, idCliente);
        rs = stmt.executeQuery();

        TablaDomicilioCliente.setModel(model);

        while (rs.next()) 
        {
            String nombreCliente = rs.getString("NombreCliente");
            String rfcCliente = rs.getString("RFCCliente");
            String cliente = nombreCliente + " - " + rfcCliente.substring(rfcCliente.length() - 3);
            datos[0] = rs.getString("idDomicilio");
            datos[1] = cliente;
            datos[2] = rs.getString("domicilioCliente");
            model.addRow(datos);
        }
        // Cerrar conexiones.
            rs.close();
            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar el Material del Servicio: " + ex.getMessage());
            }
        }
    
    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Operativo.DetalleTrabajador con los datos ingresados.
        Si ocurre un error(como duplicación de la profesión), muestra un mensaje de error.
    */
     private void InsertaDato(int idCliente) 
     {
        Connection bd = null;
        PreparedStatement stmt = null; 
        ResultSet rs = null; 
        
        try {
            // Establecer conexión con la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            
            // Obtener datos del formulario
            String domicilio = txtDomicilio.getText();

            //Verifica si domicilio ya existe.
            String verificaProfesion = "SELECT COUNT(*) FROM Comercial.DomicilioCliente WHERE idCliente = ? AND domicilioCliente = ?";
            stmt = bd.prepareStatement(verificaProfesion);
            stmt.setInt(1, idCliente);
            stmt.setString(2, domicilio);
            rs = stmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(null, "El domicilio ya existe para este cliente.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String sql = "INSERT INTO Comercial.DomicilioCliente (idCliente, domicilioCliente) VALUES (?, ?)";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idCliente);
            stmt.setString(2, domicilio);

            stmt.executeUpdate();

            // Limpia los campos después de insertar
            txtDomicilio.setText("");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al insertar el domicilio del cliente: " + ex.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (bd != null) bd.close();
            } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
     /*
    ModificaDato
    Modifica el registro seleccionado en la tabla Comercial.DomicilioCliente con los datos actualizados.
    Si ocurre un error (como duplicación de domicilio), muestra un mensaje de error.
*/
private void ModificaDato(int idCliente) 
{
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        int fila = TablaDomicilioCliente.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(null, "Seleccione un domicilio para modificar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtén el ID del domicilio desde la tabla
        int idDomicilio = Integer.parseInt(TablaDomicilioCliente.getValueAt(fila, 0).toString());

        // Obtén el nuevo domicilio desde el formulario
        String nuevoDomicilio = txtDomicilio.getText();

        // Verifica si el nuevo domicilio ya existe
        String verificaDomicilio = "SELECT COUNT(*) FROM Comercial.DomicilioCliente WHERE idCliente = ? AND domicilioCliente = ?";
        stmt = bd.prepareStatement(verificaDomicilio);
        stmt.setInt(1, idCliente);
        stmt.setString(2, nuevoDomicilio);
        rs = stmt.executeQuery();

        if (rs.next() && rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(null, "El domicilio ya existe para este cliente.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Actualiza el domicilio
        String sql = "UPDATE Comercial.DomicilioCliente SET domicilioCliente = ? WHERE idDomicilio = ?";
        stmt = bd.prepareStatement(sql);
        stmt.setString(1, nuevoDomicilio);
        stmt.setInt(2, idDomicilio);
        stmt.executeUpdate();

        txtDomicilio.setText("");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar el domicilio del cliente: " + e.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

/*
    EliminaDato
    Elimina el registro seleccionado en la tabla Comercial.DomicilioCliente.
*/
private void EliminaDato(int idCliente) 
{
    Connection bd = null;
    PreparedStatement stmt = null;

    try {
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        int fila = TablaDomicilioCliente.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(null, "Seleccione un domicilio para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtén el ID del domicilio desde la tabla
        int idDomicilio = Integer.parseInt(TablaDomicilioCliente.getValueAt(fila, 0).toString());

        // Elimina el registro
        String sql = "DELETE FROM Comercial.DomicilioCliente WHERE idDomicilio = ?";
        stmt = bd.prepareStatement(sql);
        stmt.setInt(1, idDomicilio);
        stmt.executeUpdate();

        txtDomicilio.setText("");

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Existe al menos un servicio asociado a dicho domicilio.");
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaDomicilioCliente = new javax.swing.JTable();
        txtDomicilio = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("DomicilioCliente");

        TablaDomicilioCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TablaDomicilioCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaDomicilioClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaDomicilioCliente);

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Domicilio del Cliente:\n");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtDomicilio, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnInsertar)
                            .addGap(105, 105, 105)
                            .addComponent(btnModificar)
                            .addGap(107, 107, 107)
                            .addComponent(btnEliminar))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDomicilio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar)
                    .addComponent(btnInsertar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jLabel4.getAccessibleContext().setAccessibleName("Domicilio del Cliente:");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
    */
    private void TablaDomicilioClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaDomicilioClienteMouseClicked
        int fila = TablaDomicilioCliente.getSelectedRow();
        if (fila >= 0) {
            String domicilio = TablaDomicilioCliente.getValueAt(fila, 2).toString();
            txtDomicilio.setText(domicilio);
            
        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila.");
        }
    }//GEN-LAST:event_TablaDomicilioClienteMouseClicked

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idTrabajador, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaDomicilioCliente.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
        else{
            EliminaDato(idCliente);
            ConsultaDatos(idCliente);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato(idCliente);
        ConsultaDatos(idCliente);
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idCliente, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaDomicilioCliente.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
        else{
            ModificaDato(idCliente);
            ConsultaDatos(idCliente);
            
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    public static void main(String args[]) {
        int idCliente = 1;
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DomicilioCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DomicilioCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DomicilioCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DomicilioCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DomicilioCliente(idCliente).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaDomicilioCliente;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtDomicilio;
    // End of variables declaration//GEN-END:variables
}
