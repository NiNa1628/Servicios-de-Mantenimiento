//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  TrabajadorXServicio.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
   Clase para gestionar el manejo de los trabajadores de los servicios dentro de los Servicios de Mantenimiento
   Proporciona métodos para consultar, insertar, modificar y eliminar datos.
*/
public class TrabajadorXServicio extends javax.swing.JFrame 
{
    int idServicio;
    int idTrabajadorXServicio = -1;
    
    /* 
        Constructor del formulario TrabajadorXServicio.
        Inicializa el formulario y carga los datos de la tabla TrabajadorXServicio en el JTable.
    */
    public TrabajadorXServicio(int idServicio) 
    {
        initComponents();
        this.idServicio = idServicio;
        ConsultaDatos(idServicio);
        CargarTrabajadores();
        cmboxTrabajador.setSelectedIndex(-1);
    }
    
    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Operativo.TrabajadorXServicio en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos(int idServicio) 
    {
    String[] datos = new String[4];
    DefaultTableModel model = new DefaultTableModel(new String[]{"Id Trabajador del Servicio", "Servicio", "Trabajador", "Subtotal Trabajo"}, 0);
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Conexión a la base de datos.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Consulta SQL con JOINs.
        String sql = "SELECT txs.idTrabajadorXServicio, txs.idServicio, txs.idTrabajador, txs.subtotalTrabajo, "
                + "CONCAT(t.idServicio, ' - ', c.nombreCliente) AS ServicioCliente, "
                + "CONCAT(tr.nombreTrabajador, ' (', COUNT(dt.idTrabajador), ')') AS TrabajadorConProfesiones "
                + "FROM Operativo.TrabajadorXServicio txs "
                + "JOIN Operativo.Trabajador tr ON txs.idTrabajador = tr.idTrabajador "
                + "JOIN Operativo.Servicio t ON txs.idServicio = t.idServicio JOIN Comercial.DomicilioCliente d ON t.idDomicilio = d.idDomicilio "
                + "JOIN Comercial.Cliente c ON d.idCliente = c.idCliente "
                + "LEFT JOIN Operativo.DetalleTrabajador dt ON tr.idTrabajador = dt.idTrabajador "
                + "WHERE t.idServicio = ? "
                + "GROUP BY txs.idTrabajadorXServicio, txs.idServicio, txs.idTrabajador, txs.subtotalTrabajo, "
                + "t.idServicio, c.nombreCliente, tr.nombreTrabajador";

        stmt = bd.prepareStatement(sql);
        stmt.setInt(1, idServicio);
        rs = stmt.executeQuery();

        // Configuración del modelo de la tabla.
        TablaTrabajadorXServicio.setModel(model);

        // Agregar filas al modelo.
        while (rs.next()) {
            datos[0] = rs.getString("idTrabajadorXServicio");
            datos[1] = rs.getString("ServicioCliente");
            datos[2] = rs.getString("TrabajadorConProfesiones");
            datos[3] = rs.getString("subtotalTrabajo") != null ? rs.getString("subtotalTrabajo") : "0.00";
            model.addRow(datos);
        }
        
        TablaTrabajadorXServicio.getColumn("Id Trabajador del Servicio").setMinWidth(0);
        TablaTrabajadorXServicio.getColumn("Id Trabajador del Servicio").setMaxWidth(0);
        TablaTrabajadorXServicio.getColumn("Id Trabajador del Servicio").setWidth(0);

        // Cerrar conexiones.
        rs.close();
        stmt.close();
        bd.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al cargar el Trabajador del Servicio: " + ex.getMessage());
        }
    }
    
    /*
        Carge la información de la tabla Operativo.Trabajador y Operativo.DetalleTrabajador y la muestra en un combobox.
     */
    public void CargarTrabajadores() 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
            // Conexión a la base de datos de Postgres.
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
           "postgres");
            String sql = "SELECT t.NombreTrabajador, COUNT(dt.profesion) AS CantidadProfesiones "
                    + "FROM Operativo.Trabajador t "
                    + "LEFT JOIN Operativo.DetalleTrabajador dt ON t.idTrabajador = dt.idTrabajador "
                    + "GROUP BY t.NombreTrabajador";
            stmt = bd.prepareStatement(sql);
            rs = stmt.executeQuery();

            // Limpiar el JComboBox antes de agregar datos
            cmboxTrabajador.removeAllItems();

            // Leer cada domicilio y cliente del resultado de la consulta
            while (rs.next()) {
                String nombreTrabajador = rs.getString("nombreTrabajador");
                String cantidadProfesiones = rs.getString("cantidadProfesiones");
                String trabajador = nombreTrabajador + " (" + cantidadProfesiones + ")";

                // Agregar resultado al JComboBox
                cmboxTrabajador.addItem(trabajador);
            }
        rs.close();
        stmt.close();
        bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los trabajadores.");
            }
        }

    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Operativo.TrabajadorXServicio con los datos ingresados.
    */
    private void InsertaDato(int idServicio) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try 
    {
        // Obtener datos del formulario
        String trabajadorSeleccionado = cmboxTrabajador.getSelectedItem().toString();
        String[] partesTrabajador = trabajadorSeleccionado.split("\\(");
        String nombreTrabajador = partesTrabajador[0].trim();
        
        // Establecer conexión con la base de datos
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Obtener idTrabajador
        long idTrabajador = 0;
        String queryIdTrabajador = "SELECT idTrabajador FROM Operativo.Trabajador WHERE nombreTrabajador = ?";
        stmt = bd.prepareStatement(queryIdTrabajador);
        stmt.setString(1, nombreTrabajador);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idTrabajador = rs.getLong("idTrabajador");
        } else {
            JOptionPane.showMessageDialog(null, "El trabajador seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si ya existe un trabajador asignado a este servicio
        String queryCheckServicio = "SELECT COUNT(*) FROM Operativo.TrabajadorXServicio WHERE idServicio = ? AND idTrabajador = ?";
        stmt = bd.prepareStatement(queryCheckServicio);
        stmt.setInt(1, idServicio);
        stmt.setLong(2, idTrabajador);
        rs = stmt.executeQuery();

        if (rs.next() && rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(null, "El trabajador ya está asociado a este servicio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Insertar el trabajador al servicio
        String insertInfo = "INSERT INTO Operativo.TrabajadorXServicio(idServicio, idTrabajador) VALUES(?, ?)";
        stmt = bd.prepareStatement(insertInfo);
        stmt.setInt(1, idServicio);
        stmt.setLong(2, idTrabajador);
        stmt.executeUpdate();

        // Limpiar el ComboBox después de la inserción
        cmboxTrabajador.setSelectedIndex(-1);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar el trabajador en el servicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Operativo.TrabajadorXServicio con los datos actualizados.     
     */
    private void ModificaDato(int Servicio) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Obtener datos del formulario
        String trabajadorSeleccionado = cmboxTrabajador.getSelectedItem().toString();
        String[] partesTrabajador = trabajadorSeleccionado.split("\\(");
        String nombreTrabajador = partesTrabajador[0].trim();
        
        // Establecer conexión con la base de datos
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Obtener idTrabajador
        long idTrabajador = 0;
        String queryIdTrabajador = "SELECT idTrabajador FROM Operativo.Trabajador WHERE nombreTrabajador = ?";
        stmt = bd.prepareStatement(queryIdTrabajador);
        stmt.setString(1, nombreTrabajador);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idTrabajador = rs.getLong("idTrabajador");
        } else {
            JOptionPane.showMessageDialog(null, "El trabajador seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si ya existe un trabajador asignado a este servicio
        String queryCheckServicio = "SELECT COUNT(*) FROM Operativo.TrabajadorXServicio WHERE idServicio = ? AND idTrabajador = ?";
        stmt = bd.prepareStatement(queryCheckServicio);
        stmt.setInt(1, idServicio);
        stmt.setLong(2, idTrabajador);
        rs = stmt.executeQuery();

        if (rs.next() && rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(null, "El trabajador ya está asociado a este servicio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Actualizar el detalle de la compra
        String updateQuery = "UPDATE Operativo.TrabajadorXServicio SET idTrabajador = ? WHERE idTrabajadorXServicio = ?";
        stmt = bd.prepareStatement(updateQuery);
        stmt.setLong(1, idTrabajador);
        stmt.setInt(2, idTrabajadorXServicio);
        stmt.executeUpdate();

        // Limpiar el comboBox después de la inserción
        cmboxTrabajador.setSelectedIndex(-1);
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar el trabajador del servicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Operativo.Servicio con los datos actualizados.
    */
    private void EliminaDato(int idServicio)
    {
        Connection bd = null;
        PreparedStatement stmt = null;

        try
        {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
            String sql = "DELETE FROM Operativo.TrabajadorXServicio WHERE idTrabajadorXServicio = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idTrabajadorXServicio);
            
            stmt.executeUpdate();
            
            cmboxTrabajador.setSelectedIndex(-1);
            stmt.close();
            bd.close();
    }catch(SQLException ex){
       JOptionPane.showMessageDialog(null, "Error al eliminar el Servicio.");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cmboxTrabajador = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        btnInsertar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaTrabajadorXServicio = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Trabajador del Servicio");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Seleccione el trabajador:");

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        TablaTrabajadorXServicio.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TablaTrabajadorXServicio.setToolTipText("");
        TablaTrabajadorXServicio.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        TablaTrabajadorXServicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaTrabajadorXServicioMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaTrabajadorXServicio);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnInsertar)
                        .addGap(78, 78, 78)
                        .addComponent(btnModificar)
                        .addGap(83, 83, 83)
                        .addComponent(btnEliminar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel4)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(cmboxTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(7, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(17, 17, 17)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cmboxTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(219, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnInserta_Click
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos.
     */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato(idServicio);
        ConsultaDatos(idServicio);
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idCliente, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaTrabajadorXServicio.getSelectedRow();
        if (fila >= 0) {
            idTrabajadorXServicio = Integer.parseInt(TablaTrabajadorXServicio.getValueAt(fila, 0).toString());
            EliminaDato(idServicio);
            ConsultaDatos(idServicio);

        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idCliente, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaTrabajadorXServicio.getSelectedRow();
        if (fila >= 0) {
            idTrabajadorXServicio = Integer.parseInt(TablaTrabajadorXServicio.getValueAt(fila, 0).toString());
            ModificaDato(idServicio);
            ConsultaDatos(idServicio);

        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        TablaTrabajadorXServicioMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
    */
    private void TablaTrabajadorXServicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaTrabajadorXServicioMouseClicked
        int fila = TablaTrabajadorXServicio.getSelectedRow();
        if(fila >= 0) {
            String trabajador = TablaTrabajadorXServicio.getValueAt(fila, 2).toString();
            cmboxTrabajador.setSelectedItem(trabajador);
        }
        else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_TablaTrabajadorXServicioMouseClicked


    public static void main(String args[]) {
        int idServicio = 1;
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TrabajadorXServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TrabajadorXServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TrabajadorXServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TrabajadorXServicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TrabajadorXServicio(idServicio).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaTrabajadorXServicio;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JComboBox<String> cmboxTrabajador;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
