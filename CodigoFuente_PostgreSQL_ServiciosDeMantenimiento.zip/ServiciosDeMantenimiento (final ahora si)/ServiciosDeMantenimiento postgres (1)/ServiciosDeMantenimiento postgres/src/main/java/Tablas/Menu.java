//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

import javax.swing.JButton;
import javax.swing.JOptionPane;

/*
    Clase principal del proyecto de Servicios de Mantenimiento.
    Este formulario actúa como el menú principal de la aplicación, proporcionando acceso a otros formularios específicos.
    Los siguiente formularios son:
        - Formulario de Material.
        - Formulario de Cliente.
        - Formulario de Proveedor.
        - Formulario de Trabajador.
        - Formulario de Compra.
        - Formulario de Servicio.
 */
public class Menu extends javax.swing.JFrame
{
    private String usuario;
    private String rol;
    
    /*
        Constructor del formulario principal.
        Inicializa los componentes del formulario.
     */ 
    public Menu(String usuario, String rol) 
    {
        this.usuario = usuario;
        this.rol = rol;
        initComponents();
        configurarPermisos();
    }

    /*
        Habilita y deshabilita los botones para el menú de cada tipo de usuario.
    */
    public void configurarPermisos()
    {
        switch (rol) {
            case "Admin":
                // Si es Admin, habilitar todo
                btnConsulta1.setVisible(true);
                btnConsulta2.setVisible(true);
                btnMaterial.setEnabled(true);
                btnCliente.setEnabled(true);
                btnProveedor.setEnabled(true);
                btnTrabajador.setEnabled(true);
                btnCompra.setEnabled(true);
                btnServicio.setEnabled(true);
                break;
            case "Gerente":
                // Si es Gerente, habilitar solo algunas opciones
                btnConsulta1.setVisible(false);
                btnConsulta2.setVisible(false);
                btnMaterial.setEnabled(true);
                btnCliente.setEnabled(true);
                btnProveedor.setEnabled(true);
                btnTrabajador.setEnabled(true);
                btnCompra.setEnabled(true);
                btnServicio.setEnabled(true);
                break;
            case "Empleado":
                // Si es Empleado, habilitar solo algunas opciones
                btnConsulta1.setVisible(false);
                btnConsulta2.setVisible(false);
                btnMaterial.setEnabled(true);
                btnCliente.setEnabled(true);
                btnProveedor.setEnabled(true);
                btnTrabajador.setEnabled(true);
                btnCompra.setEnabled(true);
                btnServicio.setEnabled(true);
                break;
            default:
                break;
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnProveedor = new javax.swing.JButton();
        btnCompra = new javax.swing.JButton();
        btnServicio = new javax.swing.JButton();
        btnMaterial = new javax.swing.JButton();
        btnTrabajador = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnCliente = new javax.swing.JButton();
        btnConsulta1 = new javax.swing.JButton();
        btnConsulta2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        btnProveedor.setText("Proveedor");
        btnProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProveedorActionPerformed(evt);
            }
        });

        btnCompra.setText("Compra");
        btnCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompraActionPerformed(evt);
            }
        });

        btnServicio.setText("Servicio");
        btnServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnServicioActionPerformed(evt);
            }
        });

        btnMaterial.setText("Material");
        btnMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMaterialActionPerformed(evt);
            }
        });

        btnTrabajador.setText("Trabajador");
        btnTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTrabajadorActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Servicios de Mantenimiento");

        btnCliente.setText("Cliente");
        btnCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClienteActionPerformed(evt);
            }
        });

        btnConsulta1.setText("Consulta 1");
        btnConsulta1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsulta1ActionPerformed(evt);
            }
        });

        btnConsulta2.setText("Consulta 2");
        btnConsulta2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsulta2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnProveedor)
                                    .addComponent(btnCliente))
                                .addGap(42, 42, 42)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnServicio)
                                    .addComponent(btnCompra))
                                .addGap(35, 35, 35)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnMaterial)
                                    .addComponent(btnTrabajador))
                                .addGap(14, 14, 14))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(btnConsulta1)
                        .addGap(18, 18, 18)
                        .addComponent(btnConsulta2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnMaterial)
                        .addGap(18, 18, 18)
                        .addComponent(btnTrabajador))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnCompra)
                                .addComponent(btnCliente))
                            .addGap(18, 18, 18)
                            .addComponent(btnServicio))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(41, 41, 41)
                            .addComponent(btnProveedor))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConsulta1)
                    .addComponent(btnConsulta2))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnMaterialActionPerformed
        Evento que se dispara al hacer clic en el botón de Material.
        Abre el formulario de Material como un cuadro de diálogo, permitiendo gestionar los datos de materiales.
    */
    private void btnMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaterialActionPerformed
        Material materialForm = new Material(usuario, rol);
        materialForm.setVisible(true);
    }//GEN-LAST:event_btnMaterialActionPerformed

    /*
        btnClienteActionPerformed
        Evento que se dispara al hacer clic en el botón de Cliente.
        Abre el formulario de Cliente como un cuadro de diálogo, permitiendo gestionar los datos de los clientes.
    */
    private void btnClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClienteActionPerformed
        Cliente clienteForm = new Cliente(usuario, rol);
        clienteForm.setVisible(true);
    }//GEN-LAST:event_btnClienteActionPerformed

    /*
        btnProveedorActionPerformed
       Evento que se dispara al hacer clic en el botón de Proveedor.
       Abre el formulario de Proveedor como un cuadro de diálogo, permitiendo gestionar los datos de los proveedores.
    */
    private void btnProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProveedorActionPerformed
        Proveedor proveedorForm = new Proveedor(usuario, rol);
        proveedorForm.setVisible(true);
    }//GEN-LAST:event_btnProveedorActionPerformed
 
    /*
        btnTrabajadorActionPerformed
        Evento que se dispara al hacer clic en el botón de Trabajador.
        Abre el formulario de Trabajador como un cuadro de diálogo, permitiendo gestionar los datos de los trabajadores.
    */
    private void btnTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTrabajadorActionPerformed
        Trabajador trabajadorForm = new Trabajador(usuario, rol);
        trabajadorForm.setVisible(true);
    }//GEN-LAST:event_btnTrabajadorActionPerformed

    /*
        btnCompraActionPerformed
        Evento que se dispara al hacer clic en el botón de Compra.
        Abre el formulario de Compra como un cuadro de diálogo, permitiendo gestionar los datos de las compras.
     */
    private void btnCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompraActionPerformed
        Compra compraForm = new Compra(usuario, rol);
        compraForm.setVisible(true); 
    }//GEN-LAST:event_btnCompraActionPerformed

    /*
        btnServicioActionPerformed
        Evento que se dispara al hacer clic en el botón de Servicio.
        Abre el formulario de Servicio como un cuadro de diálogo, permitiendo gestionar los datos de los servicios.
     */
    private void btnServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnServicioActionPerformed
        Servicio servicioForm = new Servicio(usuario, rol);
        servicioForm.setVisible(true);
    }//GEN-LAST:event_btnServicioActionPerformed

    /*
        btnConsulta2ActionPerformed
        Evento que se dispara al hacer clic en el botón de Consulta 1.
        Abre el formulario de Consulta 1 como un cuadro de diálogo, permitiendo gestionar las consulta 1: Uso de GROUP BY, COUNT e INNER JOIN.
     */
    private void btnConsulta1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsulta1ActionPerformed
        Consulta1 consulta1Form = new Consulta1();
        consulta1Form.setVisible(true);
    }//GEN-LAST:event_btnConsulta1ActionPerformed

    /*
        btnConsulta2ActionPerformed
        Evento que se dispara al hacer clic en el botón de Consulta 2.
        Abre el formulario de Consulta 2 como un cuadro de diálogo, permitiendo gestionar los consulta 2: Realizar subconsultas.
     */
    private void btnConsulta2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsulta2ActionPerformed
        Consulta2 consulta2Form = new Consulta2();
        consulta2Form.setVisible(true);
    }//GEN-LAST:event_btnConsulta2ActionPerformed

    public static void main(String args[]) {
        String usuario = "";
        String rol = "";
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu(usuario, rol).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCliente;
    private javax.swing.JButton btnCompra;
    private javax.swing.JButton btnConsulta1;
    private javax.swing.JButton btnConsulta2;
    private javax.swing.JButton btnMaterial;
    private javax.swing.JButton btnProveedor;
    private javax.swing.JButton btnServicio;
    private javax.swing.JButton btnTrabajador;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
