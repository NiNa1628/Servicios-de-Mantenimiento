// Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  Servicio.
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/*
    Constructor de la clase con las que se declaran 
    las variables de la tabla y se les generan los getters y setter
    para poder ser usados mas adelante 
*/

public class OMaterial 
{
    int codigo;
    String nomMaterial;
    String tipoMaterial;
    float precioMaterial;
    int existencias;
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNomMaterial() {
        return nomMaterial;
    }

    public void setNomMaterial(String nomMaterial) {
        this.nomMaterial = nomMaterial;
    }

    public String getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(String tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    public float getPrecioMaterial() {
        return precioMaterial;
    }

    public void setPrecioMaterial(float precioMaterial) {
        this.precioMaterial = precioMaterial;
    }

    public int getExistencias() {
        return existencias;
    }
    

    public void setExistencias(int existencias) {
        this.existencias = existencias;
    }
   
    /* Metodo con el cual se realiza la consulta SELECT de la tabla 
    Operativo.Material para poder se rvisualizados los datos almacenados 
    en la JTable del formulario*/
    public void mostrarMaterial(JTable tablaMaterial)
    {
        ConexionBD objetoConexion = new ConexionBD();
        
        DefaultTableModel modelo = new DefaultTableModel(); 
        
        String sql = "";
        modelo.addColumn("idMaterial");
        modelo.addColumn("Nombre del Material");
        modelo.addColumn("Tipo del Material");
        modelo.addColumn("Precio del Material");
        modelo.addColumn("Existencia");
        
        tablaMaterial.setModel(modelo);
        
        sql = "SELECT *FROM Operativo.Material";
        
        String [] datos = new String[5];
        Statement st;
        
        try{
            st= objetoConexion.establecerConexion().createStatement();
            
            ResultSet rs= st.executeQuery(sql);
            
            while(rs.next()){
                datos[0]= rs.getString(1);
                datos[1]= rs.getString(2);
                datos[2]= rs.getString(3);
                datos[3]= rs.getString(4);
                datos[4]= rs.getString(5);
                
                modelo.addRow(datos);
            }
            tablaMaterial.setModel(modelo);
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"ERROR:" +e.toString());
            
        }
        
    }
    
    /*Metodo insertar donde se realiza la insercion de datos a la tabla 
    Operativo.Material y al final se actualiza la tabla para verse reflejados 
    los comabios*/
    public void insertarMaterial(JTextField nMaterial, JComboBox<String> tMaterial, JTextField pMaterial, JTextField exist) 
    {
        setNomMaterial(nMaterial.getText());
        setTipoMaterial(tMaterial.getSelectedItem().toString()); // Obtener valor del JComboBox
        setPrecioMaterial(Float.parseFloat(pMaterial.getText()));
        setExistencias(Integer.parseInt(exist.getText()));

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "INSERT INTO Operativo.Material(nombreMaterial, tipoMaterial, precioMaterial, existencia) VALUES (?, ?, ?, ?);";

        try {
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            cs.setString(1, getNomMaterial());
            cs.setString(2, getTipoMaterial());
            cs.setFloat(3, getPrecioMaterial());
            cs.setInt(4, getExistencias());

            cs.execute();

            //JOptionPane.showMessageDialog(null, "Se insertó correctamente");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: El nombre del material ya existe");
        }
    }
    
    /*Metodo con el cual seleccionamos una tupla compla de la tabla Operativo.Material
    y al seleccionarlo se ven reflejados los datos seleccinados en los JTextLabel 
    del formulario, esto sirve para saber cual es la tupla que va a ser modificada y/o eliminada */
    public int SeleccionarMaterial(JTable tablaMaterial, JTextField nMaterial, JComboBox<String> tMaterial, JTextField pMaterial, JTextField exist) 
    {
        int idMaterial = -1; // Valor inicial por defecto si no se selecciona una fila

        try {
            int fila = tablaMaterial.getSelectedRow(); // Obtén la fila seleccionada

            if (fila >= 0) {
                // Rellena los campos con los valores de la fila seleccionada
                nMaterial.setText(tablaMaterial.getValueAt(fila, 1).toString());

                // Establece el valor en el JComboBox
                String tipoMaterial = tablaMaterial.getValueAt(fila, 2).toString();
                tMaterial.setSelectedItem(tipoMaterial); // Selecciona el valor correspondiente

                pMaterial.setText(tablaMaterial.getValueAt(fila, 3).toString());
                exist.setText(tablaMaterial.getValueAt(fila, 4).toString());

                // Obtén el idMaterial de la columna 0
                TableModel modelo = tablaMaterial.getModel();
                Object valor = modelo.getValueAt(fila, 0);

                if (valor instanceof Integer) {
                    idMaterial = (int) valor; // Si ya es entero
                } else {
                    idMaterial = Integer.parseInt(valor.toString()); // Si es texto, conviértelo a entero
                }
            } else {
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: " + e.toString());
        }

        return idMaterial; // Devuelve el ID obtenido
    }
    
    /*Metodo de modificación de datos donde se realiza la consulta sql UPDATE para
    poder modificar los datos de la tupla seleccionada en caso de ser necesario*/
    public void ModificarMaterial(JTextField nMaterial, JComboBox<String> tMaterial, JTextField pMaterial, JTextField exist, int idMaterial) 
    {
        if (idMaterial == -1) {
            JOptionPane.showMessageDialog(null, "Error: No se pudo determinar el ID del material.");
            return;
        }

        setNomMaterial(nMaterial.getText());
        setTipoMaterial(tMaterial.getSelectedItem().toString()); // Obtener el valor seleccionado del JComboBox
        setPrecioMaterial(Float.parseFloat(pMaterial.getText()));
        setExistencias(Integer.parseInt(exist.getText()));

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "UPDATE Operativo.Material " +
                          "SET nombreMaterial = ?, tipoMaterial = ?, precioMaterial = ?, existencia = ? " +
                          "WHERE idMaterial = ?;";

        try {
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            cs.setString(1, getNomMaterial());
            cs.setString(2, getTipoMaterial());
            cs.setFloat(3, getPrecioMaterial());
            cs.setInt(4, getExistencias());
            cs.setInt(5, idMaterial);

            cs.execute();

            //JOptionPane.showMessageDialog(null, "Se modificó correctamente");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: El nombre del material ya existe" );
        }
    } 
    
    /*Metodo de eliminacion de datos en el cual utilizamos la consulta sql DELETE 
    para borrar las tuplas que ya no son necesarias dentro de nuestra tabla */
    public void EliminarMaterial(int idMaterial) 
    {
        if (idMaterial == -1) {
            JOptionPane.showMessageDialog(null, "Error: No se pudo determinar el ID del material.");
            return;
        }
        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "DELETE FROM Operativo.Material WHERE idMaterial = ?;";

        try {
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            cs.setInt(1, idMaterial);

            cs.execute();

            //JOptionPane.showMessageDialog(null, "Se eliminó correctamente");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: " + e.toString());
        }
    }    
}