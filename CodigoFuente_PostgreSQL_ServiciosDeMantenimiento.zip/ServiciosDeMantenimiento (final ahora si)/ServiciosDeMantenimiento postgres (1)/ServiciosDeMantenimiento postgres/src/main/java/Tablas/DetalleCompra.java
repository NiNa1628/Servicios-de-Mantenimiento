//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario DetalleCompra
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
   Clase para gestionar el manejo de los detalles de las compras dentro de los Servicios de Mantenimiento
   Proporciona métodos para consultar, insertar, modificar y eliminar datos.
*/
public class DetalleCompra extends javax.swing.JFrame 
{
    int idCompra;
    
    /* 
        Constructor del formulario DetalleCompra.
        Inicializa el formulario y carga los datos de la tabla DetalleCompra en el DataGridView.
    */
    public DetalleCompra(int idCompra) 
    {
        initComponents();
        this.idCompra = idCompra;
        ConsultaDatos(idCompra);
        cargarMateriales();
        cmboxMaterial.setSelectedIndex(-1);
    }
    
    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Comercial.Cliente en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos(int idCompra) 
    {
    String[] datos = new String[4];
    DefaultTableModel model = new DefaultTableModel(new String[]{"Id Compra", "Material", "Cantidad", "Subtotal"}, 0);
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Conexión a la base de datos.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Consulta SQL con JOINs.
        String sql = "SELECT " +
             "CONCAT(d.idCompra, ' - ', p.nombreProveedor) AS idCompra, " +
             "CONCAT(m.NombreMaterial, ' - ', m.TipoMaterial) AS Material, " +
             "d.cantidad, CAST(d.subtotal AS numeric(10, 2)) AS subtotal " +
             "FROM Comercial.DetalleCompra d " +
             "JOIN Comercial.Compra c ON d.idCompra = c.idCompra " +
             "JOIN Comercial.Proveedor p ON c.idProveedor = p.idProveedor " +
             "JOIN Operativo.Material m ON d.idMaterial = m.idMaterial " +
             "WHERE d.idCompra = ?";

        stmt = bd.prepareStatement(sql);
        stmt.setInt(1, idCompra); // Establecer parámetro.
        rs = stmt.executeQuery();

        // Configuración del modelo de la tabla.
        TablaDetalleCompra.setModel(model);

        // Agregar filas al modelo.
        while (rs.next()) {
            datos[0] = rs.getString("idCompra");
            datos[1] = rs.getString("Material");
            datos[2] = String.valueOf(rs.getInt("cantidad"));
            datos[3] = String.format("%.2f", rs.getFloat("subtotal"));
            model.addRow(datos);
        }

        // Cerrar conexiones.
        rs.close();
        stmt.close();
        bd.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al cargar el Detalle de la Compra: " + ex.getMessage());
        }
    }

    /*
        Carge la información de la tabla Operativo.Material y la muestra en un combobox.
     */
    public void cargarMateriales() 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
            // Conexión a la base de datos de Postgres.
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
           "postgres");
            String sql = "SELECT nombreMaterial, tipoMaterial FROM Operativo.Material";
            stmt = bd.prepareStatement(sql);
            rs = stmt.executeQuery();

            // Limpiar el JComboBox antes de agregar datos
            cmboxMaterial.removeAllItems();

            // Leer cada domicilio y cliente del resultado de la consulta
            while (rs.next()) {
                String nombreMaterial = rs.getString("nombreMaterial");
                String tipoMaterial = rs.getString("tipoMaterial");
                String material = nombreMaterial + " - " + tipoMaterial;

                // Agregar resultado al JComboBox
                cmboxMaterial.addItem(material);
            }
        rs.close();
        stmt.close();
        bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los materiales.");
        }
    }

    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Comercial.DetalleCompra con los datos ingresados.
    */
    private void InsertaDato(int idCompra) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Establecer conexión con la base de datos
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Obtener datos del formulario
        String materialSeleccionado = cmboxMaterial.getSelectedItem().toString();
        String[] partesMaterial = materialSeleccionado.split("\\-");
        String nombreMaterial = partesMaterial[0].trim();
        String tipoMaterial = partesMaterial[1].trim();
        String cant = txtCantidad.getText();
        int cantidad = Integer.parseInt(cant);
        
        // Obtener idMaterial
        long idMaterial = 0;
        String queryIdMaterial = "SELECT idMaterial FROM Operativo.Material WHERE NombreMaterial = ? AND TipoMaterial = ?";
        stmt = bd.prepareStatement(queryIdMaterial);
        stmt.setString(1, nombreMaterial);
        stmt.setString(2, tipoMaterial);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idMaterial = rs.getLong("idMaterial");
        } else {
            JOptionPane.showMessageDialog(null, "El material seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insertar el detalle de la compra
        String insertInfo = "INSERT INTO Comercial.DetalleCompra(idCompra, idMaterial, cantidad) VALUES(?, ?, ?)";
        stmt = bd.prepareStatement(insertInfo);
        stmt.setInt(1, idCompra);
        stmt.setLong(2, idMaterial);
        stmt.setInt(3, cantidad);
        stmt.executeUpdate();

        // Limpiar el comboBox después de la inserción
        cmboxMaterial.setSelectedIndex(-1);
        txtCantidad.setText("");


    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar el detalle de la compra: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Comercial.Compra con los datos actualizados.     
     */
    private void ModificaDato(int idCompra) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Establecer conexión con la base de datos
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Obtener datos del formulario
        String materialSeleccionado = cmboxMaterial.getSelectedItem().toString();
        String[] partesMaterial = materialSeleccionado.split("\\-");
        String nombreMaterial = partesMaterial[0].trim();
        String tipoMaterial = partesMaterial[1].trim();
        String cant = txtCantidad.getText();
        int cantidad = Integer.parseInt(cant);

        // Obtener idMaterial
        long idMaterial = 0;
        String queryIdMaterial = "SELECT idMaterial FROM Operativo.Material WHERE NombreMaterial = ? AND TipoMaterial = ?";
        stmt = bd.prepareStatement(queryIdMaterial);
        stmt.setString(1, nombreMaterial);
        stmt.setString(2, tipoMaterial);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idMaterial = rs.getLong("idMaterial");
        } else {
            JOptionPane.showMessageDialog(null, "El material seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Actualizar el detalle de la compra
        String updateQuery = "UPDATE Comercial.DetalleCompra SET cantidad = ? WHERE idCompra = ? AND idMaterial = ?";
        stmt = bd.prepareStatement(updateQuery);
        stmt.setInt(1, cantidad);  // Asignar la cantidad
        stmt.setInt(2, idCompra);  // Asignar idCompra
        stmt.setLong(3, idMaterial);  // Asignar idMaterial
        stmt.executeUpdate();

        // Limpiar el comboBox después de la inserción
        cmboxMaterial.setSelectedIndex(-1);
        txtCantidad.setText("");
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al modificar el detalle de la compra: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Comercial.DetalleCompra con los datos actualizados.
    */
    private void EliminaDato(int idCompra) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Establecer conexión con la base de datos
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Obtener datos del formulario
        String materialSeleccionado = cmboxMaterial.getSelectedItem().toString();
        String[] partesMaterial = materialSeleccionado.split("\\-");
        String nombreMaterial = partesMaterial[0].trim();
        String tipoMaterial = partesMaterial[1].trim();

        // Obtener idMaterial
        long idMaterial = 0;
        String queryIdMaterial = "SELECT idMaterial FROM Operativo.Material WHERE NombreMaterial = ? AND TipoMaterial = ?";
        stmt = bd.prepareStatement(queryIdMaterial);
        stmt.setString(1, nombreMaterial);
        stmt.setString(2, tipoMaterial);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idMaterial = rs.getLong("idMaterial");
        } else {
            JOptionPane.showMessageDialog(null, "El material seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Sentencia SQL para eliminar el detalle de la compra
        String sql = "DELETE FROM Comercial.DetalleCompra WHERE idCompra = ? AND idMaterial = ?";
        stmt = bd.prepareStatement(sql);
        stmt.setInt(1, idCompra);   // Aquí pasa el idCompra (debe ser un entero)
        stmt.setLong(2, idMaterial); // Aquí pasa el idMaterial obtenido de la consulta

        // Ejecutar la eliminación
        int rowsAffected = stmt.executeUpdate();

        // Limpiar el ComboBox después de la eliminación
        cmboxMaterial.setSelectedIndex(-1);

    } catch (SQLException ex) {
        // Mostrar mensaje de error si algo sale mal
        JOptionPane.showMessageDialog(null, "Error al eliminar el detalle de la compra: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Cerrar recursos en el bloque finally
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar los recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnInsertar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaDetalleCompra = new javax.swing.JTable();
        cmboxMaterial = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("DetalleCompra");

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        TablaDetalleCompra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TablaDetalleCompra.setToolTipText("");
        TablaDetalleCompra.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        TablaDetalleCompra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaDetalleCompraMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaDetalleCompra);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Seleccione el material:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Cantidad:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnInsertar)
                            .addGap(78, 78, 78)
                            .addComponent(btnModificar)
                            .addGap(83, 83, 83)
                            .addComponent(btnEliminar))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmboxMaterial, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmboxMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato(idCompra);
        ConsultaDatos(idCompra);
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idCliente, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaDetalleCompra.getSelectedRow();
        if(fila >= 0){
            String valorFila = TablaDetalleCompra.getValueAt(fila, 0).toString();
            try {
                String[] partes = valorFila.split(" - ");
                idCompra = Integer.parseInt(partes[0].trim());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al procesar el id de la compra.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            EliminaDato(idCompra);
            ConsultaDatos(idCompra);
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idCliente, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaDetalleCompra.getSelectedRow();
        if (fila >= 0) {
            String valorFila = TablaDetalleCompra.getValueAt(fila, 0).toString();
            try {
                String[] partes = valorFila.split(" - ");
                idCompra = Integer.parseInt(partes[0].trim());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al procesar el id de la compra.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        ModificaDato(idCompra);
        ConsultaDatos(idCompra);

    } else {
        JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
        Llama al método SeleccionaDato para cargar los datos del cliente en los campos de texto.
    */
    private void TablaDetalleCompraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaDetalleCompraMouseClicked
        int fila = TablaDetalleCompra.getSelectedRow();
        if(fila >= 0) {
            String cantidad = TablaDetalleCompra.getValueAt(fila, 2).toString();
            txtCantidad.setText(cantidad);
            
            String material = TablaDetalleCompra.getValueAt(fila, 1).toString();
            cmboxMaterial.setSelectedItem(material);
        }
        else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_TablaDetalleCompraMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DetalleCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DetalleCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DetalleCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DetalleCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        int idCompra = 1;
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DetalleCompra(idCompra).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaDetalleCompra;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JComboBox<String> cmboxMaterial;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCantidad;
    // End of variables declaration//GEN-END:variables
}
