// Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  Servicio.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
    Clase para gestionar el manejo de los detalles de los trabajadores dentro de los Servicios de Mantenimiento
    Proporciona métodos para consultar, insertar, modificar y eliminar datos.
 */
public class DetalleTrabajador extends javax.swing.JFrame 
{
    int idTrabajador = -1;
    
    /* 
        Constructor del formulario DetalleTrabajador.
        Inicializa el formulario y carga los datos de la tabla DetalleTrabajador en el JTable.
    */
    public DetalleTrabajador(int idTrabajador) 
    {
        initComponents();
        this.idTrabajador = idTrabajador;
        ConsultaDatos(idTrabajador);
    }
    
    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Operativo.DetalleTrabajador en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos(int idTrabajador) 
    {
    String[] datos = new String[3];
    DefaultTableModel model = new DefaultTableModel(new String[]{"Trabajador", "Profesión", "Costo Base"}, 0);
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
        
        // Consulta con JOIN para obtener el nombre del trabajador
        String sql = "SELECT dt.idTrabajador, dt.profesion, dt.costoBase, t.nombreTrabajador "
                + "FROM Operativo.DetalleTrabajador dt "
                + "JOIN Operativo.Trabajador t ON dt.idTrabajador = t.idTrabajador "
                + "WHERE dt.idTrabajador = ?";
        stmt = bd.prepareStatement(sql);
        stmt.setInt(1, idTrabajador);
        rs = stmt.executeQuery();

        TablaDetalleTrabajador.setModel(model);

        while (rs.next()) 
        {
            String nombreTrabajador = rs.getString("nombreTrabajador");
            String trabajador = nombreTrabajador;
            datos[0] = trabajador;
            datos[1] = rs.getString("profesion");
            datos[2] = rs.getString("costoBase") != null ? rs.getString("costoBase") : "0.00";
            model.addRow(datos);
        }
        // Cerrar conexiones.
            rs.close();
            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar el Material del Servicio: " + ex.getMessage());
            }
        }
    
    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Operativo.DetalleTrabajador con los datos ingresados.
        Si ocurre un error(como duplicación de la profesión), muestra un mensaje de error.
    */
     private void InsertaDato(int idTrabajador) 
     {
        Connection bd = null;
        PreparedStatement stmt = null; 
        ResultSet rs = null; 
        
        try {
            // Establecer conexión con la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            
            // Obtener datos del formulario
            String profesion = txtProfesion.getText();
            String costoB = txtCostoBase.getText();
            float costoBase = Float.parseFloat(costoB);

            //Verifica si profesión ya existe.
            String verificaProfesion = "SELECT COUNT(*) FROM Operativo.DetalleTrabajador WHERE idTrabajador = ? AND profesion = ?";
            stmt = bd.prepareStatement(verificaProfesion);
            stmt.setInt(1, idTrabajador);
            stmt.setString(2, profesion);
            rs = stmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(null, "Este trabajador ya tiene asignada esta profesión.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String sql = "INSERT INTO Operativo.DetalleTrabajador (idTrabajador, profesion, costoBase) VALUES (?, ?, ?)";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idTrabajador); // Usa el idTrabajador almacenado en la clase
            stmt.setString(2, profesion);
            stmt.setFloat(3, costoBase);

            stmt.executeUpdate();

            // Limpia los campos después de insertar
            txtProfesion.setText("");
            txtCostoBase.setText("");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al insertar el detalle del trabajador: " + ex.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (bd != null) bd.close();
            } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
     
     /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Operativo.DetalleTrabajador con los datos actualizados.
        Si ocurre un error(como duplicación de la profesión), muestra un mensaje de error.
     */
     private void ModificaDato(int idTrabajador) 
     {
         Connection bd = null;
         PreparedStatement stmt = null;
         ResultSet rs = null;
         String profesionActual ="";
         
         try {
             bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

             int fila = TablaDetalleTrabajador.getSelectedRow();
             if(fila >= 0) {
                profesionActual = TablaDetalleTrabajador.getValueAt(fila, 1).toString();
            }
             
            // Obtener datos del formulario
            String profesion = txtProfesion.getText();
            String costoB = txtCostoBase.getText();
            float costoBase = Float.parseFloat(costoB);

            //Verifica si profesión ya existe.
            String verificaProfesion = "SELECT COUNT(*) FROM Operativo.DetalleTrabajador WHERE idTrabajador = ? AND profesion = ?";
            stmt = bd.prepareStatement(verificaProfesion);
            stmt.setInt(1, idTrabajador);
            stmt.setString(2, profesion);
            rs = stmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(null, "Este trabajador ya tiene asignada esta profesión.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
             
             String sql = "UPDATE Operativo.DetalleTrabajador SET profesion = ?, costoBase = ? WHERE idTrabajador = ? AND profesion = ?";
             stmt = bd.prepareStatement(sql);
             stmt.setString(1, profesion);
             stmt.setFloat(2, costoBase);
             stmt.setInt(3, idTrabajador);
             stmt.setString(4, profesionActual);
             stmt.executeUpdate();

             txtProfesion.setText("");
             txtCostoBase.setText("");

         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al modificar el detalle del trabajador: " + e.getMessage());
         } finally {
             try {
                 if (stmt != null) stmt.close();
                 if (bd != null) bd.close();
             } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                 }
            }
        }  
    
     /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Operativo.DetalleTrabajador con los datos actualizados.
     */
    private void EliminaDato(int idTrabajador) 
    {
       Connection bd = null;
       PreparedStatement stmt = null;

       try {
           bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            String profesion = txtProfesion.getText();
           
           String sql = "DELETE FROM Operativo.DetalleTrabajador WHERE idTrabajador = ? AND profesion = ?";
           stmt = bd.prepareStatement(sql);
           stmt.setInt(1, idTrabajador);
           stmt.setString(2, profesion);
           stmt.executeUpdate();

           txtProfesion.setText("");
           txtCostoBase.setText("");
       } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Error al eliminar el trabajador: " + ex.getMessage());
       } finally {
           try {
               if (stmt != null) stmt.close();
               if (bd != null) bd.close();
           } catch (SQLException ex) {
       JOptionPane.showMessageDialog(null, "Error al eliminar el Servicio.");
           }
       }
    } 
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtProfesion = new javax.swing.JTextField();
        txtCostoBase = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaDetalleTrabajador = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("DetalleTrabajador");

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Profesión del Trabajador:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Costo Base del Trabajador:");

        txtProfesion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtCostoBase.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        TablaDetalleTrabajador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TablaDetalleTrabajador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaDetalleTrabajadorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaDetalleTrabajador);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnInsertar)
                            .addGap(64, 64, 64)
                            .addComponent(btnModificar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnEliminar)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtProfesion, javax.swing.GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE)
                            .addComponent(txtCostoBase))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtProfesion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCostoBase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato(idTrabajador);
        ConsultaDatos(idTrabajador);
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idTrabajador, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaDetalleTrabajador.getSelectedRow();
        if(fila >= 0){
            idTrabajador = Integer.parseInt(TablaDetalleTrabajador.getValueAt(fila, 0).toString());
            ModificaDato(idTrabajador);
            ConsultaDatos(idTrabajador);
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idTrabajador, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaDetalleTrabajador.getSelectedRow();
        if(fila >= 0){
            idTrabajador = Integer.parseInt(TablaDetalleTrabajador.getValueAt(fila, 0).toString());
            EliminaDato(idTrabajador);
            ConsultaDatos(idTrabajador);
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
    */
    private void TablaDetalleTrabajadorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaDetalleTrabajadorMouseClicked
        int fila = TablaDetalleTrabajador.getSelectedRow();
        if (fila >= 0) {
            String profesion = TablaDetalleTrabajador.getValueAt(fila, 1).toString();
            txtProfesion.setText(profesion);
            
            String costoBase = TablaDetalleTrabajador.getValueAt(fila, 2).toString();
            txtCostoBase.setText(costoBase);
        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila.");
        }
    }//GEN-LAST:event_TablaDetalleTrabajadorMouseClicked

    public static void main(String args[]) {
        int idTrabajador = 1;
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DetalleTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DetalleTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DetalleTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DetalleTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DetalleTrabajador(idTrabajador).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaDetalleTrabajador;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCostoBase;
    private javax.swing.JTextField txtProfesion;
    // End of variables declaration//GEN-END:variables
}
