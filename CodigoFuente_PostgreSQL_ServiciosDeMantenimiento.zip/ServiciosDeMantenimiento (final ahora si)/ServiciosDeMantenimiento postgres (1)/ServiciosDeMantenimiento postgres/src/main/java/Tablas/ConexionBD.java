//Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  Servicio.
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/*Esta clase se utiliza solo para la coneccionn con la base de datos aqui 
definimos las variables y le concatenamos estas variables a la cadena para completar la conexión*/
public class ConexionBD 
{
    Connection conexion = null;
    
    String usuario = "postgres";
    String contraseña = "postgres";
    String bd = "ServiciosDeMantenimiento";
    String ip = "localhost";
    String puerto = "5432";
    
    String cadena = "jdbc:postgresql://"+ip+":"+puerto+"/"+bd;
    
    public Connection establecerConexion()
    {
        
        try{
            Class.forName("org.postgresql.Driver");
            conexion = DriverManager.getConnection(cadena,usuario,contraseña);
            //JOptionPane.showMessageDialog(null, "Se conectó correctamente");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "ERROR:"+e.toString());
            
        }
        return conexion;
    }
}