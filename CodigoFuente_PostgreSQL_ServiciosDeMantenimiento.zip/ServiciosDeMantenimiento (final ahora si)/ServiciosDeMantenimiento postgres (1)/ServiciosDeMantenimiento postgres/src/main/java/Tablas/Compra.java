// Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario Compra.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;


/*
    Clase para gestionar el manejo de las compras dentro de los Servicios de Mantenimiento
    Proporciona métodos para consultar, insertar, modificar y eliminar datos.
 */
public class Compra extends javax.swing.JFrame 
{
    private String usuario;
    private String rol;
    int idCompra = -1;
    
    // Lista que almacena objetos de tipo DetalleCompra.
    private List<DetalleCompra> detalleCompraForms = new ArrayList<DetalleCompra>();
    
    /* 
        Constructor del formulario Compra.
        Inicializa el formulario y carga los datos de la tabla Compra en el JTable.
    */
    public Compra(String usuario, String rol) 
    {
        this.usuario = usuario;
        this.rol = rol;
        initComponents();
        ConsultaDatos();
        cargarProveedores();
        cmboxProveedor.setSelectedIndex(-1);
        configurarPermisos();
    }
    
    /*
        configurarPermisos
        Permite deshabilitar los botones de Insertar, Modificar y Eliminar para el usuario Empleado
    */
    public void configurarPermisos()
    {
        if(rol.equals("Empleado")){
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        }
    }

    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Comercial.Cliente en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos()
    {

    String[] datos = new String[4];
    DefaultTableModel model = new DefaultTableModel(new String[]{"Id Compra",
    "Proveedor", "Fecha de Compra", "totalCompra"}, 0);
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
   try
    { 
        // Conexión a la base de datos de Postgres.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
        String sql = "SELECT c.idCompra, c.idProveedor, c.fechaCompra, c.totalCompra, " +
            "p.NombreProveedor, p.TelefonoProveedor " +
            "FROM Comercial.Compra c " +
            "JOIN Comercial.Proveedor p ON c.idProveedor = p.idProveedor";
        stmt = bd.prepareStatement(sql);
        rs = stmt.executeQuery();
        TablaCompra.setModel(model);
        
        // Agrega los valores a una nueva fila para almacenarlos en el JTable.
        while(rs.next()){
        String nombreProveedor = rs.getString("nombreProveedor");
        String telefonoProveedor = rs.getString("telefonoProveedor");
        String domicilio = nombreProveedor + " - " + telefonoProveedor.substring(telefonoProveedor.length()-3);
        datos[0] = String.valueOf(rs.getInt("idCompra"));
        datos[1] = domicilio;
        datos[2] = rs.getString("fechaCompra");
        BigDecimal totalCompra = rs.getBigDecimal("totalCompra");
            datos[3] = (totalCompra != null) ? totalCompra.toString() : "0.00";
        model.addRow(datos);
    }
    rs.close();
    stmt.close();
    bd.close();
    } catch(SQLException ex){
        JOptionPane.showMessageDialog(null, "Error al cargar la Compra.");
        }
    }
    
    /*
        Carge la información de la tabla Comercial.Proveedor y la muestra en un combobox.
     */
    public void cargarProveedores() 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
            // Conexión a la base de datos de Postgres.
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
           "postgres");
            String sql = "SELECT nombreProveedor, telefonoProveedor FROM Comercial.Proveedor";
            stmt = bd.prepareStatement(sql);
            rs = stmt.executeQuery();

            // Limpiar el JComboBox antes de agregar datos
            cmboxProveedor.removeAllItems();

            // Leer cada domicilio y cliente del resultado de la consulta
            while (rs.next()) {
                String nombreProveedor = rs.getString("nombreProveedor");
                String telefonoProveedor = rs.getString("telefonoProveedor");
                String domicilio = nombreProveedor + " - " + telefonoProveedor.substring(telefonoProveedor.length()-3);

                // Agregar resultado al JComboBox
                cmboxProveedor.addItem(domicilio);
            }
        rs.close();
        stmt.close();
        bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los domicilios.");
        }
    }
    
    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Comercial.Compra con los datos ingresados.
    */
    public void InsertaDato()
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Obtener datos del formulario
        String proveedorSeleccionado=cmboxProveedor.getSelectedItem().toString();
        String[] partesProveedor = proveedorSeleccionado.split("\\-");
        String nombreProveedor = partesProveedor[0].trim();
        String ultimosTresTelefono = partesProveedor[1].trim();
        
        java.sql.Date fechaCompra = new java.sql.Date(new Date().getTime());
        
        // Conexión a la base de datos de Postgres.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Obtener idProveedor
        long idProveedor = 0;
        String queryIdProveedor = "SELECT idProveedor FROM Comercial.Proveedor WHERE nombreProveedor = ? AND RIGHT(telefonoProveedor, 3) = ?";
        stmt = bd.prepareStatement(queryIdProveedor);
        stmt.setString(1, nombreProveedor);
        stmt.setString(2, ultimosTresTelefono);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idProveedor = rs.getLong("idProveedor");
        } else {
            JOptionPane.showMessageDialog(null, "El proveedor seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String insertInfo = "INSERT INTO Comercial.Compra(idProveedor, fechaCompra)VALUES(?, ?)";
        stmt = bd.prepareStatement(insertInfo);
        stmt.setLong(1, idProveedor);
        stmt.setDate(2, fechaCompra);
        stmt.executeUpdate();
        
        cmboxProveedor.setSelectedIndex(-1);
        
    }catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar la compra: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Comercial.Proveedor con los datos actualizados.
    */
    public void ModificaDato(int idCompra)
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Obtener datos del formulario
        String proveedorSeleccionado = (String)cmboxProveedor.getSelectedItem();
        if (proveedorSeleccionado == null || proveedorSeleccionado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un proveedor válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] partesProveedor = proveedorSeleccionado.split("\\-");
        String nombreProveedor = partesProveedor[0].trim();
        String ultimosTresTelefono = partesProveedor[1].trim();
        
        java.sql.Date fechaCompra = new java.sql.Date(new Date().getTime());
        
        // Conexión a la base de datos de Postgres.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Obtener idCompra
        long idProveedor = 0;  // Cambiar a tipo long
        String queryIdProveedor = "SELECT idProveedor FROM Comercial.Proveedor WHERE nombreProveedor = ? AND RIGHT(telefonoProveedor, 3) = ?";
        stmt = bd.prepareStatement(queryIdProveedor);
        stmt.setString(1, nombreProveedor);
        stmt.setString(2, ultimosTresTelefono);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idProveedor = rs.getLong("idProveedor");  // Usar getLong en lugar de getString
        } else {
            JOptionPane.showMessageDialog(null, "El proveedor seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String insertInfo = "UPDATE Comercial.Compra SET idProveedor = ?, fechaCompra = ? WHERE idCompra = ?";
        stmt = bd.prepareStatement(insertInfo);
        stmt.setLong(1, idProveedor);
        stmt.setDate(2, fechaCompra);
        stmt.setInt(3, idCompra);
        stmt.executeUpdate();
        
        cmboxProveedor.setSelectedIndex(-1);
        
    }catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar el servicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Comercial.Compra con los datos actualizados.
    */
    private void EliminaDato(int idCompra)
    {
        Connection bd = null;
        PreparedStatement stmt = null;

        try
        {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
            String sql = "DELETE FROM Comercial.Compra WHERE idCompra = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idCompra);
            
            stmt.executeUpdate();
            
            cmboxProveedor.setSelectedIndex(-1);
            stmt.close();
            bd.close();
    }catch(SQLException ex){
       JOptionPane.showMessageDialog(null, "Error al eliminar la Compra.");
        }
    }
    
    /*
        SeleccionaDato
        Selecciona los datos de la compra y los muestra en los campos de texto correspondientes.
    */
    public void SeleccionaDato(int idCompra) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Conexión a la base de datos de Postgres.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Consulta para obtener los datos de la compra según idCompra
        String sql = "SELECT c.idCompra, c.idProveedor, c.fechaCompra, c.totalCompra, " +
                     "p.NombreProveedor, p.TelefonoProveedor " +
                     "FROM Comercial.Compra c " +
                     "JOIN Comercial.Proveedor p ON c.idProveedor = p.idProveedor " +
                     "WHERE c.idCompra = ?";
        stmt = bd.prepareStatement(sql);
        stmt.setInt(1, idCompra);
        rs = stmt.executeQuery();

        // Verificamos si se encontró la compra
        if (rs.next()) {
            String nombreProveedor = rs.getString("NombreProveedor");
            String telefonoProveedor = rs.getString("TelefonoProveedor");
            String domicilio = nombreProveedor + " - " + telefonoProveedor.substring(telefonoProveedor.length() - 3);

            // Asignar el valor al ComboBox
            cmboxProveedor.setSelectedItem(domicilio);  // Asumimos que cmboxProveedor es el JComboBox

        } else {
            JOptionPane.showMessageDialog(null, "No se encontró la compra con el ID especificado.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al seleccionar los datos de la compra: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
           }
        }
    } 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnInsertar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaCompra = new javax.swing.JTable();
        cmboxProveedor = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        btnDetalleCompra = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Compra");

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        TablaCompra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TablaCompra.setToolTipText("");
        TablaCompra.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        TablaCompra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaCompraMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaCompra);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Seleccione el proveedor:");

        btnDetalleCompra.setText("Detalle de Compra");
        btnDetalleCompra.setEnabled(false);
        btnDetalleCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetalleCompraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmboxProveedor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(btnInsertar)
                                    .addGap(78, 78, 78)
                                    .addComponent(btnModificar)
                                    .addGap(83, 83, 83)
                                    .addComponent(btnEliminar))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(131, 131, 131)
                        .addComponent(btnDetalleCompra)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmboxProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDetalleCompra)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato();
        ConsultaDatos();
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idCliente, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaCompra.getSelectedRow();
        if(fila >= 0){
            idCompra = Integer.parseInt(TablaCompra.getValueAt(fila, 0).toString());
            EliminaDato(idCompra);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idCliente, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaCompra.getSelectedRow();
        if(fila >= 0){
            idCompra = Integer.parseInt(TablaCompra.getValueAt(fila, 0).toString());
            ModificaDato(idCompra);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
        Llama al método SeleccionaDato para cargar los datos del cliente en los campos de texto.
    */
    private void TablaCompraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaCompraMouseClicked
        int fila = TablaCompra.getSelectedRow();
        if(fila >= 0) {
            idCompra = Integer.parseInt(TablaCompra.getValueAt(fila, 0).toString());
            SeleccionaDato(idCompra);
            
            if(rol.equals("Admin")){
                btnDetalleCompra.setEnabled(true);
            }
        }
        else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_TablaCompraMouseClicked

    /*
        btnDetalleCompraActionPerformed
        Evento que se dispara al hacer clic en el botón de Detalle de Compra.
        Abre el formulario DetalleCompra para gestionar los detalles asociados a una compra específica.
     */
    private void btnDetalleCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetalleCompraActionPerformed
        if(idCompra != -1)
        {
            DetalleCompra detalleCompraForm = new DetalleCompra(idCompra);
            detalleCompraForms.add(detalleCompraForm);
            detalleCompraForm.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosing(java.awt.event.WindowEvent e) {
                detalleCompraForms.remove(detalleCompraForm);
            }
            });
            detalleCompraForm.setVisible(true);
        }
    }//GEN-LAST:event_btnDetalleCompraActionPerformed

    public static void main(String args[]) {
        String usuario = "";
        String rol = "";
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Compra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Compra(usuario, rol).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaCompra;
    private javax.swing.JButton btnDetalleCompra;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JComboBox<String> cmboxProveedor;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
