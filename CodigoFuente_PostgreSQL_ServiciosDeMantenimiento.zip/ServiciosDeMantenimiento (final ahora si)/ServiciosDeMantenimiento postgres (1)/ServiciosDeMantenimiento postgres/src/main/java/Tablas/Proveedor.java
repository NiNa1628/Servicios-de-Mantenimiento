// Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario Proveedor.
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
    Clase para gestionar el manejo de los proveedores dentro de los Servicios de Mantenimiento
    Proporciona métodos para consultar, insertar, modificar y eliminar datos.
 */
public class Proveedor extends javax.swing.JFrame 
{
    private String usuario;
    private String rol;
    
    /* 
        Constructor del formulario Proveedor.
        Inicializa el formulario y carga los datos de la tabla Comercial.Proveedor en el JTable.
    */
    public Proveedor(String usuario, String rol) 
    {
        this.usuario = usuario;
        this.rol = rol;
        initComponents();
        ConsultaDatos();
        configurarPermisos();
    }
    
    /*
        configurarPermisos
        Permite deshabilitar los botones de Insertar, Modificar y Eliminar para el usuario Empleado
    */
    public void configurarPermisos()
    {
        if(rol.equals("Empleado")){
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        }
    }
    
    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Comercial.Proveedor en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos() 
    {
        String[] datos = new String[4];
        DefaultTableModel model = new DefaultTableModel(new String[]{
            "Id Proveedor", "Nombre del Proveedor", "Teléfono del Proveedor", "Email del Proveedor"
        }, 0);
        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            // Conexión a la base de datos de Postgres.
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            String sql = "SELECT * FROM Comercial.Proveedor";
            stmt = bd.prepareStatement(sql);
            rs = stmt.executeQuery();
            TablaProveedor.setModel(model);

            // Agrega los valores a una nueva fila para almacenarlos en el JTable.
            while (rs.next()) {
                datos[0] = String.valueOf(rs.getInt("idProveedor"));
                datos[1] = rs.getString("nombreProveedor");
                datos[2] = rs.getString("telefonoProveedor");
                datos[3] = rs.getString("emailProveedor");
                model.addRow(datos);
            }
            rs.close();
            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los proveedores.");
        }
    }

    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Comercial.Proveedor con los datos ingresados.
        Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
    */
    private void InsertaDato() 
    {
        String nombre = txtNombreProveedor.getText();
        String telefono = txtTelefonoProveedor.getText();
        String email = txtEmailProveedor.getText();

        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establece la conexión a la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            // Verifica si el RFC, teléfono o correo ya existen
            String verifica = "SELECT COUNT(*) FROM Comercial.Proveedor WHERE telefonoProveedor = ? OR emailProveedor = ?";
            stmt = bd.prepareStatement(verifica);
            stmt.setString(1, telefono);
            stmt.setString(2, email);

            // Ejecuta la consulta
            rs = stmt.executeQuery();
            int count = 0;
            if (rs.next()) {
                count = rs.getInt(1);
            }

            if (count > 0) {
                JOptionPane.showMessageDialog(null, "El teléfono o el correo electrónico ya están en uso.");
                txtNombreProveedor.setText("");
                txtTelefonoProveedor.setText("");
                txtEmailProveedor.setText("");
            } else {
                // Inserta el nuevo proveedor
                String sql = "INSERT INTO Comercial.Proveedor (nombreProveedor, telefonoProveedor, emailProveedor) VALUES (?, ?, ?)";
                stmt.close();
                stmt = bd.prepareStatement(sql);
                stmt.setString(1, nombre);
                stmt.setString(2, telefono);
                stmt.setString(3, email);

                stmt.executeUpdate();

                txtNombreProveedor.setText("");
                txtTelefonoProveedor.setText("");
                txtEmailProveedor.setText("");

                rs.close();
                stmt.close();
                bd.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al insertar el Proveedor: ");
        }
    }

    /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Comercial.Proveedor con los datos actualizados.
        Si ocurre un error (como duplicación de RFC, teléfono o email), muestra un mensaje de error.
    */
    private void ModificaDato(int idProveedor)
    {
        String nombre = txtNombreProveedor.getText();
        String telefono = txtTelefonoProveedor.getText();
        String email = txtEmailProveedor.getText();

        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establece la conexión a la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            // Verifica si el RFC, teléfono o correo ya existen
            String verifica = "SELECT COUNT(*) FROM Comercial.Proveedor WHERE telefonoProveedor = ? OR emailProveedor = ?";
            stmt = bd.prepareStatement(verifica);
            stmt.setString(1, telefono);
            stmt.setString(2, email);

            // Ejecuta la consulta
            rs = stmt.executeQuery();
            int count = 0;
            if (rs.next()) {
                count = rs.getInt(1);
            }

            if (count > 0) {
                JOptionPane.showMessageDialog(null, "El teléfono o el correo electrónico ya están en uso.");
                txtNombreProveedor.setText("");
                txtTelefonoProveedor.setText("");
                txtEmailProveedor.setText("");
            } else {
                // Modifica el proveedor en la base de datos
                String sql = "UPDATE Comercial.Proveedor SET nombreProveedor = ?, telefonoProveedor = ?, emailProveedor = ? WHERE idProveedor = ?";
                stmt = bd.prepareStatement(sql);
                stmt.setString(1, nombre);
                stmt.setString(2, telefono);
                stmt.setString(3, email);
                stmt.setInt(4, idProveedor);

                stmt.executeUpdate();

                txtNombreProveedor.setText("");
                txtTelefonoProveedor.setText("");
                txtEmailProveedor.setText("");

                stmt.close();
                bd.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar el Proveedor.");
        }
    }

    /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Comercial.Proveedor con los datos actualizados.
    */
    private void EliminaDato(int idProveedor)
    {
        Connection bd = null;
        PreparedStatement stmt = null;

        try {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            String sql = "DELETE FROM Comercial.Proveedor WHERE idProveedor = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idProveedor);

            stmt.executeUpdate();

            txtNombreProveedor.setText("");
            txtTelefonoProveedor.setText("");
            txtEmailProveedor.setText("");

            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el Proveedor.");
        }
    }

    /*
        SeleccionaDato
        Selecciona los datos del proveedor y los muestra en los campos de texto correspondientes.
    */
    private void SeleccionaDato(int idProveedor) 
    {
        Connection bd = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");
            String sql = "SELECT nombreProveedor, telefonoProveedor, emailProveedor FROM Comercial.Proveedor WHERE idProveedor = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idProveedor);
            rs = stmt.executeQuery();
            if (rs.next()) {
                txtNombreProveedor.setText(rs.getString("nombreProveedor"));
                txtTelefonoProveedor.setText(rs.getString("telefonoProveedor"));
                txtEmailProveedor.setText(rs.getString("emailProveedor"));
            }
            rs.close();
            stmt.close();
            bd.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener los datos del Proveedor.");
            ex.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtTelefonoProveedor = new javax.swing.JTextField();
        btnInsertar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaProveedor = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombreProveedor = new javax.swing.JTextField();
        txtEmailProveedor = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Proveedor");

        txtTelefonoProveedor.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        TablaProveedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TablaProveedor.setToolTipText("");
        TablaProveedor.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        TablaProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaProveedorMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaProveedor);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Nombre Proveedor:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Teléfono Proveedor:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Email Proveedor:");

        txtNombreProveedor.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txtEmailProveedor.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 519, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addComponent(btnInsertar)
                                        .addGap(50, 50, 50))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnModificar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnEliminar))
                                    .addComponent(txtEmailProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtTelefonoProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtNombreProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelefonoProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEmailProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato();
        ConsultaDatos();
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idCliente, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaProveedor.getSelectedRow();
        if(fila >= 0){
            int idProveedor = Integer.parseInt(TablaProveedor.getValueAt(fila, 0).toString());
            EliminaDato(idProveedor);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idCliente, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaProveedor.getSelectedRow();
        if(fila >= 0){
            int idProveedor = Integer.parseInt(TablaProveedor.getValueAt(fila, 0).toString());
            ModificaDato(idProveedor);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
        Llama al método SeleccionaDato para cargar los datos del cliente en los campos de texto.
    */
    private void TablaProveedorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaProveedorMouseClicked
        int fila = TablaProveedor.getSelectedRow();
        if(fila >= 0) {
            int idProveedor = Integer.parseInt(TablaProveedor.getValueAt(fila, 0).toString());
            SeleccionaDato(idProveedor);
        }
        else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_TablaProveedorMouseClicked

    public static void main(String args[]) {
        String usuario = "";
        String rol = "";
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Proveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Proveedor(usuario, rol).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaProveedor;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtEmailProveedor;
    private javax.swing.JTextField txtNombreProveedor;
    private javax.swing.JTextField txtTelefonoProveedor;
    // End of variables declaration//GEN-END:variables
}
