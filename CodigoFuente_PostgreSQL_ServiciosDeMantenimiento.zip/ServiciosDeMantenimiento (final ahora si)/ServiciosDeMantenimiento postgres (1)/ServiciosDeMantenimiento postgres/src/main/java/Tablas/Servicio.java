// Conjunto de clases en la cual contendrá las tablas del proyecto Servicios de Mantenimiento.
package Tablas;

// Librerías del sistema usadas para crear y gestionar el formulario  Servicio.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/*
    Clase para gestionar el manejo de los servicio dentro de los Servicios de Mantenimiento
    Proporciona métodos para consultar, insertar, modificar y eliminar datos.
 */
public class Servicio extends javax.swing.JFrame 
{
    private String usuario;
    private String rol;
    int idServicio = -1;
    
    // Lista que almacena objetos de tipo TrabajadorXServicio.
    private List<TrabajadorXServicio> trabajadorXServicioForms = new ArrayList<TrabajadorXServicio>();
    
    // Lista que almacena objetos de tipo MaterialXServicio.
    private List<MaterialXServicio> materialXServicioForms = new ArrayList<MaterialXServicio>();
    
    /* 
        Constructor del formulario Servicio.
        Inicializa el formulario y carga los datos de la tabla Servicio en el JTable.
    */
    public Servicio(String usuario, String rol) 
    {
        this.usuario = usuario;
        this.rol = rol;
        initComponents();
        ConsultaDatos();
        cargarDomicilios();
        cmboxDomicilio.setSelectedIndex(-1);
        configurarPermisos();
    }
    
    /*
        configurarPermisos
        Permite deshabilitar los botones de Insertar, Modificar y Eliminar para el usuario Empleado
    */
    public void configurarPermisos()
    {
        if(rol.equals("Empleado")){
        btnInsertar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        }
    }
    
    /*
        ConsultaDatos
        Recupera y muestra todos los registros de la tabla Comercial.Compra en el JTable.
        Creación del modelo de la tabla agregando los encabezados de cada columna donde inicialmente no contiene filas.
    */
    private void ConsultaDatos()
    {

    String[] datos = new String[7];
    DefaultTableModel model = new DefaultTableModel(new String[]{"Id Servicio",
    "Domicilio", "Fecha de Cotización", "Fecha de Inicio", "Fecha de Finalización", "Duración", "Costo Final"}, 0);
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
   try
    { 
        // Conexión a la base de datos de Postgres.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
        String sql = "SELECT s.idServicio, s.idDomicilio, s.fechaCotizacion, s.fechaInicio, s.fechaFinal, s.duracion, s.costoFinal, "
                + "CONCAT(dc.domicilioCliente, ' (', c.nombreCliente, ')') AS DomicilioCliente "
                + "FROM Operativo.Servicio s JOIN Comercial.DomicilioCliente dc ON s.idDomicilio = dc.idDomicilio "
                + "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente";
        stmt = bd.prepareStatement(sql);
        rs = stmt.executeQuery();
        TablaServicio.setModel(model);
        
        // Agrega los valores a una nueva fila para almacenarlos en el JTable.
        while(rs.next()){
        datos[0] = String.valueOf(rs.getInt("idServicio"));
        datos[1] = rs.getString("DomicilioCliente");
        datos[2] = rs.getString("fechaCotizacion");
        datos[3] = rs.getString("fechaInicio");
        datos[4] = rs.getString("fechaFinal");
        datos[5] = rs.getString("duracion");
        datos[6] = rs.getString("costoFinal") != null ? rs.getString("costoFinal") : "0.00";
        model.addRow(datos);
    }
    rs.close();
    stmt.close();
    bd.close();
    } catch(SQLException ex){
        JOptionPane.showMessageDialog(null, "Error al cargar el Cliente.");
        }
    }
    
    /*
        Carge la información de la tabla Comercial.Cliente y Comercial.DomicilioCliente y la muestra en un combobox.
     */
    public void cargarDomicilios() 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
            // Conexión a la base de datos de Postgres.
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
           "postgres");
            String sql = "SELECT dc.domicilioCliente, c.nombreCliente " +
                                "FROM Comercial.DomicilioCliente dc " +
                                "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente";
            stmt = bd.prepareStatement(sql);
            rs = stmt.executeQuery();

            // Limpiar el JComboBox antes de agregar datos
            cmboxDomicilio.removeAllItems();

            // Leer cada domicilio y cliente del resultado de la consulta
            while (rs.next()) {
                String domicilioCliente = rs.getString("domicilioCliente");
                String nombreCliente = rs.getString("nombreCliente");
                String domicilio = domicilioCliente + " (" + nombreCliente + ")";

                // Agregar resultado al JComboBox
                cmboxDomicilio.addItem(domicilio);
            }
        rs.close();
        stmt.close();
        bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los domicilios.");
        }
    }
    
    /*
        InsertaDato
        Inserta un nuevo registro en la tabla Operativo.Servicio con los datos ingresados.
    */
    public void InsertaDato() 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Obtener datos del formulario
        String domicilioSeleccionado = cmboxDomicilio.getSelectedItem().toString();
        String[] partesDomicilio = domicilioSeleccionado.split("\\(");
        String domicilioCliente = partesDomicilio[0].trim();

        // Validar si las fechas de inicio y finalización están seleccionadas
        if (dtpFech_Ini.getDate() == null || dtpFech_Fin.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione todas las fechas.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        java.sql.Date fechaCotizacion = new java.sql.Date(new Date().getTime());
        java.sql.Date fechaInicio = new java.sql.Date(dtpFech_Ini.getDate().getTime());
        java.sql.Date fechaFinal = new java.sql.Date(dtpFech_Fin.getDate().getTime());

        // Validar fechas de inicio y finalización
        Date fechaActual = new Date();
        if (dtpFech_Ini.getDate().before(fechaActual)) {
            JOptionPane.showMessageDialog(null, "La fecha de inicio no puede ser anterior a la fecha actual (cotización).", "Error de Fecha", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (dtpFech_Fin.getDate().before(dtpFech_Ini.getDate())) {
            JOptionPane.showMessageDialog(null, "La fecha de finalización no puede ser anterior a la fecha de inicio.", "Error de Fecha", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Conexión a la base de datos de Postgres.
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        long idDomicilio = 0;
        String queryIdDomicilio = "SELECT idDomicilio FROM Comercial.DomicilioCliente WHERE domicilioCliente = ?";
        stmt = bd.prepareStatement(queryIdDomicilio);
        stmt.setString(1, domicilioCliente);
        rs = stmt.executeQuery();

        if (rs.next()) {
            idDomicilio = rs.getLong("idDomicilio");
        } else {
            JOptionPane.showMessageDialog(null, "El domicilio seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si ya existe un servicio programado para este domicilio
        String queryCheckServicio = "SELECT COUNT(*) FROM Operativo.Servicio WHERE idDomicilio = ? AND fechaFinal >= ?";
        stmt = bd.prepareStatement(queryCheckServicio);
        stmt.setLong(1, idDomicilio);
        stmt.setDate(2, fechaInicio);
        rs = stmt.executeQuery();

        if (rs.next() && rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(null, "No se puede programar un nuevo servicio para este domicilio hasta que el servicio actual finalice.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String insertInfo = "INSERT INTO Operativo.Servicio(idDomicilio, fechaCotizacion, fechaInicio, fechaFinal) VALUES (?, ?, ?, ?)";
        stmt = bd.prepareStatement(insertInfo);
        stmt.setLong(1, idDomicilio);
        stmt.setDate(2, fechaCotizacion);
        stmt.setDate(3, fechaInicio);   
        stmt.setDate(4, fechaFinal);
        stmt.executeUpdate();

        cmboxDomicilio.setSelectedIndex(-1);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar el servicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    /*
        ModificaDato
        Modifica el registro seleccionado en la tabla Operativo.Serivicio con los datos actualizados.     
     */
    private void ModificaDato(int idServicio) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
            // Obtener datos del formulario
            String domicilioSeleccionado = (String) cmboxDomicilio.getSelectedItem();
            if (domicilioSeleccionado == null || domicilioSeleccionado.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Seleccione un domicilio válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String[] partesDomicilio = domicilioSeleccionado.split("\\(");

            // Validar fechas
            if (dtpFech_Ini.getDate() == null || dtpFech_Fin.getDate() == null) {
                JOptionPane.showMessageDialog(null, "Por favor, seleccione todas las fechas.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            java.sql.Date fechaInicio = new java.sql.Date(dtpFech_Ini.getDate().getTime());
            java.sql.Date fechaFinal = new java.sql.Date(dtpFech_Fin.getDate().getTime());

            if (fechaFinal.before(fechaInicio)) {
                JOptionPane.showMessageDialog(null, "La fecha de finalización no puede ser anterior a la fecha de inicio.", "Error de Fecha", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Conexión a la base de datos
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

            // Obtener idDomicilio
            long idDomicilio = 0;
            String queryIdDomicilio = "SELECT dc.idDomicilio FROM Comercial.DomicilioCliente dc JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente "
                    + "WHERE dc.domicilioCliente = ? AND c.nombreCliente = ?";
            stmt = bd.prepareStatement(queryIdDomicilio);
            String domicilioCliente = partesDomicilio[0].trim();
            String nombreCliente = partesDomicilio[1].replace(")", "").trim();

            stmt.setString(1, domicilioCliente);
            stmt.setString(2, nombreCliente);
            rs = stmt.executeQuery();

            if (rs.next()) {
                idDomicilio = rs.getLong("idDomicilio");
            } else {
                JOptionPane.showMessageDialog(null, "El domicilio seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Verificar si ya existe un servicio programado en el mismo rango de fechas y domicilio
            String queryCheckServicio = "SELECT COUNT(*) FROM Operativo.Servicio WHERE idDomicilio = ? AND fechaFinal >= ? AND fechaInicio <= ? "
                    + "AND idServicio <> ?";
            stmt = bd.prepareStatement(queryCheckServicio);
            stmt.setLong(1, idDomicilio);
            stmt.setDate(2, fechaInicio);
            stmt.setDate(3, fechaFinal);
            stmt.setInt(4, idServicio);

            rs = stmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(null, 
                    "Ya existe otro servicio programado en este rango de fechas para el mismo domicilio.", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Insertar nuevo servicio
            String insertInfo = "UPDATE Operativo.Servicio SET idDomicilio = ?, fechaInicio = ?, fechaFinal= ? WHERE idServicio = ?";
            stmt = bd.prepareStatement(insertInfo);
            stmt.setLong(1, idDomicilio);
            stmt.setDate(2, fechaInicio);
            stmt.setDate(3, fechaFinal);
            stmt.setInt(4, idServicio);
            stmt.executeUpdate();

            cmboxDomicilio.setSelectedIndex(-1);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar el servicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    
    /*
        EliminaDato
        Elimina el registro seleccionado en la tabla Operativo.Servicio con los datos actualizados.
    */
    private void EliminaDato(int idServicio)
    {
        Connection bd = null;
        PreparedStatement stmt = null;

        try
        {
            bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres",
       "postgres");
            String sql = "DELETE FROM Operativo.Servicio WHERE idServicio = ?";
            stmt = bd.prepareStatement(sql);
            stmt.setInt(1, idServicio);
            
            stmt.executeUpdate();
            
            cmboxDomicilio.setSelectedIndex(-1);
            stmt.close();
            bd.close();
    }catch(SQLException ex){
       JOptionPane.showMessageDialog(null, "Error al eliminar el Servicio.");
        }
    }

    /*
        SeleccionaDato
        Selecciona los datos del servicio y los muestra en los campos de texto correspondientes.
    */
    private void SeleccionaDato(int idServicio) 
    {
    Connection bd = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        // Conexión a la base de datos
        bd = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ServiciosDeMantenimiento", "postgres", "postgres");

        // Consulta para obtener los datos del servicio seleccionado
        String query = "SELECT s.idServicio, s.idDomicilio, s.fechaCotizacion, s.fechaInicio, s.fechaFinal, s.duracion, s.costoFinal, "
                     + "CONCAT(dc.domicilioCliente, ' (', c.nombreCliente, ')') AS DomicilioCliente "
                     + "FROM Operativo.Servicio s "
                     + "JOIN Comercial.DomicilioCliente dc ON s.idDomicilio = dc.idDomicilio "
                     + "JOIN Comercial.Cliente c ON dc.idCliente = c.idCliente "
                     + "WHERE s.idServicio = ?";
        stmt = bd.prepareStatement(query);
        stmt.setInt(1, idServicio);
        rs = stmt.executeQuery();

        // Si encontramos un servicio con ese id
        if (rs.next()) {
            // Obtener los valores de la consulta
            String domicilioCliente = rs.getString("DomicilioCliente");
            java.sql.Date fechaInicio = rs.getDate("fechaInicio");
            java.sql.Date fechaFinal = rs.getDate("fechaFinal");

            cmboxDomicilio.setSelectedItem(domicilioCliente);
            dtpFech_Ini.setDate(fechaInicio);
            dtpFech_Fin.setDate(fechaFinal);
        }

        rs.close();
        stmt.close();
        bd.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al seleccionar el servicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (bd != null) bd.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnInsertar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaServicio = new javax.swing.JTable();
        cmboxDomicilio = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        dtpFech_Ini = new com.toedter.calendar.JDateChooser();
        dtpFech_Fin = new com.toedter.calendar.JDateChooser();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btnTrabajador = new javax.swing.JButton();
        btnMaterial = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Servicio");

        btnInsertar.setText("Insertar");
        btnInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        TablaServicio.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TablaServicio.setToolTipText("");
        TablaServicio.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        TablaServicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaServicioMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaServicio);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Seleccione el domicilio:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Fecha de Finalización:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Fecha de Inicio:");

        btnTrabajador.setText("Trabajador del Servicio");
        btnTrabajador.setEnabled(false);
        btnTrabajador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTrabajadorActionPerformed(evt);
            }
        });

        btnMaterial.setText("Material del Servicio");
        btnMaterial.setEnabled(false);
        btnMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMaterialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(btnInsertar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 221, Short.MAX_VALUE)
                .addComponent(btnModificar)
                .addGap(163, 163, 163)
                .addComponent(btnEliminar)
                .addGap(89, 89, 89))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(192, 192, 192)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dtpFech_Ini, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                    .addComponent(cmboxDomicilio, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dtpFech_Fin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnTrabajador)
                .addGap(148, 148, 148))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(133, 133, 133)
                    .addComponent(btnMaterial)
                    .addContainerGap(514, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmboxDomicilio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addComponent(dtpFech_Ini, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(dtpFech_Fin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnEliminar)
                    .addComponent(btnModificar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(317, Short.MAX_VALUE)
                    .addComponent(btnMaterial)
                    .addContainerGap()))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*
        btnInsertarActionPerformed
        Evento de clic del botón de inserción.
        Llama a InsertaDato, actualiza el JTable llamando a ConsultaDatos y limpia los campos de entrada.
    */
    private void btnInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarActionPerformed
        InsertaDato();
        ConsultaDatos();
    }//GEN-LAST:event_btnInsertarActionPerformed

    /*
        btnEliminarActionPerformed
        Evento de clic del botón de eliminación.
        Extrae el idServicio, llama a EliminaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaServicio.getSelectedRow();
        if(fila >= 0){
            int idServicio = Integer.parseInt(TablaServicio.getValueAt(fila, 0).toString());
            EliminaDato(idServicio);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /*
        btnModificarActionPerformed
        Evento de clic del botón de modificación.
        Extrae el idServicio, llama a ModificaDato, actualiza el JTable llamando a ConsultaDatos.
    */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = TablaServicio.getSelectedRow();
        if(fila >= 0){
            int idServicio = Integer.parseInt(TablaServicio.getValueAt(fila, 0).toString());
            ModificaDato(idServicio);
            ConsultaDatos();
        }
        else{
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    /*
        TablaClienteMouseClicked
        Evento que se activa al hacer clic en una celda del JTable.
        Llama al método SeleccionaDato para cargar los datos del servicio en los campos de texto.
    */
    private void TablaServicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaServicioMouseClicked
        int fila = TablaServicio.getSelectedRow();
        if(fila >= 0) {
            idServicio = Integer.parseInt(TablaServicio.getValueAt(fila, 0).toString());
            SeleccionaDato(idServicio);
            
            if(rol.equals("Admin")){
                btnTrabajador.setEnabled(true);
                btnMaterial.setEnabled(true);
            }
        }
        else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila válida.");
        }
    }//GEN-LAST:event_TablaServicioMouseClicked

    /*
        btnTrabajadorActionPerformed
        Evento que se dispara al hacer clic en el botón de Trabajador del Servicio.
        Abre el formulario TrabajadorXServicio para gestionar los trabajadores asociados a un servicio específica.
     */
    private void btnTrabajadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTrabajadorActionPerformed
        if(idServicio != -1)
        {
            TrabajadorXServicio trabajadorXServicioForm = new TrabajadorXServicio(idServicio);
            trabajadorXServicioForms.add(trabajadorXServicioForm);
            trabajadorXServicioForm.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosing(java.awt.event.WindowEvent e) {
                trabajadorXServicioForms.remove(trabajadorXServicioForm);
            }
            });
            trabajadorXServicioForm.setVisible(true);
        }
    }//GEN-LAST:event_btnTrabajadorActionPerformed

    /*
        btnMaterial1ActionPerformed
        Evento que se dispara al hacer clic en el botón de Material del Servicio.
        Abre el formulario MaterialXServicio para gestionar los materiales asociados a un servicio específica.
     */
    private void btnMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMaterialActionPerformed
        if(idServicio != -1)
        {
            MaterialXServicio materialXServicioForm = new MaterialXServicio(idServicio);
            materialXServicioForms.add(materialXServicioForm);
            materialXServicioForm.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosing(java.awt.event.WindowEvent e) {
                materialXServicioForms.remove(materialXServicioForm);
            }
            });
            materialXServicioForm.setVisible(true);
        }
    }//GEN-LAST:event_btnMaterialActionPerformed

    public static void main(String args[]) {
        String usuario = "";
        String rol = "";
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Servicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Servicio(usuario, rol).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaServicio;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnMaterial;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnTrabajador;
    private javax.swing.JComboBox<String> cmboxDomicilio;
    private com.toedter.calendar.JDateChooser dtpFech_Fin;
    private com.toedter.calendar.JDateChooser dtpFech_Ini;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
